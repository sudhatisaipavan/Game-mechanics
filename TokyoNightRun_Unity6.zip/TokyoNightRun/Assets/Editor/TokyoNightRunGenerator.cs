#if UNITY_EDITOR
#pragma warning disable 618
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace TokyoNightRun.EditorTools
{
    /// <summary>
    /// Tools > Tokyo Night Run > Generate Complete Game
    /// Creates the two scenes, registers tags/layers, includes the mobile shaders in builds, configures Android
    /// player settings and the build list, then validates everything. Safe to run again at any time.
    /// The game world itself (player, track, obstacles, UI) is built by code at runtime from the Bootstrap objects,
    /// so there are no prefabs to wire by hand.
    /// </summary>
    public static class TokyoNightRunGenerator
    {
        const string MenuScenePath = "Assets/Scenes/MainMenu.unity";
        const string GameScenePath = "Assets/Scenes/Game.unity";

        // Keeps the custom world shader in "Always Included Shaders" (Shader.Find at runtime needs this on Android).
        [InitializeOnLoadMethod]
        static void EnsureShadersOnLoad()
        {
            EditorApplication.delayCall += () =>
            {
                if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || EditorApplication.isUpdating) return;
                IncludeShaders();
                AssetDatabase.SaveAssets();
            };
        }

        [InitializeOnLoadMethod]
        static void AutoGenerateOnFirstOpen()
        {
            EditorApplication.delayCall += () =>
            {
                if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || EditorApplication.isUpdating) return;
                if (File.Exists(GameScenePath) && File.Exists(MenuScenePath)) return;
                if (SceneManager.GetActiveScene().isDirty) return; // never discard someone's unsaved work
                Debug.Log("[TokyoNightRun] First open detected - generating scenes automatically.");
                Generate(false);
            };
        }

        [MenuItem("Tools/Tokyo Night Run/Generate Complete Game")]
        public static void GenerateMenu() { Generate(true); }

        static void Generate(bool showDialog)
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;

            EnsureFolder("Assets/Scenes");
            RegisterTagsAndLayers();
            IncludeShaders();
            ConfigureAndroid();
            TokyoNightRunRenderSetup.SetupMenuSilent();
            CreateScene<MenuBootstrap>(MenuScenePath);
            CreateScene<GameBootstrap>(GameScenePath);
            SetBuildScenes();
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            bool ok = Validate(false);
            EditorSceneManager.OpenScene(MenuScenePath);
            string msg = ok
                ? "Tokyo Night Run is ready!\n\nPress PLAY in the Unity Editor to start from the Main Menu."
                : "Generation finished but validation found problems. Open the Console window for details.";
            Debug.Log("[TokyoNightRun] " + msg.Replace("\n", " "));
            if (showDialog) EditorUtility.DisplayDialog("Tokyo Night Run", msg, "OK");
        }

        static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;
            string parent = Path.GetDirectoryName(path).Replace('\\', '/');
            AssetDatabase.CreateFolder(parent, Path.GetFileName(path));
        }

        static void CreateScene<T>(string path) where T : MonoBehaviour
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var go = new GameObject("Bootstrap");
            go.AddComponent<T>();
            // Fog must be ON in the saved scene, otherwise Android builds strip the fog shader variants.
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogStartDistance = 70f;
            RenderSettings.fogEndDistance = 170f;
            RenderSettings.fogColor = new Color(0.97f, 0.7f, 0.78f);
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.7f, 0.6f, 0.65f);
            EditorSceneManager.SaveScene(scene, path);
        }

        static void SetBuildScenes()
        {
            EditorBuildSettings.scenes = new[]
            {
                new EditorBuildSettingsScene(MenuScenePath, true),
                new EditorBuildSettingsScene(GameScenePath, true)
            };
        }

        // ---------- tags, layers, shaders ----------
        static void RegisterTagsAndLayers()
        {
            var tm = new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/TagManager.asset")[0]);
            AddTag(tm, "Obstacle");
            AddTag(tm, "Collectible");
            AddLayer(tm, "Obstacle");
            AddLayer(tm, "Collectible");
            tm.ApplyModifiedProperties();
        }

        static void AddTag(SerializedObject tm, string tag)
        {
            var tags = tm.FindProperty("tags");
            for (int i = 0; i < tags.arraySize; i++) if (tags.GetArrayElementAtIndex(i).stringValue == tag) return;
            tags.InsertArrayElementAtIndex(tags.arraySize);
            tags.GetArrayElementAtIndex(tags.arraySize - 1).stringValue = tag;
        }

        static void AddLayer(SerializedObject tm, string layer)
        {
            var layers = tm.FindProperty("layers");
            for (int i = 8; i < layers.arraySize; i++) if (layers.GetArrayElementAtIndex(i).stringValue == layer) return;
            for (int i = 8; i < layers.arraySize; i++)
            {
                var p = layers.GetArrayElementAtIndex(i);
                if (string.IsNullOrEmpty(p.stringValue)) { p.stringValue = layer; return; }
            }
        }

        static readonly string[] RequiredShaders = { "TokyoNightRun/VertexLit", "TokyoNightRun/Character", "TokyoNightRun/Unlit", "TokyoNightRun/Particle", "TokyoNightRun/Sky" };
        static readonly string[] OptionalShaders = { "Sprites/Default", "Unlit/Color" };

        public static void IncludeShadersPublic() { IncludeShaders(); AssetDatabase.SaveAssets(); }

        static void IncludeShaders()
        {
            var objs = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset");
            if (objs == null || objs.Length == 0) { Debug.LogWarning("[TokyoNightRun] Could not open GraphicsSettings; add the shaders manually (see README)."); return; }
            var so = new SerializedObject(objs[0]);
            var arr = so.FindProperty("m_AlwaysIncludedShaders");
            if (arr == null) { Debug.LogWarning("[TokyoNightRun] m_AlwaysIncludedShaders not found; add the shaders manually (see README)."); return; }
            var all = new List<string>(RequiredShaders);
            all.AddRange(OptionalShaders);
            foreach (var name in all)
            {
                var shader = Shader.Find(name);
                if (shader == null) { Debug.LogWarning("[TokyoNightRun] Shader not found: " + name); continue; }
                bool has = false;
                for (int i = 0; i < arr.arraySize; i++) if (arr.GetArrayElementAtIndex(i).objectReferenceValue == shader) has = true;
                if (has) continue;
                arr.InsertArrayElementAtIndex(arr.arraySize);
                arr.GetArrayElementAtIndex(arr.arraySize - 1).objectReferenceValue = shader;
            }
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        // ---------- Android ----------
        [MenuItem("Tools/Tokyo Night Run/Configure Android Settings")]
        public static void ConfigureAndroid()
        {
            PlayerSettings.companyName = "TokyoNightRun Studio";
            PlayerSettings.productName = "Tokyo Night Run";
            PlayerSettings.bundleVersion = "0.6.0";
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.Portrait;
            PlayerSettings.allowedAutorotateToPortrait = true;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.allowedAutorotateToLandscapeLeft = false;
            PlayerSettings.allowedAutorotateToLandscapeRight = false;
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.tokyonightrun.game");
            PlayerSettings.Android.bundleVersionCode = 1;
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARMv7 | AndroidArchitecture.ARM64;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel25;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.SetManagedStrippingLevel(NamedBuildTarget.Android, ManagedStrippingLevel.Low);
            Debug.Log("[TokyoNightRun] Android settings applied (portrait, IL2CPP, ARMv7+ARM64, min API 25, package com.tokyonightrun.game).");
        }

        [MenuItem("Tools/Tokyo Night Run/Build Android APK (testing)")]
        public static void BuildApk()
        {
            if (!File.Exists(GameScenePath)) Generate(false);
            Directory.CreateDirectory("Builds");
            var opts = new BuildPlayerOptions
            {
                scenes = new[] { MenuScenePath, GameScenePath },
                locationPathName = "Builds/TokyoNightRun.apk",
                target = BuildTarget.Android,
                options = BuildOptions.None
            };
            var report = BuildPipeline.BuildPlayer(opts);
            Debug.Log("[TokyoNightRun] APK build result: " + report.summary.result + " -> " + opts.locationPathName);
            if (report.summary.result != UnityEditor.Build.Reporting.BuildResult.Succeeded)
                EditorUtility.DisplayDialog("Tokyo Night Run", "Build did not succeed. Check the Console. Is 'Android Build Support' (with SDK, NDK, OpenJDK) installed in Unity Hub?", "OK");
        }

        // ---------- validation ----------
        [MenuItem("Tools/Tokyo Night Run/Validate Project")]
        public static void ValidateMenu() { Validate(true); }

        static bool Validate(bool showDialog)
        {
            var problems = new List<string>();
            if (!File.Exists(MenuScenePath)) problems.Add("Missing scene: " + MenuScenePath);
            if (!File.Exists(GameScenePath)) problems.Add("Missing scene: " + GameScenePath);
            var inBuild = new HashSet<string>();
            foreach (var s in EditorBuildSettings.scenes) if (s.enabled) inBuild.Add(s.path);
            if (!inBuild.Contains(MenuScenePath)) problems.Add("MainMenu is not in Build Settings");
            if (!inBuild.Contains(GameScenePath)) problems.Add("Game is not in Build Settings");
            if (inBuild.Count > 0 && EditorBuildSettings.scenes.Length > 0 && EditorBuildSettings.scenes[0].path != MenuScenePath)
                problems.Add("MainMenu should be scene 0 in Build Settings");
            foreach (var n in RequiredShaders) if (Shader.Find(n) == null) problems.Add("Shader not found (compile error in Assets/Shaders?): " + n);
            if (!TokyoNightRunRenderSetup.UrpInstalled) problems.Add("URP package not installed yet - run Tools > Tokyo Night Run > Setup Unity 6 Rendering (URP)");
            else if (UnityEngine.Rendering.GraphicsSettings.defaultRenderPipeline == null) problems.Add("No render pipeline asset assigned - run Tools > Tokyo Night Run > Setup Unity 6 Rendering (URP)");
            if (PlayerSettings.defaultInterfaceOrientation != UIOrientation.Portrait) problems.Add("Orientation is not Portrait");
            if (UIBuilder.DefaultFont == null) problems.Add("Built-in UI font not found");

            if (problems.Count == 0) Debug.Log("[TokyoNightRun] Validation passed: scenes exist, build list is correct, shaders available.");
            else foreach (var p in problems) Debug.LogError("[TokyoNightRun] " + p);
            if (showDialog) EditorUtility.DisplayDialog("Tokyo Night Run validation", problems.Count == 0 ? "All checks passed." : string.Join("\n", problems), "OK");
            return problems.Count == 0;
        }
    }
}
#endif
