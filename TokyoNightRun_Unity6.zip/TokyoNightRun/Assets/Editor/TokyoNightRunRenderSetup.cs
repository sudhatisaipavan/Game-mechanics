#if UNITY_EDITOR
using System;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEditor.PackageManager;
using UnityEditor.PackageManager.Requests;
using UnityEngine;
using UnityEngine.Rendering;

namespace TokyoNightRun.EditorTools
{
    /// <summary>
    /// Unity 6.x rendering setup. The Built-in Render Pipeline is deprecated since Unity 6.5, so Tokyo Night Run renders with URP.
    /// On first open this installs the Universal RP package (the version that matches your editor), creates
    /// Assets/Settings/TokyoNightRun_URP.asset (+ renderer) tuned for mobile (HDR for bloom, MSAA, SRP Batcher, no shadows/depth/opaque textures),
    /// assigns it in Graphics + Quality settings and makes sure the legacy Input Manager stays active.
    /// Everything is done through reflection so the project still compiles before URP is installed.
    /// Menu: Tools > Tokyo Night Run > Setup Unity 6 Rendering (URP).
    /// </summary>
    public static class TokyoNightRunRenderSetup
    {
        const string Folder = "Assets/Settings";
        const string AssetPath = "Assets/Settings/TokyoNightRun_URP.asset";
        const string RendererPath = "Assets/Settings/TokyoNightRun_URP_Renderer.asset";
        const string UrpPackage = "com.unity.render-pipelines.universal";
        const string UrpAsm = "Unity.RenderPipelines.Universal.Runtime";
        const string AddedKey = "TokyoNightRun.UrpAddRequested";

        static AddRequest addRequest;

        static Type UrpAssetType { get { return Type.GetType("UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset, " + UrpAsm); } }
        static Type UrpRendererType { get { return Type.GetType("UnityEngine.Rendering.Universal.UniversalRendererData, " + UrpAsm); } }
        public static bool UrpInstalled { get { return UrpAssetType != null && UrpRendererType != null; } }

        [InitializeOnLoadMethod]
        static void AutoSetup()
        {
            EditorApplication.delayCall += () =>
            {
                if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling || EditorApplication.isUpdating) return;
                EnsureInputHandler(false);
                if (!UrpInstalled) { RequestPackage(); return; }
                if (GraphicsSettings.defaultRenderPipeline == null) CreateAndAssign(false);
            };
        }

        [MenuItem("Tools/Tokyo Night Run/Setup Unity 6 Rendering (URP)")]
        public static void SetupMenu()
        {
            EnsureInputHandler(true);
            if (!UrpInstalled)
            {
                SessionState.SetBool(AddedKey, false);
                RequestPackage();
                EditorUtility.DisplayDialog("Tokyo Night Run", "Installing the Universal Render Pipeline package. Wait for Unity to finish importing, then run this menu item again if the rendering is not set up automatically.", "OK");
                return;
            }
            CreateAndAssign(true);
        }

        /// <summary>Used by the generator: configure what can be configured now, without dialogs.</summary>
        public static void SetupMenuSilent()
        {
            EnsureInputHandler(false);
            if (UrpInstalled) CreateAndAssign(false); else RequestPackage();
        }

        static void RequestPackage()
        {
            if (SessionState.GetBool(AddedKey, false)) return;
            SessionState.SetBool(AddedKey, true);
            Debug.Log("[TokyoNightRun] Installing the Universal Render Pipeline package (matching version for this editor)...");
            addRequest = Client.Add(UrpPackage); // no version = the version Unity recommends for this editor
            EditorApplication.update += PollAdd;
        }

        static void PollAdd()
        {
            if (addRequest == null || !addRequest.IsCompleted) return;
            EditorApplication.update -= PollAdd;
            if (addRequest.Status == StatusCode.Success) Debug.Log("[TokyoNightRun] URP installed: " + addRequest.Result.packageId + ". Unity will reload scripts; rendering is configured afterwards.");
            else Debug.LogError("[TokyoNightRun] Could not install URP automatically: " + (addRequest.Error != null ? addRequest.Error.message : "unknown error") +
                                "\nOpen Window > Package Manager > Unity Registry, install 'Universal RP', then run Tools > Tokyo Night Run > Setup Unity 6 Rendering (URP).");
            addRequest = null;
        }

        static void CreateAndAssign(bool showDialog)
        {
            try
            {
                if (!AssetDatabase.IsValidFolder(Folder)) AssetDatabase.CreateFolder("Assets", "Settings");

                var asset = AssetDatabase.LoadAssetAtPath<RenderPipelineAsset>(AssetPath);
                if (asset == null)
                {
                    var rd = AssetDatabase.LoadAssetAtPath<ScriptableObject>(RendererPath);
                    if (rd == null)
                    {
                        rd = ScriptableObject.CreateInstance(UrpRendererType);
                        AssetDatabase.CreateAsset(rd, RendererPath);
                    }
                    MethodInfo create = null;
                    foreach (var m in UrpAssetType.GetMethods(BindingFlags.Public | BindingFlags.Static))
                        if (m.Name == "Create" && m.GetParameters().Length == 1) { create = m; break; }
                    if (create == null) throw new MissingMethodException("UniversalRenderPipelineAsset.Create not found");
                    asset = (RenderPipelineAsset)create.Invoke(null, new object[] { rd });
                    AssetDatabase.CreateAsset(asset, AssetPath);

                    // mobile-friendly, bloom-ready defaults (each set is best effort: names differ slightly between URP versions)
                    SetProp(asset, "supportsHDR", true);
                    SetProp(asset, "msaaSampleCount", 2);
                    SetProp(asset, "renderScale", 1f);
                    SetProp(asset, "supportsCameraDepthTexture", false);
                    SetProp(asset, "supportsCameraOpaqueTexture", false);
                    SetProp(asset, "useSRPBatcher", true);
                    SetProp(asset, "shadowDistance", 25f);
                    EditorUtility.SetDirty(asset);
                    AssetDatabase.SaveAssets();
                }

                GraphicsSettings.defaultRenderPipeline = asset;
                int original = QualitySettings.GetQualityLevel();
                for (int i = 0; i < QualitySettings.names.Length; i++)
                {
                    QualitySettings.SetQualityLevel(i, false);
                    QualitySettings.renderPipeline = asset;
                }
                QualitySettings.SetQualityLevel(original, false);
                AssetDatabase.SaveAssets();
                TokyoNightRunGenerator.IncludeShadersPublic();
                Debug.Log("[TokyoNightRun] URP configured: " + AssetPath);
                if (showDialog) EditorUtility.DisplayDialog("Tokyo Night Run", "Unity 6 rendering (URP) is configured.\nPress Play from Assets/Scenes/MainMenu.unity.", "OK");
            }
            catch (Exception e)
            {
                Debug.LogError("[TokyoNightRun] URP setup failed: " + e.Message + "\nCreate it manually: Assets > Create > Rendering > URP Asset (with Universal Renderer), then assign it in Project Settings > Graphics.");
                if (showDialog) EditorUtility.DisplayDialog("Tokyo Night Run", "URP setup failed - see the Console for details.", "OK");
            }
        }

        static void SetProp(object obj, string name, object value)
        {
            try
            {
                var p = obj.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                if (p != null && p.CanWrite) p.SetValue(obj, value, null);
            }
            catch (Exception) { /* property missing or read-only in this URP version: keep the default */ }
        }

        /// <summary>The game reads touch / keyboard through the legacy Input Manager. Make sure it is not disabled.</summary>
        static void EnsureInputHandler(bool verbose)
        {
            try
            {
                var objs = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/ProjectSettings.asset");
                if (objs == null || objs.Length == 0) return;
                var so = new SerializedObject(objs[0]);
                var p = so.FindProperty("activeInputHandler");
                if (p == null) return;
                if (p.intValue == 1) // 1 = Input System Package (New) only
                {
                    p.intValue = 2; // Both
                    so.ApplyModifiedPropertiesWithoutUndo();
                    Debug.LogWarning("[TokyoNightRun] Active Input Handling was 'Input System Package (New)'. Changed to 'Both' - restart the Unity Editor when prompted.");
                }
                else if (verbose) Debug.Log("[TokyoNightRun] Active Input Handling is fine.");
            }
            catch (Exception e) { Debug.LogWarning("[TokyoNightRun] Could not check Active Input Handling: " + e.Message); }
        }
    }
}
#endif
