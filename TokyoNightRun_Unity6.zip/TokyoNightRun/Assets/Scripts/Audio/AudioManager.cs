using System.Collections.Generic;
using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// One persistent audio manager (created automatically, survives scene loads, never duplicated).
    /// If you add your own AudioClips to the 'Override' fields they replace the generated sounds.
    /// </summary>
    public class AudioManager : MonoBehaviour
    {
        static AudioManager instance;

        public static AudioManager Instance
        {
            get
            {
                if (instance == null)
                {
                    var go = new GameObject("AudioManager");
                    go.AddComponent<AudioManager>(); // Awake assigns 'instance'
                }
                return instance;
            }
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics() { instance = null; }

        readonly Dictionary<SfxId, AudioClip> clips = new Dictionary<SfxId, AudioClip>();
        AudioSource music, sfx;
        bool ducked;

        void Awake()
        {
            if (instance != null && instance != this) { Destroy(gameObject); return; }
            instance = this;
            DontDestroyOnLoad(gameObject);
            music = gameObject.AddComponent<AudioSource>();
            music.loop = true; music.playOnAwake = false;
            sfx = gameObject.AddComponent<AudioSource>();
            sfx.playOnAwake = false;
            try
            {
                clips[SfxId.Coin] = AudioSynth.Coin(); clips[SfxId.Jump] = AudioSynth.Jump();
                clips[SfxId.Slide] = AudioSynth.Slide(); clips[SfxId.Land] = AudioSynth.Land();
                clips[SfxId.Hit] = AudioSynth.Hit(); clips[SfxId.PowerUp] = AudioSynth.PowerUp();
                clips[SfxId.Burst] = AudioSynth.Burst(); clips[SfxId.Click] = AudioSynth.Click();
                clips[SfxId.GameOver] = AudioSynth.GameOver(); clips[SfxId.Milestone] = AudioSynth.Milestone();
                clips[SfxId.Splash] = AudioSynth.Splash(); clips[SfxId.Gulal] = AudioSynth.Gulal();
                music.clip = AudioSynth.Music();
            }
            catch (System.Exception e) { Debug.LogWarning("[TokyoNightRun] Audio generation failed: " + e.Message); }
            ApplyVolumes();
        }

        public void ApplyVolumes()
        {
            var d = SaveManager.Data;
            music.volume = d.musicVolume * (ducked ? 0.35f : 1f);
            sfx.volume = d.sfxVolume;
        }

        public static void Play(SfxId id)
        {
            var m = Instance;
            AudioClip c;
            if (m.clips.TryGetValue(id, out c) && c != null) m.sfx.PlayOneShot(c, 1f);
        }

        public static void PlayMusic()
        {
            var m = Instance;
            if (m.music.clip != null && !m.music.isPlaying) m.music.Play();
        }

        public static void SetDucked(bool ducked)
        {
            var m = Instance;
            m.ducked = ducked;
            m.ApplyVolumes();
        }

        public static void Vibrate()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            if (SaveManager.Data.vibration) Handheld.Vibrate();
#endif
        }
    }
}
