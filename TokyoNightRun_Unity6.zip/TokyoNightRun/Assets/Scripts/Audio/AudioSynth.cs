using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Generates every sound effect and the festival music loop from maths at start-up,
    /// so the game has audio without any audio files. Drop real clips into AudioManager later if you like.
    /// </summary>
    public static class AudioSynth
    {
        const int SR = 22050;

        static AudioClip Make(string name, float[] d, bool loop = false)
        {
            var c = AudioClip.Create(name, d.Length, 1, SR, false);
            c.SetData(d, 0);
            return c;
        }

        static void AddTone(float[] d, float start, float freq, float freq2, float dur, float vol, float harmonic = 0.3f)
        {
            int i0 = (int)(start * SR), n = (int)(dur * SR);
            float phase = 0f;
            for (int i = 0; i < n && i0 + i < d.Length; i++)
            {
                float t = i / (float)n;
                float f = Mathf.Lerp(freq, freq2, t);
                phase += 2f * Mathf.PI * f / SR;
                float env = Mathf.Min(1f, i / (SR * 0.005f)) * Mathf.Exp(-3.5f * t);
                d[i0 + i] += (Mathf.Sin(phase) + harmonic * Mathf.Sin(phase * 2f)) * env * vol;
            }
        }

        static void AddNoise(float[] d, float start, float dur, float vol, System.Random rng, float lowpass)
        {
            int i0 = (int)(start * SR), n = (int)(dur * SR);
            float prev = 0f;
            for (int i = 0; i < n && i0 + i < d.Length; i++)
            {
                float t = i / (float)n;
                float r = (float)(rng.NextDouble() * 2 - 1);
                prev = Mathf.Lerp(prev, r, lowpass);
                d[i0 + i] += prev * Mathf.Exp(-4f * t) * vol;
            }
        }

        static float[] Buf(float seconds) { return new float[(int)(seconds * SR)]; }

        public static AudioClip Coin() { var d = Buf(0.25f); AddTone(d, 0f, 988f, 988f, 0.08f, 0.4f); AddTone(d, 0.07f, 1318f, 1318f, 0.18f, 0.4f); return Make("coin", d); }
        public static AudioClip Jump() { var d = Buf(0.28f); AddTone(d, 0f, 280f, 640f, 0.25f, 0.45f, 0.1f); return Make("jump", d); }
        public static AudioClip Slide() { var d = Buf(0.35f); AddNoise(d, 0f, 0.33f, 0.35f, new System.Random(3), 0.25f); return Make("slide", d); }
        public static AudioClip Land() { var d = Buf(0.15f); AddTone(d, 0f, 140f, 60f, 0.14f, 0.5f, 0f); return Make("land", d); }
        public static AudioClip Hit() { var d = Buf(0.5f); AddNoise(d, 0f, 0.45f, 0.7f, new System.Random(5), 0.5f); AddTone(d, 0f, 120f, 40f, 0.45f, 0.6f, 0f); return Make("hit", d); }
        public static AudioClip PowerUp() { var d = Buf(0.5f); float[] n = { 523f, 659f, 784f, 1047f }; for (int i = 0; i < 4; i++) AddTone(d, i * 0.09f, n[i], n[i], 0.2f, 0.35f); return Make("powerup", d); }
        public static AudioClip Burst() { var d = Buf(0.9f); AddNoise(d, 0f, 0.6f, 0.4f, new System.Random(9), 0.3f); float[] n = { 392f, 523f, 659f, 784f, 1047f }; for (int i = 0; i < 5; i++) AddTone(d, i * 0.07f, n[i], n[i], 0.4f, 0.3f); return Make("burst", d); }
        public static AudioClip Click() { var d = Buf(0.08f); AddTone(d, 0f, 700f, 500f, 0.07f, 0.35f, 0f); return Make("click", d); }
        public static AudioClip GameOver() { var d = Buf(1.0f); float[] n = { 392f, 330f, 262f, 196f }; for (int i = 0; i < 4; i++) AddTone(d, i * 0.2f, n[i], n[i] * 0.97f, 0.35f, 0.4f); return Make("gameover", d); }
        public static AudioClip Milestone() { var d = Buf(0.8f); float[] n = { 523f, 659f, 784f, 1047f, 784f, 1047f }; for (int i = 0; i < 6; i++) AddTone(d, i * 0.1f, n[i], n[i], 0.25f, 0.35f); return Make("milestone", d); }
        public static AudioClip Splash() { var d = Buf(0.4f); AddNoise(d, 0f, 0.38f, 0.5f, new System.Random(11), 0.6f); return Make("splash", d); }
        public static AudioClip Gulal() { var d = Buf(0.3f); AddNoise(d, 0f, 0.25f, 0.25f, new System.Random(13), 0.15f); AddTone(d, 0f, 600f, 900f, 0.15f, 0.25f); return Make("gulal", d); }

        /// <summary>8-second looping festival tune: pentatonic melody, dhol-style drum and a drone.</summary>
        public static AudioClip Music()
        {
            switch (Theme.Current.Music)
            {
                case MusicStyle.UrbanFunk: return Groove("city_funk", 112f, 220f, new[] { 0, 3, 5, 7, 5, 3, 0, -99, 7, 10, 7, 5, 3, 5, 0, -99, 0, 3, 7, 10, 12, 10, 7, 5, 3, 0, 3, 5, 3, 0, -99, -99 }, 55f, 0.5f);
                case MusicStyle.Jingle: return Bells();
                case MusicStyle.CityPop: return Synthwave();
                case MusicStyle.Tropical: return Groove("tropical", 108f, 330f, new[] { 0, 4, 7, 12, 7, 4, 7, -99, 9, 7, 4, 0, 4, 7, 9, -99, 12, 9, 7, 4, 7, 9, 12, 14, 12, 9, 7, 4, 2, 4, 0, -99 }, 65f, 0.2f);
            }
            return Festival();
        }

        /// <summary>Beat-driven loop: melody (semitones above 'root' Hz), kick, snare noise, hat and a bass note per bar.</summary>
        static AudioClip Groove(string name, float bpm, float root, int[] mel, float bass, float harmonic)
        {
            float beat = 60f / bpm; int beats = 16;
            var d = Buf(beat * beats);
            var rng = new System.Random(31);
            for (int i = 0; i < mel.Length; i++)
            {
                if (mel[i] < -50) continue;
                float f = root * Mathf.Pow(2f, mel[i] / 12f);
                AddTone(d, i * beat * 0.5f, f, f, beat * 0.42f, 0.15f, harmonic);
            }
            for (int b = 0; b < beats; b++)
            {
                if (b % 4 == 0 || b % 4 == 2) AddTone(d, b * beat, 110f, 45f, 0.2f, 0.45f, 0f);          // kick
                if (b % 4 == 1 || b % 4 == 3) AddNoise(d, b * beat, 0.12f, 0.3f, rng, 0.5f);              // snare
                AddNoise(d, b * beat + beat * 0.5f, 0.04f, 0.12f, rng, 0.95f);                             // hat
                if (b % 2 == 0) AddTone(d, b * beat, bass * (b % 8 < 4 ? 1f : 1.33f), bass * (b % 8 < 4 ? 1f : 1.33f), beat * 0.9f, 0.22f, 0.4f); // bass
            }
            for (int i = 0; i < d.Length; i++) d[i] = Mathf.Clamp(d[i], -0.95f, 0.95f);
            return Make(name, d, true);
        }

        /// <summary>Sleigh-bell holiday loop: bright bell melody, shaker on every beat and a warm pad.</summary>
        static AudioClip Bells()
        {
            float bpm = 126f, beat = 60f / bpm; int beats = 16;
            var d = Buf(beat * beats);
            var rng = new System.Random(5);
            int[] mel = { 7, 7, 7, -99, 7, 7, 7, -99, 7, 12, 3, 5, 7, -99, -99, -99, 8, 8, 8, 8, 8, 7, 7, 7, 7, 5, 5, 7, 5, -99, 12, -99 };
            for (int i = 0; i < mel.Length; i++)
            {
                if (mel[i] < -50) continue;
                float f = 392f * Mathf.Pow(2f, mel[i] / 12f);
                AddTone(d, i * beat * 0.5f, f, f, beat * 0.5f, 0.14f, 0.9f);        // bell: strong 2nd harmonic
                AddTone(d, i * beat * 0.5f, f * 2.76f, f * 2.76f, beat * 0.25f, 0.04f, 0f);
            }
            for (int b = 0; b < beats; b++)
            {
                AddNoise(d, b * beat, 0.05f, 0.14f, rng, 0.98f);
                AddNoise(d, b * beat + beat * 0.5f, 0.05f, 0.1f, rng, 0.98f);
                if (b % 4 == 0) AddTone(d, b * beat, 98f, 70f, 0.25f, 0.3f, 0f);
            }
            for (int i = 0; i < d.Length; i++)
            {
                float t = i / (float)SR;
                d[i] += (Mathf.Sin(2f * Mathf.PI * 196f * t) + Mathf.Sin(2f * Mathf.PI * 246.9f * t)) * 0.025f;
                d[i] = Mathf.Clamp(d[i], -0.95f, 0.95f);
            }
            return Make("holiday_bells", d, true);
        }

        /// <summary>Night-city synth loop: arpeggiated minor chords, gated bass and a light four-on-the-floor kick.</summary>
        static AudioClip Synthwave()
        {
            float bpm = 100f, beat = 60f / bpm; int beats = 16;
            var d = Buf(beat * beats);
            var rng = new System.Random(8);
            int[][] chords = { new[] { 0, 3, 7, 10 }, new[] { -4, 0, 3, 7 }, new[] { -2, 2, 5, 9 }, new[] { -5, -2, 2, 5 } };
            for (int step = 0; step < beats * 2; step++)
            {
                var ch = chords[(step / 8) % 4];
                float f = 220f * Mathf.Pow(2f, ch[step % 4] / 12f) * (step % 8 >= 4 ? 2f : 1f);
                AddTone(d, step * beat * 0.5f, f, f, beat * 0.45f, 0.12f, 0.6f);
            }
            for (int b = 0; b < beats; b++)
            {
                AddTone(d, b * beat, 100f, 42f, 0.2f, 0.4f, 0f);
                if (b % 2 == 1) AddNoise(d, b * beat, 0.14f, 0.28f, rng, 0.4f);
                AddNoise(d, b * beat + beat * 0.5f, 0.04f, 0.1f, rng, 0.95f);
                var ch = chords[(b / 4) % 4];
                float bf = 55f * Mathf.Pow(2f, ch[0] / 12f);
                AddTone(d, b * beat, bf, bf, beat * 0.8f, 0.25f, 0.5f);
            }
            for (int i = 0; i < d.Length; i++) d[i] = Mathf.Clamp(d[i], -0.95f, 0.95f);
            return Make("neon_night", d, true);
        }

        static AudioClip Festival()
        {
            float bpm = 120f, beat = 60f / bpm;
            int beats = 16;
            var d = Buf(beat * beats);
            var rng = new System.Random(21);
            // semitone offsets above D4 (Bhoopali-like pentatonic); -99 = rest
            int[] mel = { 0, 4, 7, 9, 7, 4, 2, 0, 4, 7, 12, 9, 7, 4, 7, -99, 9, 12, 9, 7, 4, 7, 2, 0, 2, 4, 7, 4, 2, 0, 0, -99 };
            for (int i = 0; i < mel.Length; i++)
            {
                if (mel[i] < -50) continue;
                float f = 293.66f * Mathf.Pow(2f, mel[i] / 12f);
                AddTone(d, i * beat * 0.5f, f, f, beat * 0.45f, 0.16f, 0.5f);
            }
            for (int b = 0; b < beats; b++)
            {
                AddTone(d, b * beat, 95f, 45f, 0.2f, 0.45f, 0f);                 // dhol thump
                AddNoise(d, b * beat + beat * 0.5f, 0.06f, 0.18f, rng, 0.9f);     // shaker
                if (b % 2 == 1) AddTone(d, b * beat, 190f, 120f, 0.1f, 0.2f, 0f); // tabla-ish
            }
            for (int i = 0; i < d.Length; i++) // drone + soft limiter
            {
                float t = i / (float)SR;
                d[i] += Mathf.Sin(2f * Mathf.PI * 146.83f * t) * 0.05f;
                d[i] = Mathf.Clamp(d[i], -0.95f, 0.95f);
            }
            return Make("festival_music", d, true);
        }
    }
}
