using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>Third-person chase camera with smooth lane following, speed FOV and trauma-based shake.</summary>
    public class CameraFollow : MonoBehaviour
    {
        public Transform Target;
        public Vector3 Offset = new Vector3(0f, 4.3f, -7.4f);
        public float LookAhead = 6f;
        public float BaseFov = 62f;

        Camera cam;
        float trauma;
        Vector3 smoothed;
        bool first = true;

        void Awake() { cam = GetComponent<Camera>(); }

        public void Shake(float amount) { trauma = Mathf.Clamp01(Mathf.Max(trauma, amount)); }

        public void Snap() { first = true; }

        void LateUpdate()
        {
            if (Target == null) return;
            float dt = Time.deltaTime;
            Vector3 p = Target.position;
            Vector3 desired = new Vector3(p.x * 0.65f, Offset.y + p.y * 0.4f, p.z + Offset.z);
            if (first) { smoothed = desired; first = false; }
            float k = 1f - Mathf.Exp(-10f * dt);
            smoothed.x = Mathf.Lerp(smoothed.x, desired.x, k);
            smoothed.y = Mathf.Lerp(smoothed.y, desired.y, k);
            smoothed.z = desired.z; // never lag behind in the running direction

            Vector3 pos = smoothed;
            trauma = Mathf.MoveTowards(trauma, 0f, dt * 1.8f);
            if (trauma > 0f)
            {
                float s = trauma * trauma * 0.6f;
                float t = Time.time * 25f;
                pos += new Vector3(Mathf.PerlinNoise(t, 0f) - 0.5f, Mathf.PerlinNoise(0f, t) - 0.5f, 0f) * 2f * s;
            }
            transform.position = pos;
            Vector3 look = new Vector3(p.x * 0.3f, 1.2f, p.z + LookAhead);
            transform.rotation = Quaternion.LookRotation(look - pos, Vector3.up);

            if (cam != null)
            {
                float fov = BaseFov;
                var gm = GameManager.Instance;
                if (gm != null)
                {
                    fov += gm.Difficulty01 * 6f;
                    if (gm.Powerups != null && gm.Powerups.BoostActive) fov += 8f;
                }
                cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, fov, 1f - Mathf.Exp(-4f * dt));
            }
        }
    }
}
