using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// The signature endless-runner look: the world bends down (and slightly sideways) towards the horizon.
    /// Only the TokyoNightRun/VertexLit world shader reads these globals; colliders are unchanged. Put on the camera.
    /// </summary>
    public class CurvedWorld : MonoBehaviour
    {
        public float Sag = 0.0016f;   // metres of drop per metre^2 (1.6 m at 32 m, 6.4 m at 64 m)
        public float Bend = 0f;
        public bool SwayBend = true;  // slowly swings the bend left/right

        void LateUpdate()
        {
            float bend = SwayBend ? Mathf.Sin(Time.time * 0.15f) * 0.0009f : Bend;
            Shader.SetGlobalVector("_HR_Curve", new Vector4(bend, Sag, 0f, 0f));
            Shader.SetGlobalVector("_HR_Origin", new Vector4(0f, 0f, transform.position.z, 0f));
        }

        void OnDestroy() { Shader.SetGlobalVector("_HR_Curve", Vector4.zero); }
    }
}
