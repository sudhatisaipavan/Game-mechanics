using System.Collections.Generic;
using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>Which hand-built model/animation set a character uses (see CharacterBuilder / CharacterPoses).</summary>
    public enum CharacterStyle { Dhiren, Divya, Trisha, Ulvaan, Sandy }

    public class CharacterDef
    {
        public string Id, Name, Tagline, PartnerId, IconLetter;
        public CharacterStyle Style;
        public int Cost;                  // coin price used when GameConfig.UnlockAllCharactersForTesting is false
        public Color Skin, Hair, HairTip, Jacket, Inner, Pants, Shoes, Sole, Accent, Accent2, Metal, Lips;
        public Color Theme, ThemeDark;    // UI colours / profile icon
        public bool IsCouple { get { return !string.IsNullOrEmpty(PartnerId); } }
    }

    public class OutfitDef
    {
        public string Id, Name;
        public int Cost;
        public Color Kurta;               // jacket/hoodie colour override; alpha 0 means "use the character's own colour"
        public Color Accent;              // accent override; alpha 0 means "keep the character's accent"
        public string[] OnlyFor;          // null = every character, otherwise only these character ids (couple skins)
    }

    public class TrailDef
    {
        public string Id, Name;
        public int Cost;
        public Color Color;
        public bool Rainbow, None;
    }

    /// <summary>
    /// Data for everything that can be unlocked. To add a new character, add one entry to Characters and a model
    /// branch in CharacterBuilder (or drop a prefab into Resources/Characters, see README).
    /// </summary>
    public static class Catalog
    {
        public const string DefaultCharacter = "char_dhiren";
        public const string DefaultOutfit = "outfit_classic";
        public const string DefaultTrail = "trail_none";
        public const string CoupleA = "char_trisha";
        public const string CoupleB = "char_ulvaan";

        static Color H(int rgb) { return GameConfig.Hex(rgb); }

        public static readonly CharacterDef[] Characters =
        {
            // Dhiren: confident streetwear. Black bomber with Holi-gradient trim, white tee, sand tapered trousers, white sneakers.
            new CharacterDef { Id = "char_dhiren", Name = "Dhiren", Style = CharacterStyle.Dhiren, IconLetter = "D", Cost = 0,
                Tagline = "Cool, calm, always first on the platform.",
                Skin = H(0xC68E5E), Hair = H(0x1C1512), HairTip = H(0x3E7BFA), Jacket = H(0x1F232B), Inner = H(0xF4F1EA), Pants = H(0xC9B79C),
                Shoes = H(0xF6F6F4), Sole = H(0xFF6F3C), Accent = H(0xFF4F9A), Accent2 = H(0xFFB300), Metal = H(0xC9CED6), Lips = H(0xA8645A),
                Theme = H(0x3E7BFA), ThemeDark = H(0x16306E) },
            // Divya: glamorous. Violet cropped jacket, cream tee, olive cargos, chunky sneakers, ponytail with magenta tips.
            new CharacterDef { Id = "char_divya", Name = "Divya", Style = CharacterStyle.Divya, IconLetter = "V", Cost = 600,
                Tagline = "Fashion-first, fearless, unstoppable.",
                Skin = H(0xE3B189), Hair = H(0x2A1712), HairTip = H(0xE91E8C), Jacket = H(0x7B3FE4), Inner = H(0xFFF3E0), Pants = H(0xB4A27A),
                Shoes = H(0xFAFAFA), Sole = H(0xFFC107), Accent = H(0xFFC107), Accent2 = H(0xE91E8C), Metal = H(0xFFD76A), Lips = H(0xD6366F),
                Theme = H(0xE91E8C), ThemeDark = H(0x5A0F3F) },
            // Trisha: cute pastel couple look. Pink oversized hoodie with mint details, lavender joggers.
            new CharacterDef { Id = "char_trisha", Name = "Trisha", Style = CharacterStyle.Trisha, IconLetter = "T", Cost = 800, PartnerId = "char_ulvaan",
                Tagline = "Sunshine in sneakers, spreading colour.",
                Skin = H(0xF2CBA3), Hair = H(0x3A2218), HairTip = H(0xFFB3D1), Jacket = H(0xF7B7D2), Inner = H(0xFFFFFF), Pants = H(0xCDBDF2),
                Shoes = H(0xFFFFFF), Sole = H(0xB5EAD7), Accent = H(0xB5EAD7), Accent2 = H(0xFFE29A), Metal = H(0xFFD76A), Lips = H(0xF08AA8),
                Theme = H(0xF48FB1), ThemeDark = H(0x6A2A45) },
            // Ulvaan: Trisha's partner. Mint hoodie with pink details, beige trousers, matching charm and wristband.
            new CharacterDef { Id = "char_ulvaan", Name = "Ulvaan", Style = CharacterStyle.Ulvaan, IconLetter = "U", Cost = 800, PartnerId = "char_trisha",
                Tagline = "Easygoing, loyal, never lets go of her hand.",
                Skin = H(0xD9A878), Hair = H(0x2B1C15), HairTip = H(0x5A3A2A), Jacket = H(0xA8E0CF), Inner = H(0xFFFFFF), Pants = H(0xE0D2B4),
                Shoes = H(0xFFFFFF), Sole = H(0xF7B7D2), Accent = H(0xF7B7D2), Accent2 = H(0xFFE29A), Metal = H(0xFFD76A), Lips = H(0xB87056),
                Theme = H(0x80CBC4), ThemeDark = H(0x1B4A44) },
            // Sandy: unique, loud and layered. Lime puffer vest over charcoal hoodie, black cargos, orange statement sneakers.
            new CharacterDef { Id = "char_sandy", Name = "Sandy", Style = CharacterStyle.Sandy, IconLetter = "S", Cost = 1000,
                Tagline = "Layers, attitude and a backflip for fun.",
                Skin = H(0x8D5A3B), Hair = H(0xF1E7C6), HairTip = H(0xB6FF00), Jacket = H(0xB6FF00), Inner = H(0x30343B), Pants = H(0x23262B),
                Shoes = H(0xFF6D00), Sole = H(0xF4F4F4), Accent = H(0xFF6D00), Accent2 = H(0xFF4F9A), Metal = H(0xBFC5CC), Lips = H(0x7A4330),
                Theme = H(0xB6FF00), ThemeDark = H(0x33440A) },
        };

        public static readonly OutfitDef[] Outfits =
        {
            new OutfitDef { Id = "outfit_classic", Name = "Signature Look", Cost = 0, Kurta = new Color(0, 0, 0, 0), Accent = new Color(0, 0, 0, 0) },
            new OutfitDef { Id = "outfit_saffron", Name = "Saffron Jacket", Cost = 300, Kurta = H(0xFF9933), Accent = new Color(0, 0, 0, 0) },
            new OutfitDef { Id = "outfit_sky", Name = "Sky Blue Jacket", Cost = 300, Kurta = H(0x4FC3F7), Accent = new Color(0, 0, 0, 0) },
            new OutfitDef { Id = "outfit_rani", Name = "Rani Pink Jacket", Cost = 400, Kurta = H(0xE91E8C), Accent = new Color(0, 0, 0, 0) },
            // Couple skins: both partners wear the SAME palette so they look like a matched pair.
            new OutfitDef { Id = "outfit_couple_sunset", Name = "Couple Skin: Sunset Peach", Cost = 400, Kurta = H(0xFFC49B), Accent = H(0xFF8FA3),
                OnlyFor = new[] { "char_trisha", "char_ulvaan" } },
            new OutfitDef { Id = "outfit_couple_ocean", Name = "Couple Skin: Ocean Lilac", Cost = 400, Kurta = H(0xBCA9F5), Accent = H(0x8FE3F0),
                OnlyFor = new[] { "char_trisha", "char_ulvaan" } },
        };

        public static readonly TrailDef[] Trails =
        {
            new TrailDef { Id = "trail_none", Name = "No Trail", Cost = 0, None = true, Color = Color.white },
            new TrailDef { Id = "trail_pink", Name = Theme.Current.TrailNames[0], Cost = 200, Color = H(Theme.Current.TrailColors[0]) },
            new TrailDef { Id = "trail_blue", Name = Theme.Current.TrailNames[1], Cost = 200, Color = H(Theme.Current.TrailColors[1]) },
            new TrailDef { Id = "trail_rainbow", Name = "Rainbow Trail", Cost = 500, Rainbow = true, Color = Color.white },
        };

        public static CharacterDef FindCharacter(string id)
        {
            for (int i = 0; i < Characters.Length; i++) if (Characters[i].Id == id) return Characters[i];
            return Characters[0];
        }

        public static OutfitDef FindOutfit(string id)
        {
            for (int i = 0; i < Outfits.Length; i++) if (Outfits[i].Id == id) return Outfits[i];
            return Outfits[0];
        }

        public static TrailDef FindTrail(string id)
        {
            for (int i = 0; i < Trails.Length; i++) if (Trails[i].Id == id) return Trails[i];
            return Trails[0];
        }

        public static bool IsCharacterId(string id)
        {
            for (int i = 0; i < Characters.Length; i++) if (Characters[i].Id == id) return true;
            return false;
        }

        /// <summary>Returns the coin cost for any item id, or -1 if the id is unknown.</summary>
        public static int CostOf(string id)
        {
            if (string.IsNullOrEmpty(id)) return -1;
            for (int i = 0; i < Characters.Length; i++) if (Characters[i].Id == id) return Characters[i].Cost;
            for (int i = 0; i < Outfits.Length; i++) if (Outfits[i].Id == id) return Outfits[i].Cost;
            for (int i = 0; i < Trails.Length; i++) if (Trails[i].Id == id) return Trails[i].Cost;
            return -1;
        }

        public static bool OutfitAllowed(OutfitDef o, string characterId)
        {
            if (o == null || o.OnlyFor == null) return true;
            for (int i = 0; i < o.OnlyFor.Length; i++) if (o.OnlyFor[i] == characterId) return true;
            return false;
        }

        /// <summary>The outfit that is really worn: a couple skin on a non-couple character falls back to the signature look.</summary>
        public static OutfitDef EffectiveOutfit(CharacterDef c, OutfitDef o)
        {
            return (o != null && OutfitAllowed(o, c.Id)) ? o : Outfits[0];
        }

        /// <summary>Jacket / hoodie colour after applying the outfit on top of the character.</summary>
        public static Color JacketColor(CharacterDef c, OutfitDef o)
        {
            o = EffectiveOutfit(c, o);
            return o.Kurta.a > 0.5f ? o.Kurta : c.Jacket;
        }

        public static Color AccentColor(CharacterDef c, OutfitDef o)
        {
            o = EffectiveOutfit(c, o);
            return o.Accent.a > 0.5f ? o.Accent : c.Accent;
        }
    }
}
