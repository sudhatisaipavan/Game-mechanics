using System.Collections.Generic;
using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Builds a complete skinned 3D humanoid for a character: a 19-21 bone skeleton, one SkinnedMeshRenderer with smooth
    /// limb skinning, face (eyes, brows, nose, mouth, ears), hair, layered outfit, shoes and accessories, plus generated
    /// textures and materials. If Resources/Characters/&lt;id&gt; contains an imported prefab it is used instead.
    /// </summary>
    public static class CharacterBuilder
    {
        public static RunnerVisual Build(CharacterDef c, OutfitDef outfit)
        {
            outfit = Catalog.EffectiveOutfit(c, outfit);
            var prefab = Resources.Load<GameObject>("Characters/" + c.Id);
            RunnerVisual rv = prefab != null ? BuildExternal(c, prefab) : new Gen(c, outfit).Make();
            AddExtras(rv);
            return rv;
        }

        static RunnerVisual BuildExternal(CharacterDef c, GameObject prefab)
        {
            var root = new GameObject("Runner_" + c.Name);
            var rv = root.AddComponent<RunnerVisual>();
            var inst = Object.Instantiate(prefab);
            inst.transform.SetParent(root.transform, false);
            rv.Body = inst.transform;
            rv.Style = c.Style;
            rv.ExternalAnimator = inst.GetComponentInChildren<Animator>();
            return rv;
        }

        static void AddExtras(RunnerVisual rv)
        {
            // colour shield bubble (hidden until the power-up is active)
            var bubble = ProceduralFactory.Prim(rv.transform, PrimitiveType.Sphere, new Vector3(0, 0.95f, 0), Vector3.one * 2.3f, new Color(0.3f, 1f, 0.5f, 0.28f), "ShieldBubble");
            bubble.GetComponent<MeshRenderer>().sharedMaterial = MaterialLibrary.Alpha(new Color(0.3f, 1f, 0.5f, 0.28f));
            bubble.SetActive(false);
            rv.ShieldBubble = bubble;
            // soft ground shadow
            var sh = new GameObject("BlobShadow");
            sh.transform.SetParent(rv.transform, false);
            var mesh = new Mesh();
            mesh.vertices = new[] { new Vector3(-0.6f, 0, -0.6f), new Vector3(-0.6f, 0, 0.6f), new Vector3(0.6f, 0, -0.6f), new Vector3(0.6f, 0, 0.6f) };
            mesh.uv = new[] { new Vector2(0, 0), new Vector2(0, 1), new Vector2(1, 0), new Vector2(1, 1) };
            mesh.triangles = new[] { 0, 1, 2, 1, 3, 2 };
            mesh.normals = new[] { Vector3.up, Vector3.up, Vector3.up, Vector3.up };
            sh.AddComponent<MeshFilter>().sharedMesh = mesh;
            var r = sh.AddComponent<MeshRenderer>();
            r.sharedMaterial = MaterialLibrary.Shadow();
            r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            r.receiveShadows = false;
            sh.AddComponent<BlobShadow>().Follow = rv.transform;
        }

        // ====================================================================================================
        class Gen
        {
            readonly CharacterDef c;
            readonly OutfitDef outfit;
            readonly Color jacketCol, accentCol;
            readonly SkinBuilder sb = new SkinBuilder();
            readonly Transform[] bones = new Transform[(int)BoneId.Count];
            readonly Vector3[] wp = new Vector3[(int)BoneId.Count];
            readonly int[] idx = new int[(int)BoneId.Count];
            Transform armature;

            // proportions
            float hipH, torso, shoulderW, pelvisR, waistR, chestR, headS, armR, legR, hipW;
            float legTop, kneeY, ankleY = 0.085f, neckY, shoulderY, elbowY, wristY, thigh, shin, upperArm, foreArm;
            Vector3 hc, hr; // head centre / radii

            public Gen(CharacterDef def, OutfitDef o)
            {
                c = def; outfit = o;
                jacketCol = Catalog.JacketColor(def, o);
                accentCol = Catalog.AccentColor(def, o);
            }

            // ------------------------------------------------------------ helpers
            static float Interp(float[] xs, float[] ys, float x)
            {
                if (x <= xs[0]) return ys[0];
                for (int i = 1; i < xs.Length; i++)
                    if (x <= xs[i]) return Mathf.Lerp(ys[i - 1], ys[i], Mathf.InverseLerp(xs[i - 1], xs[i], x));
                return ys[ys.Length - 1];
            }

            int I(BoneId b) { return idx[(int)b]; }
            BoneWeight W(BoneId b) { return SkinBuilder.W(I(b)); }
            BoneWeight W(BoneId a, BoneId b, float t) { return SkinBuilder.W(I(a), I(b), t); }

            void E(Vector3 centre, Vector3 radii, Slot slot, BoneId bone, float pitch = 0, float yaw = 0, float roll = 0, int lon = 12, int lat = 8)
            { sb.Ellipsoid(centre, radii, Quaternion.Euler(pitch, yaw, roll), slot, W(bone), lon, lat); }

            void Tor(Vector3 centre, float major, float minor, Slot slot, BoneWeight w, float pitch = 0, float yaw = 0, float roll = 0, int seg = 18)
            { sb.Torus(centre, major, minor, Quaternion.Euler(pitch, yaw, roll), slot, w, seg, 6); }

            void Bx(Vector3 centre, Vector3 size, Slot slot, BoneId bone, float pitch = 0, float yaw = 0, float roll = 0)
            { sb.Box(centre, size, Quaternion.Euler(pitch, yaw, roll), slot, W(bone)); }

            Transform Mk(BoneId id, int parent, Vector3 world)
            {
                var g = new GameObject(id.ToString());
                Transform par = parent < 0 ? armature : bones[parent];
                Vector3 pw = parent < 0 ? Vector3.zero : wp[parent];
                g.transform.SetParent(par, false);
                g.transform.localPosition = world - pw;
                bones[(int)id] = g.transform;
                wp[(int)id] = world;
                return g.transform;
            }

            // ------------------------------------------------------------ main entry
            public RunnerVisual Make()
            {
                SetProportions();
                var root = new GameObject("Runner_" + c.Name);
                var rv = root.AddComponent<RunnerVisual>();
                rv.Style = c.Style;
                armature = new GameObject("Armature").transform;
                armature.SetParent(root.transform, false);
                rv.Body = armature;

                BuildSkeleton();
                for (int i = 0; i < bones.Length; i++) idx[i] = bones[i] != null ? sb.AddBone(bones[i]) : -1;
                if (idx[(int)BoneId.Tail1] < 0) { idx[(int)BoneId.Tail1] = I(BoneId.Head); idx[(int)BoneId.Tail2] = I(BoneId.Head); }

                BuildBody();
                Face();
                Hands();
                switch (c.Style)
                {
                    case CharacterStyle.Dhiren: Dhiren(); break;
                    case CharacterStyle.Divya: Divya(); break;
                    case CharacterStyle.Trisha: Trisha(); break;
                    case CharacterStyle.Ulvaan: Ulvaan(); break;
                    default: Sandy(); break;
                }

                var smrGo = new GameObject("Body");
                smrGo.transform.SetParent(root.transform, false);
                var used = new List<Slot>();
                Mesh mesh = sb.Build(smrGo.transform, used, c.Name + "_Mesh");
                var smr = smrGo.AddComponent<SkinnedMeshRenderer>();
                smr.sharedMesh = mesh;
                smr.bones = sb.Bones.ToArray();
                smr.rootBone = bones[(int)BoneId.Hips];
                var mats = new Material[used.Count];
                for (int i = 0; i < mats.Length; i++) mats[i] = Mat(used[i]);
                smr.sharedMaterials = mats;
                smr.updateWhenOffscreen = true; // safe with flips and slides; one character only
                smr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
                smr.receiveShadows = false;

                for (int i = 0; i < bones.Length; i++) rv.Bones[i] = bones[i];
                rv.HipH = hipH;
                rv.HipsBind = bones[(int)BoneId.Hips].localPosition;
                return rv;
            }

            // ------------------------------------------------------------ proportions & skeleton
            void SetProportions()
            {
                switch (c.Style)
                {
                    case CharacterStyle.Dhiren: hipH = 0.96f; torso = 0.53f; shoulderW = 0.215f; pelvisR = 0.135f; waistR = 0.12f; chestR = 0.16f; headS = 1.0f; armR = 0.05f; legR = 0.092f; hipW = 0.095f; break;
                    case CharacterStyle.Divya: hipH = 0.93f; torso = 0.47f; shoulderW = 0.175f; pelvisR = 0.138f; waistR = 0.095f; chestR = 0.13f; headS = 0.98f; armR = 0.043f; legR = 0.088f; hipW = 0.095f; break;
                    case CharacterStyle.Trisha: hipH = 0.86f; torso = 0.45f; shoulderW = 0.17f; pelvisR = 0.13f; waistR = 0.105f; chestR = 0.13f; headS = 1.1f; armR = 0.042f; legR = 0.085f; hipW = 0.09f; break;
                    case CharacterStyle.Ulvaan: hipH = 0.95f; torso = 0.52f; shoulderW = 0.2f; pelvisR = 0.13f; waistR = 0.115f; chestR = 0.15f; headS = 1.0f; armR = 0.047f; legR = 0.09f; hipW = 0.092f; break;
                    default: hipH = 1.0f; torso = 0.55f; shoulderW = 0.235f; pelvisR = 0.14f; waistR = 0.125f; chestR = 0.17f; headS = 1.0f; armR = 0.053f; legR = 0.095f; hipW = 0.1f; break;
                }
                legTop = hipH - 0.05f;
                thigh = (legTop - ankleY) * 0.52f;
                shin = (legTop - ankleY) * 0.48f;
                kneeY = legTop - thigh;
                neckY = hipH + torso;
                shoulderY = neckY - 0.07f;
                upperArm = 0.29f; foreArm = 0.27f;
                if (c.Style == CharacterStyle.Trisha || c.Style == CharacterStyle.Divya) { upperArm = 0.265f; foreArm = 0.25f; }
                if (c.Style == CharacterStyle.Sandy) { upperArm = 0.31f; foreArm = 0.285f; }
                elbowY = shoulderY - upperArm;
                wristY = elbowY - foreArm;
                hc = new Vector3(0f, neckY + 0.08f + 0.095f * headS, 0.012f);
                hr = new Vector3(0.095f, 0.115f, 0.105f) * headS;
            }

            void BuildSkeleton()
            {
                Mk(BoneId.Hips, -1, new Vector3(0, hipH, 0));
                Mk(BoneId.Spine, (int)BoneId.Hips, new Vector3(0, hipH + torso * 0.28f, 0));
                Mk(BoneId.Chest, (int)BoneId.Spine, new Vector3(0, hipH + torso * 0.60f, 0));
                Mk(BoneId.Neck, (int)BoneId.Chest, new Vector3(0, neckY, 0));
                Mk(BoneId.Head, (int)BoneId.Neck, new Vector3(0, neckY + 0.08f, 0));
                for (int s = -1; s <= 1; s += 2)
                {
                    bool left = s < 0;
                    Mk(left ? BoneId.ClavL : BoneId.ClavR, (int)BoneId.Chest, new Vector3(s * 0.045f, neckY - 0.05f, 0));
                    Mk(left ? BoneId.ArmL : BoneId.ArmR, left ? (int)BoneId.ClavL : (int)BoneId.ClavR, new Vector3(s * shoulderW, shoulderY, 0));
                    Mk(left ? BoneId.ForeL : BoneId.ForeR, left ? (int)BoneId.ArmL : (int)BoneId.ArmR, new Vector3(s * (shoulderW + 0.005f), elbowY, 0));
                    Mk(left ? BoneId.HandL : BoneId.HandR, left ? (int)BoneId.ForeL : (int)BoneId.ForeR, new Vector3(s * (shoulderW + 0.01f), wristY, 0));
                    Mk(left ? BoneId.LegL : BoneId.LegR, (int)BoneId.Hips, new Vector3(s * hipW, legTop, 0));
                    Mk(left ? BoneId.ShinL : BoneId.ShinR, left ? (int)BoneId.LegL : (int)BoneId.LegR, new Vector3(s * (hipW + 0.005f), kneeY, 0));
                    Mk(left ? BoneId.FootL : BoneId.FootR, left ? (int)BoneId.ShinL : (int)BoneId.ShinR, new Vector3(s * (hipW + 0.008f), ankleY, 0));
                }
                if (c.Style == CharacterStyle.Divya) // ponytail
                {
                    Mk(BoneId.Tail1, (int)BoneId.Head, new Vector3(0, hc.y + 0.085f * headS, hc.z - 0.115f * headS));
                    Mk(BoneId.Tail2, (int)BoneId.Tail1, new Vector3(0, hc.y + 0.085f * headS - 0.19f, hc.z - 0.135f * headS));
                }
                else if (c.Style == CharacterStyle.Sandy) // bandana tails
                {
                    Mk(BoneId.Tail1, (int)BoneId.Chest, new Vector3(0, neckY + 0.01f, -0.075f));
                    Mk(BoneId.Tail2, (int)BoneId.Tail1, new Vector3(0, neckY - 0.11f, -0.095f));
                }
            }

            // ------------------------------------------------------------ weights
            BoneWeight TW(float y)
            {
                float y0 = hipH + 0.04f, y1 = wp[(int)BoneId.Spine].y, y2 = wp[(int)BoneId.Chest].y;
                if (y <= y0) return W(BoneId.Hips);
                if (y <= y1) return W(BoneId.Hips, BoneId.Spine, Mathf.InverseLerp(y0, y1, y));
                if (y <= y2) return W(BoneId.Spine, BoneId.Chest, Mathf.InverseLerp(y1, y2, y));
                return W(BoneId.Chest);
            }

            BoneWeight LegW(int side, float y)
            {
                BoneId leg = side < 0 ? BoneId.LegL : BoneId.LegR, sh = side < 0 ? BoneId.ShinL : BoneId.ShinR, ft = side < 0 ? BoneId.FootL : BoneId.FootR;
                if (y >= legTop - 0.01f) return W(BoneId.Hips, leg, 0.6f);
                if (y > kneeY + 0.07f) return W(leg);
                if (y > kneeY - 0.07f) return W(leg, sh, (kneeY + 0.07f - y) / 0.14f);
                if (y > ankleY + 0.05f) return W(sh);
                if (y > ankleY) return W(sh, ft, (ankleY + 0.05f - y) / 0.05f);
                return W(ft);
            }

            BoneWeight ArmW(int side, float y)
            {
                BoneId arm = side < 0 ? BoneId.ArmL : BoneId.ArmR, fo = side < 0 ? BoneId.ForeL : BoneId.ForeR, hd = side < 0 ? BoneId.HandL : BoneId.HandR;
                if (y >= shoulderY - 0.01f) return W(BoneId.Chest, arm, 0.6f);
                if (y > elbowY + 0.06f) return W(arm);
                if (y > elbowY - 0.06f) return W(arm, fo, (elbowY + 0.06f - y) / 0.12f);
                if (y > wristY + 0.03f) return W(fo);
                if (y > wristY - 0.01f) return W(fo, hd, (wristY + 0.03f - y) / 0.04f);
                return W(hd);
            }

            // ------------------------------------------------------------ body shells
            float LegRad(float y) { return Interp(new[] { ankleY, kneeY, legTop }, new[] { 0.042f, 0.062f, legR }, y); }
            float ArmRad(float y) { return Interp(new[] { wristY, elbowY, shoulderY }, new[] { 0.03f, 0.04f, armR }, y); }

            void TorsoRad(float y, out float rx, out float rz)
            {
                float[] ys = { hipH - 0.11f, hipH - 0.02f, hipH + 0.10f, hipH + 0.22f, hipH + 0.34f, hipH + 0.44f, neckY };
                float[] rxs = { pelvisR * 0.92f, pelvisR, waistR, (waistR + chestR) * 0.5f, chestR, shoulderW * 0.92f, 0.075f };
                float[] rzf = { 0.70f, 0.70f, 0.68f, 0.66f, 0.62f, 0.50f, 0.95f };
                rx = Interp(ys, rxs, y);
                rz = rx * Interp(ys, rzf, y);
            }

            public float TorsoFront(float y, float add) { float rx, rz; TorsoRad(y, out rx, out rz); return rz + add; }

            void TorsoShell(Slot slot, float yBot, float yTop, float addX, float addZ, int rings = 9)
            {
                var y = new float[rings]; var rx = new float[rings]; var rz = new float[rings]; var w = new BoneWeight[rings];
                for (int i = 0; i < rings; i++)
                {
                    y[i] = Mathf.Lerp(yBot, yTop, i / (float)(rings - 1));
                    float a, b; TorsoRad(y[i], out a, out b);
                    rx[i] = a + addX; rz[i] = b + addZ; w[i] = TW(y[i]);
                }
                sb.Lathe(y, rx, rz, 18, Matrix4x4.identity, slot, w, true, true);
            }

            void LegShell(int side, Slot slot, float yTop, float yBot, float mTop, float mKnee, float mAnkle, float add = 0.012f, float zScale = 0.95f)
            {
                int n = 10;
                var y = new float[n]; var rx = new float[n]; var rz = new float[n]; var w = new BoneWeight[n];
                for (int i = 0; i < n; i++)
                {
                    y[i] = Mathf.Lerp(yTop, yBot, i / (float)(n - 1));
                    float m = Interp(new[] { ankleY, kneeY, legTop }, new[] { mAnkle, mKnee, mTop }, y[i]);
                    float r = LegRad(y[i]) * m + add;
                    rx[i] = r; rz[i] = r * zScale; w[i] = LegW(side, y[i]);
                }
                sb.Lathe(y, rx, rz, 14, Matrix4x4.Translate(new Vector3(side * (hipW + 0.004f), 0, 0)), slot, w, true, true);
            }

            void ArmShell(int side, Slot slot, float yTop, float yBot, float mTop, float mElbow, float mWrist, float add = 0.012f)
            {
                int n = 9;
                var y = new float[n]; var rx = new float[n]; var rz = new float[n]; var w = new BoneWeight[n];
                for (int i = 0; i < n; i++)
                {
                    y[i] = Mathf.Lerp(yTop, yBot, i / (float)(n - 1));
                    float m = Interp(new[] { wristY, elbowY, shoulderY }, new[] { mWrist, mElbow, mTop }, y[i]);
                    float r = ArmRad(y[i]) * m + add;
                    rx[i] = r; rz[i] = r; w[i] = ArmW(side, y[i]);
                }
                sb.Lathe(y, rx, rz, 12, Matrix4x4.Translate(new Vector3(side * (shoulderW + 0.004f), 0, 0)), slot, w, true, true);
            }

            /// <summary>A short ring around a limb (cuff, band, bracelet) at height y.</summary>
            void ArmBand(int side, Slot slot, float y, float height, float add)
            {
                var yy = new[] { y + height * 0.5f, y - height * 0.5f };
                float r = ArmRad(y) + add;
                var w = new[] { ArmW(side, yy[0]), ArmW(side, yy[1]) };
                sb.Lathe(yy, new[] { r, r }, new[] { r, r }, 12, Matrix4x4.Translate(new Vector3(side * (shoulderW + 0.004f), 0, 0)), slot, w, true, true);
            }

            void LegBand(int side, Slot slot, float y, float height, float add)
            {
                var yy = new[] { y + height * 0.5f, y - height * 0.5f };
                float r = LegRad(y) + add;
                var w = new[] { LegW(side, yy[0]), LegW(side, yy[1]) };
                sb.Lathe(yy, new[] { r, r }, new[] { r * 0.95f, r * 0.95f }, 14, Matrix4x4.Translate(new Vector3(side * (hipW + 0.004f), 0, 0)), slot, w, true, true);
            }

            void BuildBody()
            {
                // neck: skin tube from the chest up into the head
                var y = new[] { neckY - 0.04f, neckY + 0.03f, neckY + 0.1f };
                var w = new[] { W(BoneId.Chest), W(BoneId.Neck), W(BoneId.Head) };
                sb.Lathe(y, new[] { 0.052f, 0.045f, 0.044f }, new[] { 0.05f, 0.043f, 0.043f }, 12, Matrix4x4.identity, Slot.Skin, w, false, false);
                // shoes and ankle sock line
                Shoe(-1); Shoe(1);
            }

            void Shoe(int side)
            {
                bool big = c.Style == CharacterStyle.Sandy || c.Style == CharacterStyle.Divya;
                float k = big ? 1.18f : 1f;
                float x = side * (hipW + 0.008f);
                BoneId ft = side < 0 ? BoneId.FootL : BoneId.FootR;
                E(new Vector3(x, 0.026f * k, 0.04f), new Vector3(0.057f, 0.03f * k, 0.138f) * (big ? 1.08f : 1f), Slot.Sole, ft, 0, 0, 0, 12, 8);
                E(new Vector3(x, 0.074f * k, 0.035f), new Vector3(0.053f, 0.05f * k, 0.126f), Slot.Shoes, ft, 0, 0, 0, 12, 8);
                E(new Vector3(x, 0.062f * k, 0.115f), new Vector3(0.05f, 0.04f * k, 0.058f), Slot.Shoes, ft, 0, 0, 0, 10, 7);
                E(new Vector3(x, 0.09f * k, -0.03f), new Vector3(0.046f, 0.05f, 0.05f), Slot.Shoes, ft, 0, 0, 0, 10, 7);
                E(new Vector3(x, 0.118f * k, 0.065f), new Vector3(0.026f, 0.013f, 0.05f), Slot.Accent, ft, -22, 0, 0, 8, 6); // laces / tongue
                E(new Vector3(x, 0.05f * k, -0.06f), new Vector3(0.048f, 0.022f, 0.03f), Slot.Accent2, ft, 0, 0, 0, 8, 6); // heel tab
            }

            void Hands()
            {
                for (int s = -1; s <= 1; s += 2)
                {
                    BoneId h = s < 0 ? BoneId.HandL : BoneId.HandR;
                    float x = s * (shoulderW + 0.01f);
                    Slot slot = (c.Style == CharacterStyle.Sandy) ? Slot.Dark : Slot.Skin; // fingerless gloves for Sandy
                    E(new Vector3(x, wristY - 0.07f, 0.004f), new Vector3(0.036f, 0.065f, 0.022f), slot, h, 0, 0, 0, 10, 8);
                    E(new Vector3(x - s * 0.03f, wristY - 0.05f, 0.02f), new Vector3(0.012f, 0.032f, 0.012f), Slot.Skin, h, 15, 0, s * -15f, 8, 6);
                    if (c.Style == CharacterStyle.Sandy) E(new Vector3(x, wristY - 0.125f, 0.004f), new Vector3(0.03f, 0.03f, 0.016f), Slot.Skin, h, 0, 0, 0, 8, 6);
                }
            }

            // ------------------------------------------------------------ face
            float HZ(float dx, float dy)
            {
                float k = 1f - (dx * dx) / (hr.x * hr.x) - (dy * dy) / (hr.y * hr.y);
                return hc.z + hr.z * Mathf.Sqrt(Mathf.Max(0.01f, k));
            }

            void Face()
            {
                BoneWeight wh = W(BoneId.Head);
                sb.Ellipsoid(hc, hr, Quaternion.identity, Slot.Skin, wh, 18, 12);
                sb.Ellipsoid(hc + new Vector3(0, -0.055f * headS, 0.012f * headS), new Vector3(0.078f, 0.075f, 0.082f) * headS, Quaternion.identity, Slot.Skin, wh, 14, 9);
                for (int s = -1; s <= 1; s += 2) // ears
                    sb.Ellipsoid(hc + new Vector3(s * hr.x * 0.98f, -0.006f, -0.005f), new Vector3(0.014f, 0.032f, 0.02f) * headS, Quaternion.Euler(0, 0, s * 8f), Slot.Skin, wh, 8, 6);
                float ex = 0.038f * headS, ey = 0.014f * headS;
                if (c.Style == CharacterStyle.Trisha) { ex = 0.04f * headS; ey = 0.006f * headS; } // bigger, lower eyes = cuter
                float eyeScale = c.Style == CharacterStyle.Trisha ? 1.18f : 1f;
                for (int s = -1; s <= 1; s += 2)
                {
                    float z = HZ(s * ex, ey);
                    sb.Ellipsoid(hc + new Vector3(s * ex, ey, 0) + new Vector3(0, 0, z - hc.z - 0.003f), new Vector3(0.021f, 0.016f * eyeScale, 0.011f) * headS, Quaternion.identity, Slot.Eye, wh, 10, 7);
                    sb.Ellipsoid(hc + new Vector3(s * ex, ey, 0) + new Vector3(0, 0, z - hc.z + 0.003f), new Vector3(0.0125f, 0.0125f * eyeScale, 0.006f) * headS, Quaternion.identity, Slot.Dark, wh, 8, 6);
                    float by = ey + 0.034f * headS;
                    sb.Ellipsoid(hc + new Vector3(s * ex, by, HZ(s * ex, by) - hc.z + 0.001f), new Vector3(0.026f, 0.0055f, 0.007f) * headS, Quaternion.Euler(0, 0, s * (c.Style == CharacterStyle.Sandy ? -10f : 7f)), Slot.Hair, wh, 8, 6);
                }
                float ny = -0.015f * headS;
                sb.Ellipsoid(hc + new Vector3(0, ny, HZ(0, ny) - hc.z + 0.012f), new Vector3(0.014f, 0.02f, 0.02f) * headS, Quaternion.identity, Slot.Skin, wh, 8, 6);
                float my = -0.056f * headS;
                sb.Ellipsoid(hc + new Vector3(0, my, HZ(0, my) - hc.z + 0.0f), new Vector3(0.022f, 0.0065f, 0.008f) * headS, Quaternion.identity, Slot.Lips, wh, 8, 6);
                if (c.Style == CharacterStyle.Trisha || c.Style == CharacterStyle.Divya) // blush
                    for (int s = -1; s <= 1; s += 2)
                    {
                        float bx = s * 0.056f * headS, by2 = -0.03f * headS;
                        sb.Ellipsoid(hc + new Vector3(bx, by2, HZ(bx, by2) - hc.z - 0.002f), new Vector3(0.02f, 0.011f, 0.005f) * headS, Quaternion.identity, Slot.Lips, wh, 8, 6);
                    }
            }

            /// <summary>Hair cap covering the crown and back of the head, leaving the forehead and face free.</summary>
            void HairCap(float extraUp = 0f, float extraBack = 0f)
            {
                BoneWeight wh = W(BoneId.Head);
                sb.Ellipsoid(hc + new Vector3(0, 0.03f * headS + extraUp, -0.02f * headS - extraBack), new Vector3(hr.x * 1.08f, hr.y * 0.97f, hr.z * 1.05f),
                    Quaternion.identity, Slot.Hair, wh, 18, 12);
            }

            // ------------------------------------------------------------ materials
            Material Mat(Slot s)
            {
                Color col = Color.white; Texture2D tex = null;
                string key = c.Id + "|" + outfit.Id + "|" + s;
                int seed = c.Id.GetHashCode() & 0xFFFF;
                switch (s)
                {
                    case Slot.Skin: col = c.Skin; break;
                    case Slot.Hair: col = c.Hair; tex = CharacterTextures.Hair(c.Id + "_hair", seed); break;
                    case Slot.HairTip: col = c.HairTip; tex = CharacterTextures.Hair(c.Id + "_hair", seed); break;
                    case Slot.Jacket: col = jacketCol; tex = CharacterTextures.Fabric(key, seed + 1, 7, 1f); break;
                    case Slot.Inner: col = c.Inner; tex = CharacterTextures.Fabric(key, seed + 2, 4, 1f); break;
                    case Slot.Pants: col = c.Pants; tex = CharacterTextures.Fabric(key, seed + 3, 5, 1f); break;
                    case Slot.Shoes: col = c.Shoes; tex = CharacterTextures.Fabric(key, seed + 4, 2, 0.4f); break;
                    case Slot.Sole: col = c.Sole; break;
                    case Slot.Accent: col = accentCol; tex = CharacterTextures.Fabric(key, seed + 5, 0, 1f); break;
                    case Slot.Accent2: col = c.Accent2; break;
                    case Slot.Metal: col = c.Metal; break;
                    case Slot.Glass: col = new Color(0.07f, 0.09f, 0.13f); break;
                    case Slot.Eye: col = new Color(0.97f, 0.97f, 0.95f); break;
                    case Slot.Dark: col = new Color(0.09f, 0.09f, 0.1f); break;
                    default: col = c.Lips; break;
                }
                return MaterialLibrary.Textured(key, col, tex);
            }

            // ====================================================================================================
            // DHIREN: stylish streetwear. Black bomber, white tee, sand tapered trousers, white sneakers.
            void Dhiren()
            {
                BoneWeight wh = W(BoneId.Head);
                // hair: swept quiff with blue tips and a neat fade
                HairCap();
                sb.Ellipsoid(hc + new Vector3(0, 0.115f, 0.04f), new Vector3(0.075f, 0.048f, 0.095f), Quaternion.Euler(-18f, 0, 0), Slot.Hair, wh, 12, 8);
                sb.Ellipsoid(hc + new Vector3(0.01f, 0.125f, 0.105f), new Vector3(0.055f, 0.026f, 0.035f), Quaternion.Euler(-30f, 0, -8f), Slot.HairTip, wh, 10, 6);
                for (int s = -1; s <= 1; s += 2)
                    sb.Ellipsoid(hc + new Vector3(s * 0.093f, 0.0f, 0.0f), new Vector3(0.012f, 0.045f, 0.045f), Quaternion.identity, Slot.Hair, wh, 6, 5); // sideburns
                sb.Ellipsoid(hc + new Vector3(0.092f, -0.006f, 0.0f), new Vector3(0.009f, 0.009f, 0.009f), Quaternion.identity, Slot.Metal, wh, 6, 5); // stud earring
                // layers: tee, bomber jacket with ribbed hem/collar/cuffs
                TorsoShell(Slot.Inner, hipH - 0.08f, neckY, 0.006f, 0.006f);
                TorsoShell(Slot.Jacket, hipH - 0.05f, neckY - 0.005f, 0.024f, 0.03f);
                TorsoShell(Slot.Accent2, hipH - 0.075f, hipH - 0.005f, 0.03f, 0.036f, 3); // ribbed hem
                Tor(new Vector3(0, neckY + 0.0f, 0), 0.066f, 0.022f, Slot.Accent2, W(BoneId.Chest), 0, 0, 0);
                float fz = TorsoFront(hipH + 0.3f, 0.03f);
                E(new Vector3(0, hipH + 0.34f, fz - 0.006f), new Vector3(0.042f, 0.17f, 0.016f), Slot.Inner, BoneId.Chest, 0, 0, 0, 8, 6); // open front V of tee
                Bx(new Vector3(0, hipH + 0.18f, TorsoFront(hipH + 0.18f, 0.03f) + 0.002f), new Vector3(0.009f, 0.3f, 0.006f), Slot.Metal, BoneId.Spine); // zip
                E(new Vector3(-0.07f, hipH + 0.36f, TorsoFront(hipH + 0.36f, 0.03f) - 0.004f), new Vector3(0.045f, 0.03f, 0.012f), Slot.Accent, BoneId.Chest, 0, 0, 12, 8, 6); // Holi pink chest patch
                for (int s = -1; s <= 1; s += 2)
                {
                    ArmShell(s, Slot.Jacket, shoulderY + 0.03f, wristY + 0.035f, 1.1f, 1.05f, 1.15f, 0.022f);
                    ArmBand(s, Slot.Accent, elbowY + 0.13f, 0.035f, 0.03f);   // gradient sleeve stripes
                    ArmBand(s, Slot.Accent2, elbowY + 0.07f, 0.02f, 0.03f);
                    ArmBand(s, Slot.Accent2, wristY + 0.04f, 0.06f, 0.034f);  // ribbed cuff
                    LegShell(s, Slot.Pants, legTop + 0.04f, ankleY + 0.018f, 1.0f, 0.95f, 0.88f, 0.014f);
                    LegBand(s, Slot.Inner, ankleY + 0.035f, 0.03f, 0.016f);   // folded cuff showing
                }
                ArmBand(-1, Slot.Accent, wristY + 0.02f, 0.045f, 0.04f);       // wristband on the left
                ArmBand(1, Slot.Metal, wristY + 0.022f, 0.022f, 0.036f);       // watch
                // silver chain with pendant
                Tor(new Vector3(0, neckY - 0.045f, 0.015f), 0.085f, 0.0065f, Slot.Metal, W(BoneId.Chest), 12, 0, 0, 20);
                E(new Vector3(0, neckY - 0.165f, TorsoFront(neckY - 0.165f, 0.03f) + 0.004f), new Vector3(0.014f, 0.02f, 0.006f), Slot.Metal, BoneId.Chest, 0, 0, 0, 8, 6);
                // belt peeking under the jacket
                Bx(new Vector3(0, hipH - 0.045f, TorsoFront(hipH - 0.045f, 0.0f) + 0.002f), new Vector3(0.05f, 0.03f, 0.008f), Slot.Metal, BoneId.Hips);
            }

            // DIVYA: glamorous. Violet cropped jacket, cream tee, olive cargos, chunky sneakers, high ponytail with pink tips.
            void Divya()
            {
                BoneWeight wh = W(BoneId.Head);
                HairCap(0.004f, 0.006f);
                // side-swept bangs
                sb.Ellipsoid(hc + new Vector3(0.02f, 0.078f, 0.082f), new Vector3(0.092f, 0.026f, 0.034f), Quaternion.Euler(-24f, 0, -14f), Slot.Hair, wh, 12, 7);
                for (int s = -1; s <= 1; s += 2) sb.Ellipsoid(hc + new Vector3(s * 0.088f, -0.02f, 0.015f), new Vector3(0.016f, 0.07f, 0.05f), Quaternion.identity, Slot.Hair, wh, 8, 6);
                // ponytail: hair tie, then a tapering tube skinned between the two tail bones
                Vector3 t1 = wp[(int)BoneId.Tail1], t2 = wp[(int)BoneId.Tail2];
                Tor(t1 + new Vector3(0, -0.01f, 0.0f), 0.034f, 0.011f, Slot.Accent, wh, 90, 0, 0, 12);
                int n = 7;
                var y = new float[n]; var rx = new float[n]; var rz = new float[n]; var cz = new float[n]; var w = new BoneWeight[n];
                float[] rad = { 0.03f, 0.04f, 0.044f, 0.042f, 0.034f, 0.022f, 0.008f };
                for (int i = 0; i < n; i++)
                {
                    float k = i / (float)(n - 1);
                    y[i] = t1.y + 0.015f - k * 0.42f;
                    rx[i] = rad[i]; rz[i] = rad[i] * 0.8f; cz[i] = t1.z - k * 0.05f;
                    w[i] = SkinBuilder.W(I(BoneId.Tail1), I(BoneId.Tail2), Mathf.Clamp01((k - 0.15f) / 0.6f));
                }
                sb.Lathe(y, rx, rz, 10, Matrix4x4.identity, Slot.Hair, w, true, true, null, cz);
                sb.Ellipsoid(new Vector3(0, t1.y - 0.4f, t1.z - 0.045f), new Vector3(0.026f, 0.07f, 0.022f), Quaternion.Euler(5, 0, 0), Slot.HairTip, W(BoneId.Tail2), 8, 6); // pink tips
                sb.Ellipsoid(new Vector3(0, t1.y - 0.25f, t1.z - 0.037f), new Vector3(0.012f, 0.1f, 0.03f), Quaternion.identity, Slot.HairTip, SkinBuilder.W(I(BoneId.Tail1), I(BoneId.Tail2), 0.6f), 8, 6); // highlight streak
                // sunglasses pushed up on the head, hoop earrings
                for (int s = -1; s <= 1; s += 2)
                {
                    sb.Ellipsoid(hc + new Vector3(s * 0.04f, 0.1f, 0.052f), new Vector3(0.036f, 0.022f, 0.01f), Quaternion.Euler(-48f, 0, s * 6f), Slot.Glass, wh, 10, 6);
                    Tor(hc + new Vector3(s * 0.095f, -0.04f, 0.0f), 0.022f, 0.0045f, Slot.Metal, wh, 0, 0, 90, 14);
                }
                Bx(hc + new Vector3(0, 0.103f, 0.048f), new Vector3(0.02f, 0.006f, 0.006f), Slot.Metal, BoneId.Head, -48f);
                // outfit: cream crop tee, violet cropped jacket with gold trim, high-waist cargos with belt
                TorsoShell(Slot.Inner, hipH + 0.08f, neckY, 0.006f, 0.007f);
                TorsoShell(Slot.Jacket, hipH + 0.17f, neckY - 0.004f, 0.02f, 0.028f, 7);
                TorsoShell(Slot.Accent, hipH + 0.15f, hipH + 0.19f, 0.024f, 0.032f, 3); // gold hem trim
                TorsoShell(Slot.Pants, hipH - 0.11f, hipH + 0.15f, 0.014f, 0.018f, 6);
                TorsoShell(Slot.Dark, hipH + 0.105f, hipH + 0.135f, 0.02f, 0.024f, 3);  // belt
                Bx(new Vector3(0, hipH + 0.12f, TorsoFront(hipH + 0.12f, 0.024f) + 0.003f), new Vector3(0.04f, 0.03f, 0.008f), Slot.Metal, BoneId.Hips); // buckle
                float fz = TorsoFront(hipH + 0.33f, 0.028f);
                E(new Vector3(0, hipH + 0.33f, fz - 0.005f), new Vector3(0.055f, 0.13f, 0.014f), Slot.Inner, BoneId.Chest, 0, 0, 0, 8, 6);
                Tor(new Vector3(0, neckY - 0.005f, 0), 0.064f, 0.018f, Slot.Accent, W(BoneId.Chest), 0, 0, 0);
                for (int s = -1; s <= 1; s += 2)
                {
                    ArmShell(s, Slot.Jacket, shoulderY + 0.03f, wristY + 0.04f, 1.1f, 1.05f, 1.12f, 0.02f);
                    ArmBand(s, Slot.Accent, wristY + 0.045f, 0.045f, 0.03f);
                    ArmBand(s, Slot.Metal, wristY + 0.012f, 0.012f, 0.026f); // bracelets
                    LegShell(s, Slot.Pants, legTop + 0.04f, ankleY + 0.02f, 1.18f, 1.28f, 1.25f, 0.018f, 1.0f);
                    LegBand(s, Slot.Pants, ankleY + 0.05f, 0.04f, 0.045f); // gathered cuff over the sneaker
                    Bx(new Vector3(s * (hipW + 0.1f), kneeY + 0.12f, 0.0f), new Vector3(0.034f, 0.1f, 0.085f), Slot.Pants, s < 0 ? BoneId.LegL : BoneId.LegR); // cargo pocket
                    Bx(new Vector3(s * (hipW + 0.119f), kneeY + 0.14f, 0.0f), new Vector3(0.008f, 0.03f, 0.07f), Slot.Dark, s < 0 ? BoneId.LegL : BoneId.LegR);
                }
                // crossbody strap and mini bag
                Bx(new Vector3(0.0f, hipH + 0.32f, TorsoFront(hipH + 0.32f, 0.032f) + 0.001f), new Vector3(0.012f, 0.5f, 0.006f), Slot.Dark, BoneId.Chest, 0, 0, 38f);
                E(new Vector3(-0.13f, hipH + 0.02f, 0.06f), new Vector3(0.05f, 0.04f, 0.025f), Slot.Accent2, BoneId.Hips, 0, 0, 0, 10, 7);
            }

            // TRISHA: cute pastel couple look. Pink oversized hoodie with mint details, lavender joggers, twin buns.
            void Trisha()
            {
                BoneWeight wh = W(BoneId.Head);
                HairCap(0.004f, 0.006f);
                for (int s = -1; s <= 1; s += 2)
                {
                    sb.Ellipsoid(hc + new Vector3(s * 0.088f, -0.04f, -0.02f), new Vector3(0.03f, 0.085f, 0.075f), Quaternion.Euler(0, 0, s * 4f), Slot.Hair, wh, 10, 7); // bob sides
                    sb.Ellipsoid(hc + new Vector3(s * 0.066f, 0.128f, -0.02f), new Vector3(0.045f, 0.045f, 0.045f), Quaternion.identity, Slot.Hair, wh, 10, 8); // buns
                    Tor(hc + new Vector3(s * 0.062f, 0.098f, -0.018f), 0.04f, 0.009f, Slot.Accent, wh, 0, 0, s * 20f, 14);                               // scrunchies
                    sb.Ellipsoid(hc + new Vector3(s * 0.066f, 0.17f, -0.02f), new Vector3(0.02f, 0.014f, 0.02f), Quaternion.identity, Slot.HairTip, wh, 8, 6);
                }
                sb.Ellipsoid(hc + new Vector3(0, -0.05f, -0.075f), new Vector3(0.092f, 0.095f, 0.04f), Quaternion.identity, Slot.Hair, wh, 10, 7);       // back of bob
                sb.Ellipsoid(hc + new Vector3(0, 0.074f, 0.088f), new Vector3(0.085f, 0.024f, 0.03f), Quaternion.Euler(-26f, 0, 0), Slot.Hair, wh, 12, 7); // bangs
                // flower hair clip
                for (int p = 0; p < 5; p++)
                {
                    float a = p * Mathf.PI * 2f / 5f;
                    sb.Ellipsoid(hc + new Vector3(0.07f + Mathf.Cos(a) * 0.014f, 0.085f + Mathf.Sin(a) * 0.014f, 0.07f), new Vector3(0.011f, 0.011f, 0.007f), Quaternion.identity, Slot.Accent2, wh, 6, 5);
                }
                sb.Ellipsoid(hc + new Vector3(0.07f, 0.085f, 0.074f), new Vector3(0.008f, 0.008f, 0.006f), Quaternion.identity, Slot.Dark, wh, 6, 5);
                // oversized hoodie: boxy body, folded hood, drawstrings, kangaroo pocket, rib cuffs and hem
                TorsoShell(Slot.Inner, hipH - 0.06f, neckY, 0.006f, 0.006f);
                TorsoShell(Slot.Jacket, hipH - 0.15f, neckY - 0.004f, 0.05f, 0.05f, 10);
                TorsoShell(Slot.Accent, hipH - 0.17f, hipH - 0.11f, 0.054f, 0.054f, 3);
                Tor(new Vector3(0, neckY + 0.0f, -0.01f), 0.078f, 0.036f, Slot.Jacket, W(BoneId.Chest), 8, 0, 0, 18);
                float fz = TorsoFront(hipH + 0.25f, 0.05f);
                E(new Vector3(0, hipH + 0.06f, TorsoFront(hipH + 0.06f, 0.05f) - 0.012f), new Vector3(0.09f, 0.045f, 0.022f), Slot.Accent, BoneId.Spine, 6, 0, 0, 12, 6);
                for (int s = -1; s <= 1; s += 2)
                {
                    E(new Vector3(s * 0.028f, neckY - 0.1f, TorsoFront(neckY - 0.1f, 0.05f) + 0.003f), new Vector3(0.006f, 0.075f, 0.006f), Slot.Accent, BoneId.Chest, 0, 0, 0, 6, 5);
                    E(new Vector3(s * 0.028f, neckY - 0.18f, TorsoFront(neckY - 0.18f, 0.05f) + 0.003f), new Vector3(0.01f, 0.014f, 0.01f), Slot.Accent2, BoneId.Chest, 0, 0, 0, 6, 5);
                    ArmShell(s, Slot.Jacket, shoulderY + 0.03f, wristY + 0.05f, 1.2f, 1.45f, 1.5f, 0.026f);
                    ArmBand(s, Slot.Accent, wristY + 0.05f, 0.05f, 0.04f);
                    LegShell(s, Slot.Pants, legTop + 0.04f, ankleY + 0.02f, 1.1f, 1.12f, 1.0f, 0.016f);
                    LegBand(s, Slot.Inner, ankleY + 0.04f, 0.035f, 0.035f); // jogger cuffs
                }
                // matching couple accessories: heart charm necklace, friendship band, mini bear backpack
                Tor(new Vector3(0, neckY - 0.04f, 0.02f), 0.075f, 0.005f, Slot.Metal, W(BoneId.Chest), 14, 0, 0, 18);
                Heart(new Vector3(0, neckY - 0.11f, TorsoFront(neckY - 0.11f, 0.05f) + 0.012f), 0.016f, Slot.Accent2, BoneId.Chest);
                ArmBand(1, Slot.Accent, wristY + 0.015f, 0.02f, 0.046f);
                ArmBand(1, Slot.Accent2, wristY + 0.04f, 0.02f, 0.046f);
                E(new Vector3(0, hipH + 0.3f, -0.17f), new Vector3(0.09f, 0.11f, 0.055f), Slot.Accent2, BoneId.Chest, 0, 0, 0, 10, 8);
                for (int s = -1; s <= 1; s += 2)
                {
                    E(new Vector3(s * 0.05f, hipH + 0.4f, -0.17f), new Vector3(0.028f, 0.028f, 0.02f), Slot.Accent2, BoneId.Chest, 0, 0, 0, 8, 6); // bear ears
                    Bx(new Vector3(s * 0.075f, hipH + 0.34f, -0.08f), new Vector3(0.012f, 0.28f, 0.006f), Slot.Accent, BoneId.Chest, 0, 0, s * -10f); // straps
                }
            }

            // ULVAAN: Trisha's partner. Mint zip hoodie with pink details, beige trousers, round glasses, headphones.
            void Ulvaan()
            {
                BoneWeight wh = W(BoneId.Head);
                HairCap(0.006f, 0.004f);
                sb.Ellipsoid(hc + new Vector3(0, 0.12f, -0.005f), new Vector3(0.082f, 0.04f, 0.09f), Quaternion.identity, Slot.Hair, wh, 12, 8);          // volume
                sb.Ellipsoid(hc + new Vector3(0.025f, 0.09f, 0.082f), new Vector3(0.07f, 0.03f, 0.04f), Quaternion.Euler(-22f, 0, -14f), Slot.Hair, wh, 10, 7); // swept fringe
                for (int s = -1; s <= 1; s += 2)
                    for (int k = 0; k < 3; k++)
                        sb.Ellipsoid(hc + new Vector3(s * 0.098f, 0.04f - k * 0.03f, -0.01f - k * 0.015f), new Vector3(0.018f, 0.025f, 0.03f), Quaternion.identity, Slot.Hair, wh, 6, 5); // soft curls
                // round glasses
                for (int s = -1; s <= 1; s += 2)
                {
                    float ex = s * 0.038f * headS, ey = 0.014f * headS;
                    Tor(hc + new Vector3(ex, ey, HZ(ex, ey) - hc.z + 0.012f), 0.027f, 0.0032f, Slot.Metal, wh, 90, 0, 0, 16);
                    Bx(hc + new Vector3(s * 0.098f, ey, 0.03f), new Vector3(0.004f, 0.004f, 0.08f), Slot.Metal, BoneId.Head);
                }
                Bx(hc + new Vector3(0, 0.014f * headS, HZ(0, 0.014f) - hc.z + 0.013f), new Vector3(0.026f, 0.004f, 0.004f), Slot.Metal, BoneId.Head);
                // zip hoodie
                TorsoShell(Slot.Inner, hipH - 0.05f, neckY, 0.006f, 0.006f);
                TorsoShell(Slot.Jacket, hipH - 0.12f, neckY - 0.004f, 0.036f, 0.038f, 10);
                TorsoShell(Slot.Accent, hipH - 0.14f, hipH - 0.1f, 0.04f, 0.042f, 3);
                Tor(new Vector3(0, neckY + 0.0f, -0.012f), 0.076f, 0.034f, Slot.Jacket, W(BoneId.Chest), 8, 0, 0, 18);
                Bx(new Vector3(0, hipH + 0.17f, TorsoFront(hipH + 0.17f, 0.038f) + 0.002f), new Vector3(0.009f, 0.5f, 0.006f), Slot.Metal, BoneId.Spine);
                for (int s = -1; s <= 1; s += 2)
                {
                    E(new Vector3(s * 0.03f, neckY - 0.1f, TorsoFront(neckY - 0.1f, 0.038f) + 0.003f), new Vector3(0.006f, 0.07f, 0.006f), Slot.Accent, BoneId.Chest, 0, 0, 0, 6, 5);
                    ArmShell(s, Slot.Jacket, shoulderY + 0.03f, wristY + 0.045f, 1.12f, 1.25f, 1.3f, 0.022f);
                    ArmBand(s, Slot.Accent, wristY + 0.045f, 0.045f, 0.034f);
                    LegShell(s, Slot.Pants, legTop + 0.04f, ankleY + 0.02f, 1.05f, 1.02f, 1.1f, 0.014f);
                }
                // headphones around the neck, matching charm and friendship band (pair of Trisha's)
                Tor(new Vector3(0, neckY - 0.02f, 0.0f), 0.1f, 0.012f, Slot.Accent, W(BoneId.Chest), 8, 0, 0, 20);
                for (int s = -1; s <= 1; s += 2)
                    sb.Ellipsoid(new Vector3(s * 0.098f, neckY - 0.03f, 0.04f), new Vector3(0.022f, 0.04f, 0.04f), Quaternion.identity, Slot.Accent, W(BoneId.Chest), 8, 6);
                ArmBand(1, Slot.Accent2, wristY + 0.015f, 0.02f, 0.046f);
                ArmBand(1, Slot.Accent, wristY + 0.04f, 0.02f, 0.046f);
                Bx(new Vector3(0.115f, hipH - 0.02f, 0.03f), new Vector3(0.006f, 0.1f, 0.006f), Slot.Metal, BoneId.Hips);
                Heart(new Vector3(0.12f, hipH - 0.1f, 0.03f), 0.02f, Slot.Accent, BoneId.Hips);
            }

            // SANDY: unique and loud. Platinum spikes with lime tips, black visor shades, lime puffer vest over a charcoal
            // hoodie, black cargos with straps, big orange sneakers, bandana, fingerless gloves, chain wallet.
            void Sandy()
            {
                BoneWeight wh = W(BoneId.Head);
                HairCap(0.004f, 0.004f);
                for (int i = 0; i < 8; i++)
                {
                    float a = i * Mathf.PI * 2f / 8f;
                    float tilt = (i % 2 == 0) ? 0.55f : 0.35f;
                    Vector3 dir = new Vector3(Mathf.Sin(a) * Mathf.Sin(tilt), Mathf.Cos(tilt), Mathf.Cos(a) * Mathf.Sin(tilt)).normalized;
                    Vector3 b0 = hc + new Vector3(Mathf.Sin(a) * 0.045f, 0.1f, Mathf.Cos(a) * 0.045f - 0.01f);
                    Quaternion q = Quaternion.FromToRotation(Vector3.up, dir);
                    float len = (i % 2 == 0) ? 0.075f : 0.06f;
                    sb.Ellipsoid(b0 + dir * len * 0.7f, new Vector3(0.026f, len, 0.026f), q, Slot.Hair, wh, 8, 6);
                    sb.Ellipsoid(b0 + dir * len * 1.5f, new Vector3(0.016f, len * 0.5f, 0.016f), q, Slot.HairTip, wh, 8, 6);
                }
                // black visor shades with metal frame, ear cuff
                float ey = 0.014f * headS;
                for (int s = -1; s <= 1; s += 2)
                {
                    float ex = s * 0.04f * headS;
                    sb.Ellipsoid(hc + new Vector3(ex, ey, HZ(ex, ey) - hc.z + 0.012f), new Vector3(0.044f, 0.024f, 0.012f), Quaternion.Euler(0, 0, s * -6f), Slot.Glass, wh, 12, 7);
                    Bx(hc + new Vector3(s * 0.098f, ey, 0.03f), new Vector3(0.005f, 0.012f, 0.08f), Slot.Metal, BoneId.Head);
                    Tor(hc + new Vector3(s * 0.094f, -0.018f, 0.0f), 0.012f, 0.0035f, Slot.Metal, wh, 0, 0, 90, 10);
                }
                Bx(hc + new Vector3(0, ey + 0.006f, HZ(0, ey) - hc.z + 0.013f), new Vector3(0.03f, 0.008f, 0.006f), Slot.Metal, BoneId.Head);
                // layers: charcoal hoodie (body + sleeves), lime quilted puffer vest, hood behind the neck
                TorsoShell(Slot.Inner, hipH - 0.1f, neckY, 0.034f, 0.034f, 10);
                E(new Vector3(0, neckY + 0.0f, -0.08f), new Vector3(0.11f, 0.075f, 0.075f), Slot.Inner, BoneId.Chest, 0, 0, 0, 12, 7); // hood
                TorsoShell(Slot.Jacket, hipH + 0.02f, neckY - 0.01f, 0.062f, 0.058f, 9);
                for (int k = 0; k < 4; k++) // quilting lines
                    TorsoShell(Slot.Dark, hipH + 0.11f + k * 0.11f, hipH + 0.118f + k * 0.11f, 0.066f, 0.062f, 2);
                Tor(new Vector3(0, neckY - 0.005f, 0.0f), 0.078f, 0.028f, Slot.Jacket, W(BoneId.Chest), 0, 0, 0, 18);
                Bx(new Vector3(0, hipH + 0.3f, TorsoFront(hipH + 0.3f, 0.058f) + 0.002f), new Vector3(0.01f, 0.5f, 0.007f), Slot.Metal, BoneId.Spine);
                E(new Vector3(0.09f, hipH + 0.4f, TorsoFront(hipH + 0.4f, 0.058f) - 0.004f), new Vector3(0.035f, 0.02f, 0.01f), Slot.Accent, BoneId.Chest, 0, 0, 0, 8, 6); // orange logo patch
                for (int s = -1; s <= 1; s += 2)
                {
                    ArmShell(s, Slot.Inner, shoulderY + 0.03f, wristY + 0.04f, 1.1f, 1.1f, 1.2f, 0.022f);
                    ArmBand(s, Slot.Accent, wristY + 0.05f, 0.04f, 0.034f);
                    LegShell(s, Slot.Pants, legTop + 0.04f, ankleY + 0.02f, 1.2f, 1.3f, 1.22f, 0.018f, 1.0f);
                    LegBand(s, Slot.Pants, ankleY + 0.05f, 0.04f, 0.044f);
                    BoneId lg = s < 0 ? BoneId.LegL : BoneId.LegR;
                    Bx(new Vector3(s * (hipW + 0.112f), kneeY + 0.14f, 0.0f), new Vector3(0.04f, 0.12f, 0.09f), Slot.Pants, lg);                    // cargo pocket
                    LegBand(s, Slot.Accent, kneeY + 0.2f, 0.025f, 0.036f);                                                                         // orange strap
                    LegBand(s, Slot.Accent2, kneeY - 0.02f, 0.02f, 0.034f);                                                                        // pink strap
                }
                // bandana at the neck with two streaming tails, chain wallet, fingerless glove cuffs
                Tor(new Vector3(0, neckY + 0.004f, 0.0f), 0.066f, 0.016f, Slot.Accent2, W(BoneId.Chest), 0, 0, 0, 16);
                E(new Vector3(0, neckY - 0.01f, 0.062f), new Vector3(0.035f, 0.03f, 0.014f), Slot.Accent2, BoneId.Chest, 20, 0, 0, 8, 6);
                Vector3 t1 = wp[(int)BoneId.Tail1], t2 = wp[(int)BoneId.Tail2];
                sb.Ellipsoid(t1 + new Vector3(0, -0.04f, -0.01f), new Vector3(0.04f, 0.06f, 0.01f), Quaternion.identity, Slot.Accent2, W(BoneId.Tail1), 8, 6);
                sb.Ellipsoid(t2 + new Vector3(0, -0.06f, -0.01f), new Vector3(0.03f, 0.075f, 0.008f), Quaternion.Euler(0, 0, 8), Slot.Accent2, W(BoneId.Tail2), 8, 6);
                sb.Ellipsoid(t2 + new Vector3(0.04f, -0.05f, -0.01f), new Vector3(0.022f, 0.07f, 0.008f), Quaternion.Euler(0, 0, -14), Slot.Accent2, W(BoneId.Tail2), 8, 6);
                Tor(new Vector3(0.12f, hipH - 0.04f, 0.0f), 0.045f, 0.004f, Slot.Metal, W(BoneId.Hips), 0, 0, 90, 12);
            }

            /// <summary>Little heart charm made from two spheres and a point.</summary>
            void Heart(Vector3 centre, float size, Slot slot, BoneId bone)
            {
                BoneWeight w = W(bone);
                sb.Ellipsoid(centre + new Vector3(-size * 0.5f, size * 0.3f, 0), new Vector3(size * 0.62f, size * 0.62f, size * 0.4f), Quaternion.identity, slot, w, 8, 6);
                sb.Ellipsoid(centre + new Vector3(size * 0.5f, size * 0.3f, 0), new Vector3(size * 0.62f, size * 0.62f, size * 0.4f), Quaternion.identity, slot, w, 8, 6);
                sb.Ellipsoid(centre + new Vector3(0, -size * 0.25f, 0), new Vector3(size * 0.75f, size * 0.8f, size * 0.38f), Quaternion.Euler(0, 0, 45f), slot, w, 8, 6);
            }
        }
    }
}
