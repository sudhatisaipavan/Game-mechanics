using UnityEngine;

namespace TokyoNightRun
{
    public enum BoneId { Hips, Spine, Chest, Neck, Head, ClavL, ArmL, ForeL, HandL, ClavR, ArmR, ForeR, HandR, LegL, ShinL, FootL, LegR, ShinR, FootR, Tail1, Tail2, Count }

    /// <summary>Euler angles (degrees) for every bone plus a hip height offset and a whole-body flip angle.</summary>
    public class PoseFrame
    {
        public readonly Vector3[] E = new Vector3[(int)BoneId.Count];
        public float HipsY, Flip;
        public void Clear() { for (int i = 0; i < E.Length; i++) E[i] = Vector3.zero; HipsY = 0f; Flip = 0f; }
    }

    public struct RunStyle { public float Cadence, ArmSwing, LegSwing, Knee, Elbow, Bounce, Lean, Twist, HeadTilt, ArmOut; }

    /// <summary>
    /// Pure functions that compute a pose for each movement state. RunnerVisual cross-fades between them, which gives
    /// smooth transitions (run -> jump -> fall -> land -> run, run -> slide, ...). Each character has its own run
    /// rhythm, idle, jump and victory. Sign conventions (character faces +Z, bones start with identity rotation):
    /// +X on a hanging limb swings it backwards, -X forwards; +X on spine/head leans forward; elbow flex is -X, knee flex is +X.
    /// </summary>
    public static class CharacterPoses
    {
        public static RunStyle StyleFor(CharacterStyle s)
        {
            switch (s)
            {
                case CharacterStyle.Dhiren: return new RunStyle { Cadence = 0.95f, ArmSwing = 38, LegSwing = 46, Knee = 62, Elbow = 80, Bounce = 0.05f, Lean = 9, Twist = 8, HeadTilt = 4, ArmOut = 4 };
                case CharacterStyle.Divya: return new RunStyle { Cadence = 1.1f, ArmSwing = 50, LegSwing = 50, Knee = 75, Elbow = 85, Bounce = 0.06f, Lean = 8, Twist = 12, HeadTilt = 3, ArmOut = 3 };
                case CharacterStyle.Trisha: return new RunStyle { Cadence = 1.15f, ArmSwing = 42, LegSwing = 42, Knee = 70, Elbow = 95, Bounce = 0.085f, Lean = 5, Twist = 9, HeadTilt = 6, ArmOut = 8 };
                case CharacterStyle.Ulvaan: return new RunStyle { Cadence = 1.0f, ArmSwing = 52, LegSwing = 48, Knee = 66, Elbow = 70, Bounce = 0.06f, Lean = 8, Twist = 9, HeadTilt = 3, ArmOut = 5 };
                default: return new RunStyle { Cadence = 0.9f, ArmSwing = 62, LegSwing = 56, Knee = 72, Elbow = 65, Bounce = 0.075f, Lean = 14, Twist = 14, HeadTilt = 5, ArmOut = 7 };
            }
        }

        static void S(PoseFrame f, BoneId b, float x, float y = 0f, float z = 0f) { f.E[(int)b] = new Vector3(x, y, z); }
        static float Rx(PoseFrame f, BoneId b) { return f.E[(int)b].x; }

        static void FeetLevel(PoseFrame f)
        {
            S(f, BoneId.FootL, Mathf.Clamp(-(Rx(f, BoneId.LegL) + Rx(f, BoneId.ShinL)) * 0.45f, -35f, 35f));
            S(f, BoneId.FootR, Mathf.Clamp(-(Rx(f, BoneId.LegR) + Rx(f, BoneId.ShinR)) * 0.45f, -35f, 35f));
        }

        /// <summary>t = seconds in the current state (for Jump/Fall: seconds in the air).</summary>
        public static void Evaluate(RunnerVisual.Pose pose, CharacterStyle who, float phase, float t, float speed01, float hipH, PoseFrame f)
        {
            f.Clear();
            RunStyle r = StyleFor(who);
            switch (pose)
            {
                case RunnerVisual.Pose.Run: Run(f, r, who, phase, speed01); break;
                case RunnerVisual.Pose.Jump: Jump(f, who, t); break;
                case RunnerVisual.Pose.Fall: Fall(f, who, t); break;
                case RunnerVisual.Pose.Land: Land(f, who); break;
                case RunnerVisual.Pose.Slide: Slide(f, hipH); break;
                case RunnerVisual.Pose.Dead: Dead(f); break;
                case RunnerVisual.Pose.Victory: Victory(f, who, t); break;
                default: Idle(f, who, t); break;
            }
            FeetLevel(f);
        }

        static void Run(PoseFrame f, RunStyle r, CharacterStyle who, float phase, float speed01)
        {
            float s = Mathf.Sin(phase), c = Mathf.Cos(phase);
            float swing = r.LegSwing * Mathf.Lerp(0.85f, 1.15f, speed01);
            S(f, BoneId.LegL, -s * swing + 6f, 0, -2f);
            S(f, BoneId.LegR, s * swing + 6f, 0, 2f);
            S(f, BoneId.ShinL, 8f + r.Knee * Mathf.Clamp01(0.15f + c));
            S(f, BoneId.ShinR, 8f + r.Knee * Mathf.Clamp01(0.15f - c));
            float arm = r.ArmSwing * Mathf.Lerp(0.9f, 1.15f, speed01);
            S(f, BoneId.ArmL, s * arm, 0, -r.ArmOut);
            S(f, BoneId.ArmR, -s * arm, 0, r.ArmOut);
            S(f, BoneId.ForeL, -r.Elbow + 18f * s);
            S(f, BoneId.ForeR, -r.Elbow - 18f * s);
            f.HipsY = -0.5f * r.Bounce * Mathf.Cos(2f * phase);
            S(f, BoneId.Hips, r.Lean * 0.4f, s * r.Twist * 0.4f, who == CharacterStyle.Divya ? 3f * s : 0f);
            S(f, BoneId.Spine, r.Lean * 0.6f + 2f * Mathf.Sin(2f * phase), 0, 2f * s);
            S(f, BoneId.Chest, r.Lean * 0.4f, -s * r.Twist);
            S(f, BoneId.Head, -r.Lean * 0.9f + 1.5f * Mathf.Sin(2f * phase), s * r.Twist * 0.6f, r.HeadTilt * Mathf.Sin(phase * 0.5f));
            S(f, BoneId.Tail1, 25f + speed01 * 25f + 10f * Mathf.Sin(2f * phase + 0.4f), 0, 6f * s);
            S(f, BoneId.Tail2, 12f + 14f * Mathf.Sin(2f * phase - 0.5f), 0, 8f * Mathf.Sin(phase + 0.7f));
        }

        static void Jump(PoseFrame f, CharacterStyle who, float t)
        {
            S(f, BoneId.Hips, 6f); S(f, BoneId.Spine, 6f); S(f, BoneId.Head, -10f);
            S(f, BoneId.Tail1, 55f); S(f, BoneId.Tail2, 30f);
            switch (who)
            {
                case CharacterStyle.Dhiren: // cool: one arm up, one relaxed
                    S(f, BoneId.LegL, -65f); S(f, BoneId.ShinL, 100f); S(f, BoneId.LegR, 12f); S(f, BoneId.ShinR, 40f);
                    S(f, BoneId.ArmL, -150f, 0, -12f); S(f, BoneId.ForeL, -20f); S(f, BoneId.ArmR, 15f, 0, 14f); S(f, BoneId.ForeR, -25f); break;
                case CharacterStyle.Divya: // V-arms, knees up
                    S(f, BoneId.LegL, -60f); S(f, BoneId.ShinL, 105f); S(f, BoneId.LegR, -35f); S(f, BoneId.ShinR, 95f);
                    S(f, BoneId.ArmL, -150f, 0, -32f); S(f, BoneId.ForeL, -10f); S(f, BoneId.ArmR, -150f, 0, 32f); S(f, BoneId.ForeR, -10f); break;
                case CharacterStyle.Trisha: // joyful: arms up, heels kicked back
                    S(f, BoneId.LegL, 20f); S(f, BoneId.ShinL, 115f); S(f, BoneId.LegR, -30f); S(f, BoneId.ShinR, 65f);
                    S(f, BoneId.ArmL, -165f, 0, -16f); S(f, BoneId.ForeL, -12f); S(f, BoneId.ArmR, -165f, 0, 16f); S(f, BoneId.ForeR, -12f); break;
                case CharacterStyle.Ulvaan: // superhero reach
                    S(f, BoneId.LegL, -55f); S(f, BoneId.ShinL, 90f); S(f, BoneId.LegR, 25f); S(f, BoneId.ShinR, 55f);
                    S(f, BoneId.ArmL, -172f, 0, -6f); S(f, BoneId.ForeL, -4f); S(f, BoneId.ArmR, 30f, 0, 25f); S(f, BoneId.ForeR, -30f); break;
                default: // Sandy: tucked front flip
                    S(f, BoneId.LegL, -95f); S(f, BoneId.ShinL, 125f); S(f, BoneId.LegR, -90f); S(f, BoneId.ShinR, 120f);
                    S(f, BoneId.ArmL, -70f, 0, 10f); S(f, BoneId.ForeL, -95f); S(f, BoneId.ArmR, -70f, 0, -10f); S(f, BoneId.ForeR, -95f);
                    S(f, BoneId.Spine, 20f); S(f, BoneId.Head, 12f);
                    f.Flip = Mathf.Clamp01(t / 0.62f) * 360f; break;
            }
        }

        static void Fall(PoseFrame f, CharacterStyle who, float t)
        {
            S(f, BoneId.Hips, 4f); S(f, BoneId.Spine, 4f); S(f, BoneId.Head, -6f);
            S(f, BoneId.Tail1, 5f); S(f, BoneId.Tail2, 0f); // hair/scarf streams upward when falling
            S(f, BoneId.LegL, -28f); S(f, BoneId.ShinL, 50f); S(f, BoneId.LegR, -4f); S(f, BoneId.ShinR, 28f);
            S(f, BoneId.ArmL, -25f, 0, -62f); S(f, BoneId.ForeL, -20f); S(f, BoneId.ArmR, -25f, 0, 62f); S(f, BoneId.ForeR, -20f);
            if (who == CharacterStyle.Trisha) { S(f, BoneId.ArmL, -150f, 0, -20f); S(f, BoneId.ArmR, -150f, 0, 20f); }
            if (who == CharacterStyle.Sandy)
            {
                S(f, BoneId.LegL, -80f); S(f, BoneId.ShinL, 110f); S(f, BoneId.LegR, -75f); S(f, BoneId.ShinR, 105f);
                S(f, BoneId.ArmL, -60f, 0, 8f); S(f, BoneId.ForeL, -90f); S(f, BoneId.ArmR, -60f, 0, -8f); S(f, BoneId.ForeR, -90f);
                f.Flip = Mathf.Clamp01(t / 0.62f) * 360f;
            }
        }

        static void Land(PoseFrame f, CharacterStyle who)
        {
            f.HipsY = -0.2f;
            S(f, BoneId.Hips, 10f); S(f, BoneId.Spine, 20f); S(f, BoneId.Chest, 8f); S(f, BoneId.Head, -14f);
            S(f, BoneId.LegL, -58f, 0, -6f); S(f, BoneId.ShinL, 105f); S(f, BoneId.LegR, -50f, 0, 6f); S(f, BoneId.ShinR, 98f);
            S(f, BoneId.ArmL, -38f, 0, -22f); S(f, BoneId.ForeL, -45f); S(f, BoneId.ArmR, -38f, 0, 22f); S(f, BoneId.ForeR, -45f);
            S(f, BoneId.Tail1, 70f); S(f, BoneId.Tail2, 40f);
        }

        static void Slide(PoseFrame f, float hipH)
        {
            f.HipsY = 0.34f - hipH;
            S(f, BoneId.Hips, -68f);
            S(f, BoneId.Spine, 20f); S(f, BoneId.Chest, 15f); S(f, BoneId.Head, 25f);
            S(f, BoneId.LegL, 0f, 0, -5f); S(f, BoneId.ShinL, 10f); S(f, BoneId.LegR, -8f, 0, 5f); S(f, BoneId.ShinR, 6f);
            S(f, BoneId.ArmL, 45f, 0, -15f); S(f, BoneId.ForeL, -12f); S(f, BoneId.ArmR, 50f, 0, 15f); S(f, BoneId.ForeR, -12f);
            S(f, BoneId.Tail1, 70f); S(f, BoneId.Tail2, 40f);
        }

        static void Dead(PoseFrame f)
        {
            f.HipsY = -0.3f;
            S(f, BoneId.Hips, 50f); S(f, BoneId.Spine, 20f); S(f, BoneId.Head, 20f);
            S(f, BoneId.LegL, -40f); S(f, BoneId.ShinL, 60f); S(f, BoneId.LegR, 25f); S(f, BoneId.ShinR, 30f);
            S(f, BoneId.ArmL, -50f, 0, -70f); S(f, BoneId.ForeL, -15f); S(f, BoneId.ArmR, -30f, 0, 75f); S(f, BoneId.ForeR, -10f);
        }

        static void Idle(PoseFrame f, CharacterStyle who, float t)
        {
            float br = Mathf.Sin(t * 1.8f);
            f.HipsY = br * 0.004f;
            S(f, BoneId.Spine, br * 1.5f); S(f, BoneId.Chest, br * 1.0f);
            S(f, BoneId.Head, 0f, Mathf.Sin(t * 0.7f) * 8f, 0f);
            S(f, BoneId.ArmL, 4f, 0, -7f); S(f, BoneId.ArmR, 4f, 0, 7f); S(f, BoneId.ForeL, -10f); S(f, BoneId.ForeR, -10f);
            S(f, BoneId.Tail1, 8f + br * 3f); S(f, BoneId.Tail2, 6f);
            switch (who)
            {
                case CharacterStyle.Dhiren: // hand near the pocket, head tilted
                    S(f, BoneId.ArmR, -20f, 0, 10f); S(f, BoneId.ForeR, -75f); S(f, BoneId.Head, 0f, Mathf.Sin(t * 0.7f) * 6f, 5f); break;
                case CharacterStyle.Divya: // hand on hip, weight shifted
                    S(f, BoneId.Hips, 0f, 0f, 5f); S(f, BoneId.ArmL, 0f, 0, -38f); S(f, BoneId.ForeL, -95f, 50f, 0f);
                    S(f, BoneId.LegR, 0f, 0, 3f); S(f, BoneId.LegL, -4f); break;
                case CharacterStyle.Trisha: // bouncy, arms swinging gently
                    f.HipsY = Mathf.Abs(Mathf.Sin(t * 3f)) * 0.012f;
                    S(f, BoneId.ArmL, Mathf.Sin(t * 3f) * 8f, 0, -12f); S(f, BoneId.ArmR, -Mathf.Sin(t * 3f) * 8f, 0, 12f);
                    S(f, BoneId.Head, 0f, Mathf.Sin(t * 0.9f) * 8f, 6f); break;
                case CharacterStyle.Ulvaan: // friendly wave every few seconds
                {
                    float wave = Mathf.Clamp01(Mathf.Sin(t * 0.9f) * 3f);
                    S(f, BoneId.ArmR, Mathf.Lerp(4f, -150f, wave), 0, Mathf.Lerp(7f, 25f, wave));
                    S(f, BoneId.ForeR, Mathf.Lerp(-10f, -25f + Mathf.Sin(t * 9f) * 30f, wave));
                    break;
                }
                default: // Sandy: arms crossed, chest out
                    S(f, BoneId.ArmL, -30f, 0, -10f); S(f, BoneId.ForeL, -120f, 70f, 0f);
                    S(f, BoneId.ArmR, -30f, 0, 10f); S(f, BoneId.ForeR, -120f, -70f, 0f);
                    S(f, BoneId.Chest, -3f + br); S(f, BoneId.Head, -3f, Mathf.Sin(t * 0.7f) * 6f, 0f); break;
            }
        }

        static void Victory(PoseFrame f, CharacterStyle who, float t)
        {
            f.HipsY = Mathf.Abs(Mathf.Sin(t * 9f)) * 0.1f;
            S(f, BoneId.Spine, -4f); S(f, BoneId.Head, -8f, Mathf.Sin(t * 5f) * 10f);
            S(f, BoneId.LegL, -8f); S(f, BoneId.ShinL, 16f); S(f, BoneId.LegR, -8f); S(f, BoneId.ShinR, 16f);
            S(f, BoneId.Tail1, 15f + Mathf.Sin(t * 9f) * 10f); S(f, BoneId.Tail2, 10f);
            switch (who)
            {
                case CharacterStyle.Dhiren: // confident point and fist
                    S(f, BoneId.ArmR, -170f, 0, 15f); S(f, BoneId.ForeR, -10f); S(f, BoneId.ArmL, 0f, 0, -38f); S(f, BoneId.ForeL, -95f, 50f, 0f); break;
                case CharacterStyle.Divya:
                    S(f, BoneId.Hips, 0f, Mathf.Sin(t * 4f) * 12f, 0f);
                    S(f, BoneId.ArmL, -165f, 0, -35f); S(f, BoneId.ArmR, -165f, 0, 35f); S(f, BoneId.ForeL, -8f); S(f, BoneId.ForeR, -8f); break;
                case CharacterStyle.Trisha:
                    S(f, BoneId.ArmL, -170f + Mathf.Sin(t * 12f) * 12f, 0, -18f); S(f, BoneId.ArmR, -170f - Mathf.Sin(t * 12f) * 12f, 0, 18f);
                    S(f, BoneId.ForeL, -12f); S(f, BoneId.ForeR, -12f); break;
                case CharacterStyle.Ulvaan:
                    S(f, BoneId.ArmR, -160f, 0, 25f); S(f, BoneId.ForeR, -25f + Mathf.Sin(t * 10f) * 35f);
                    S(f, BoneId.ArmL, 6f, 0, -10f); S(f, BoneId.ForeL, -10f); break;
                default: // Sandy: front flip then fist pump
                    f.Flip = Mathf.Clamp01(t / 0.7f) * 360f;
                    S(f, BoneId.ArmR, -130f + Mathf.Sin(t * 8f) * 15f, 0, 20f); S(f, BoneId.ForeR, -80f);
                    S(f, BoneId.ArmL, 6f, 0, -10f); S(f, BoneId.ForeL, -60f); break;
            }
        }
    }
}
