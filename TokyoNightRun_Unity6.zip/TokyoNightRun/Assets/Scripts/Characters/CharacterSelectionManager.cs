using UnityEngine;
using UnityEngine.UI;

namespace TokyoNightRun
{
    /// <summary>
    /// Character selection screen: full-body 3D preview (drag to rotate), arrows and profile icons to browse all five
    /// runners, SELECT / UNLOCK, and a special COUPLE screen for Trisha and Ulvaan with matching couple skins.
    /// The choice is saved and is the model used in the game scene.
    /// </summary>
    public class CharacterSelectionManager
    {
        public GameObject Root;
        MainMenuController menu;
        MenuBootstrap stage;
        int index;
        bool coupleMode;
        Text nameText, statusText, coinsText, tagText;
        Button actionBtn, coupleBtn, pickA, pickB;
        Image nameBar;
        GameObject singleUi, coupleUi;
        Image[] icons;
        Text[] iconLetters;
        Button[] skinBtns;
        static Sprite circle;

        static Sprite Circle()
        {
            if (circle != null) return circle;
            const int n = 64;
            var tex = new Texture2D(n, n, TextureFormat.RGBA32, false);
            var px = new Color[n * n];
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float d = Vector2.Distance(new Vector2(x, y), new Vector2(n * 0.5f - 0.5f, n * 0.5f - 0.5f)) / (n * 0.5f);
                    px[y * n + x] = new Color(1, 1, 1, Mathf.Clamp01((1f - d) * 18f));
                }
            tex.SetPixels(px); tex.Apply();
            circle = Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f));
            return circle;
        }

        public void Build(RectTransform parent, MainMenuController m, MenuBootstrap s)
        {
            menu = m; stage = s;
            System.Func<float, float, Vector2> V = UIBuilder.V;
            Root = UIBuilder.Rect("Characters", parent, Vector2.zero, Vector2.one).gameObject; // transparent: the 3D preview shows through
            var r = Root.transform;
            UIBuilder.Box(r, "TopBar", new Color(0.16f, 0.05f, 0.25f, 0.85f), V(0f, 0.9f), V(1f, 1f));
            UIBuilder.Label(r, "CHOOSE YOUR RUNNER", 64, UIBuilder.Yellow, TextAnchor.MiddleCenter, V(0.05f, 0.92f), V(0.95f, 0.99f));
            coinsText = UIBuilder.Label(r, "", 40, Color.white, TextAnchor.MiddleCenter, V(0.2f, 0.86f), V(0.8f, 0.91f));
            UIBuilder.Box(r, "BottomBar", new Color(0.16f, 0.05f, 0.25f, 0.88f), V(0f, 0f), V(1f, 0.38f));
            nameBar = UIBuilder.Box(r, "NameBar", Color.white, V(0f, 0.285f), V(1f, 0.298f));
            nameText = UIBuilder.Label(r, "", 78, Color.white, TextAnchor.MiddleCenter, V(0.1f, 0.30f), V(0.9f, 0.375f));
            tagText = UIBuilder.Label(r, "", 32, new Color(1, 1, 1, 0.85f), TextAnchor.MiddleCenter, V(0.06f, 0.255f), V(0.94f, 0.285f), FontStyle.Italic);
            statusText = UIBuilder.Label(r, "", 36, UIBuilder.Yellow, TextAnchor.MiddleCenter, V(0.1f, 0.215f), V(0.9f, 0.255f));
            UIBuilder.MakeButton(r, "<", UIBuilder.Blue, V(0.02f, 0.55f), V(0.15f, 0.62f), () => Step(-1), 70);
            UIBuilder.MakeButton(r, ">", UIBuilder.Blue, V(0.85f, 0.55f), V(0.98f, 0.62f), () => Step(1), 70);
            UIBuilder.Label(r, "Drag to rotate", 30, new Color(1, 1, 1, 0.75f), TextAnchor.MiddleCenter, V(0.3f, 0.865f), V(0.7f, 0.9f), FontStyle.Italic);

            // profile icons (one per character)
            int n = Catalog.Characters.Length;
            icons = new Image[n]; iconLetters = new Text[n];
            singleUi = UIBuilder.Rect("Single", r, Vector2.zero, Vector2.one).gameObject;
            for (int i = 0; i < n; i++)
            {
                int k = i;
                float x0 = 0.04f + i * 0.19f;
                var def = Catalog.Characters[i];
                var ring = UIBuilder.Box(singleUi.transform, "IconRing" + i, Color.white, V(x0, 0.075f), V(x0 + 0.17f, 0.075f + 0.17f * 1080f / 1920f));
                ring.sprite = Circle();
                var face = UIBuilder.Box(ring.transform, "Icon", def.Theme, V(0.08f, 0.08f), V(0.92f, 0.92f));
                face.sprite = Circle();
                icons[i] = ring;
                iconLetters[i] = UIBuilder.Label(face.transform, def.IconLetter, 70, Color.white, TextAnchor.MiddleCenter, Vector2.zero, Vector2.one);
                var btn = ring.gameObject.AddComponent<Button>();
                btn.targetGraphic = ring;
                btn.onClick.AddListener(() => { AudioManager.Play(SfxId.Click); coupleMode = false; index = k; ShowCurrent(); });
            }
            actionBtn = UIBuilder.MakeButton(singleUi.transform, "SELECT", UIBuilder.Green, V(0.05f, 0.005f), V(0.5f, 0.07f), OnAction, 48);
            coupleBtn = UIBuilder.MakeButton(singleUi.transform, "COUPLE", UIBuilder.Pink, V(0.52f, 0.005f), V(0.7f, 0.07f), EnterCouple, 34);
            UIBuilder.MakeButton(singleUi.transform, "BACK", UIBuilder.Grey, V(0.72f, 0.005f), V(0.95f, 0.07f), () => menu.Back(), 40);

            // couple screen: pick either partner and equip a matching couple skin
            coupleUi = UIBuilder.Rect("Couple", r, Vector2.zero, Vector2.one).gameObject;
            UIBuilder.Label(coupleUi.transform, "MATCHING COUPLE SKINS", 40, UIBuilder.Yellow, TextAnchor.MiddleCenter, V(0.05f, 0.165f), V(0.95f, 0.21f));
            skinBtns = new Button[3];
            string[] skinIds = { "outfit_classic", "outfit_couple_sunset", "outfit_couple_ocean" };
            for (int i = 0; i < 3; i++)
            {
                int k = i; string sid = skinIds[i];
                skinBtns[i] = UIBuilder.MakeButton(coupleUi.transform, "", UIBuilder.Purple, V(0.03f + i * 0.325f, 0.095f), V(0.03f + i * 0.325f + 0.31f, 0.16f), () => OnCoupleSkin(sid), 30);
            }
            pickA = UIBuilder.MakeButton(coupleUi.transform, "PLAY AS TRISHA", UIBuilder.Green, V(0.03f, 0.005f), V(0.34f, 0.085f), () => PickPartner(Catalog.CoupleA), 30);
            pickB = UIBuilder.MakeButton(coupleUi.transform, "PLAY AS ULVAAN", UIBuilder.Green, V(0.35f, 0.005f), V(0.66f, 0.085f), () => PickPartner(Catalog.CoupleB), 30);
            UIBuilder.MakeButton(coupleUi.transform, "BACK", UIBuilder.Grey, V(0.68f, 0.005f), V(0.97f, 0.085f), () => { coupleMode = false; ShowCurrent(); }, 38);
        }

        public void Refresh()
        {
            coupleMode = false;
            string sel = SaveManager.Data.selectedCharacter;
            index = 0;
            for (int i = 0; i < Catalog.Characters.Length; i++) if (Catalog.Characters[i].Id == sel) index = i;
            ShowCurrent();
        }

        void Step(int d)
        {
            coupleMode = false;
            index = (index + d + Catalog.Characters.Length) % Catalog.Characters.Length;
            ShowCurrent();
        }

        void ShowCurrent()
        {
            var save = SaveManager.Data;
            coinsText.text = "COINS " + save.coins;
            singleUi.SetActive(!coupleMode);
            coupleUi.SetActive(coupleMode);
            if (coupleMode) { ShowCouple(); return; }

            var c = Catalog.Characters[index];
            stage.SetPreview(c.Id, save.selectedOutfit);
            nameText.text = c.Name.ToUpper();
            nameText.color = c.Theme;
            nameBar.color = c.Theme;
            tagText.text = c.Tagline;
            bool owned = Progression.IsUnlocked(c.Id);
            bool selected = save.selectedCharacter == c.Id;
            statusText.text = owned ? (selected ? "Selected" : "Unlocked") : "Locked - costs " + c.Cost + " coins";
            UIBuilder.SetButtonText(actionBtn, selected ? "SELECTED" : owned ? "SELECT" : "UNLOCK " + c.Cost);
            actionBtn.interactable = !selected;
            coupleBtn.gameObject.SetActive(c.IsCouple);
            for (int i = 0; i < icons.Length; i++)
            {
                bool cur = i == index;
                icons[i].color = cur ? Color.white : new Color(1, 1, 1, 0.25f);
                icons[i].transform.localScale = Vector3.one * (cur ? 1.08f : 0.92f);
                bool o = Progression.IsUnlocked(Catalog.Characters[i].Id);
                iconLetters[i].text = o ? Catalog.Characters[i].IconLetter : "?";
            }
        }

        void EnterCouple()
        {
            coupleMode = true;
            ShowCurrent();
        }

        void ShowCouple()
        {
            var save = SaveManager.Data;
            string outfit = Catalog.OutfitAllowed(Catalog.FindOutfit(save.selectedOutfit), Catalog.CoupleA) ? save.selectedOutfit : Catalog.DefaultOutfit;
            stage.SetCouplePreview(outfit);
            nameText.text = "TRISHA & ULVAAN";
            nameText.color = new Color(1f, 0.75f, 0.85f);
            nameBar.color = new Color(1f, 0.75f, 0.85f);
            tagText.text = "Matching outfits, matching charms, one team.";
            statusText.text = "Both wear the same couple skin";
            string[] ids = { "outfit_classic", "outfit_couple_sunset", "outfit_couple_ocean" };
            for (int i = 0; i < 3; i++)
            {
                var o = Catalog.FindOutfit(ids[i]);
                bool owned = Progression.IsUnlocked(o.Id);
                bool eq = save.selectedOutfit == o.Id;
                string label = i == 0 ? "ORIGINAL" : (i == 1 ? "SUNSET" : "OCEAN");
                UIBuilder.SetButtonText(skinBtns[i], eq ? label + "\nEQUIPPED" : owned ? label + "\nEQUIP" : label + "\nBUY " + o.Cost);
                skinBtns[i].interactable = !eq;
            }
            UIBuilder.SetButtonText(pickA, save.selectedCharacter == Catalog.CoupleA ? "TRISHA SELECTED" : "PLAY AS TRISHA");
            UIBuilder.SetButtonText(pickB, save.selectedCharacter == Catalog.CoupleB ? "ULVAAN SELECTED" : "PLAY AS ULVAAN");
        }

        void OnCoupleSkin(string outfitId)
        {
            // couple skins need a couple character selected so the outfit is allowed
            if (!Catalog.IsCharacterId(SaveManager.Data.selectedCharacter) || !Catalog.FindCharacter(SaveManager.Data.selectedCharacter).IsCouple)
                Progression.Select(Catalog.CoupleA);
            if (!Progression.IsUnlocked(outfitId) && !Progression.TryUnlock(outfitId)) { statusText.text = "Not enough coins!"; return; }
            Progression.Select(outfitId);
            ShowCurrent();
            menu.RefreshHeader();
            stage.CelebrateSelection();
        }

        void PickPartner(string id)
        {
            if (!Progression.IsUnlocked(id) && !Progression.TryUnlock(id)) { statusText.text = "Not enough coins!"; return; }
            Progression.Select(id);
            ShowCurrent();
            menu.RefreshHeader();
            stage.CelebrateSelection();
        }

        void OnAction()
        {
            var c = Catalog.Characters[index];
            if (!Progression.IsUnlocked(c.Id) && !Progression.TryUnlock(c.Id))
            {
                statusText.text = "Not enough coins!";
                return;
            }
            Progression.Select(c.Id);
            ShowCurrent();
            menu.RefreshHeader();
            stage.CelebrateSelection();
        }
    }
}
