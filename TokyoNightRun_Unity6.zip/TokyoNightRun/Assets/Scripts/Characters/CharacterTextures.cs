using System.Collections.Generic;
using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>Small generated fabric / hair textures (64x64) with Holi colour splatters, so clothes are not flat colours.</summary>
    public static class CharacterTextures
    {
        static readonly Dictionary<string, Texture2D> cache = new Dictionary<string, Texture2D>();

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics() { cache.Clear(); }

        public static Texture2D Fabric(string key, int seed, int splats, float weave)
        {
            Texture2D t;
            if (cache.TryGetValue(key, out t) && t != null) return t;
            const int n = 64;
            t = new Texture2D(n, n, TextureFormat.RGBA32, true);
            t.wrapMode = TextureWrapMode.Repeat;
            var px = new Color[n * n];
            var rng = new System.Random(seed);
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float w = 1f - weave * (((x / 2 + y / 2) % 2 == 0) ? 0.08f : 0f);
                    w -= weave * 0.04f * Mathf.PerlinNoise(x * 0.35f + seed, y * 0.35f);
                    px[y * n + x] = new Color(w, w, w, 1f);
                }
            for (int s = 0; s < splats; s++)
            {
                Color sc = Theme.RandomPal(rng);
                float cx = (float)rng.NextDouble() * n, cy = (float)rng.NextDouble() * n, r = 3f + (float)rng.NextDouble() * 6f;
                for (int y = 0; y < n; y++)
                    for (int x = 0; x < n; x++)
                    {
                        float dx = Mathf.Min(Mathf.Abs(x - cx), n - Mathf.Abs(x - cx)), dy = Mathf.Min(Mathf.Abs(y - cy), n - Mathf.Abs(y - cy));
                        float d = Mathf.Sqrt(dx * dx + dy * dy) / r;
                        if (d >= 1f) continue;
                        float a = (1f - d) * 0.55f;
                        px[y * n + x] = Color.Lerp(px[y * n + x], Color.Lerp(sc, Color.white, 0.25f), a);
                    }
            }
            t.SetPixels(px);
            t.Apply(true, true);
            cache[key] = t;
            return t;
        }

        public static Texture2D Hair(string key, int seed)
        {
            Texture2D t;
            if (cache.TryGetValue(key, out t) && t != null) return t;
            const int n = 32;
            t = new Texture2D(n, n, TextureFormat.RGBA32, true);
            t.wrapMode = TextureWrapMode.Repeat;
            var px = new Color[n * n];
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float g = 0.82f + 0.18f * Mathf.PerlinNoise(x * 0.9f + seed, y * 0.08f);
                    px[y * n + x] = new Color(g, g, g, 1f);
                }
            t.SetPixels(px);
            t.Apply(true, true);
            cache[key] = t;
            return t;
        }
    }
}
