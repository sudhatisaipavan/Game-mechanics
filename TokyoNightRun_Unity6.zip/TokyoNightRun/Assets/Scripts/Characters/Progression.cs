namespace TokyoNightRun
{
    /// <summary>Buying and selecting characters, outfits and trails. Pure logic on top of SaveManager.</summary>
    public static class Progression
    {
        public static bool IsUnlocked(string id)
        {
            if (GameConfig.UnlockAllCharactersForTesting && Catalog.IsCharacterId(id)) return true; // first playable build: everyone is available
            return SaveManager.Data.unlocked.Contains(id);
        }

        /// <summary>Spends coins to unlock an item. Returns false if unknown, already owned, or too expensive.</summary>
        public static bool TryUnlock(string id)
        {
            int cost = Catalog.CostOf(id);
            if (cost < 0 || IsUnlocked(id)) return false;
            var d = SaveManager.Data;
            if (d.coins < cost) return false;
            d.coins -= cost;
            d.unlocked.Add(id);
            SaveManager.Save();
            return true;
        }

        /// <summary>Equips an unlocked item. Returns false if it is still locked or the id is unknown.</summary>
        public static bool Select(string id)
        {
            if (!IsUnlocked(id)) return false;
            var d = SaveManager.Data;
            if (id.StartsWith("char_")) d.selectedCharacter = id;
            else if (id.StartsWith("outfit_"))
            {
                if (!Catalog.OutfitAllowed(Catalog.FindOutfit(id), d.selectedCharacter)) return false; // couple skins need Trisha or Ulvaan
                d.selectedOutfit = id;
            }
            else if (id.StartsWith("trail_")) d.selectedTrail = id;
            else return false;
            SaveManager.Save();
            return true;
        }

        public static bool IsSelected(string id)
        {
            var d = SaveManager.Data;
            return d.selectedCharacter == id || d.selectedOutfit == id || d.selectedTrail == id;
        }
    }
}
