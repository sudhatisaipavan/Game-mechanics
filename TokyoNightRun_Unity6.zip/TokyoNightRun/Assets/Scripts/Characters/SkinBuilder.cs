using System.Collections.Generic;
using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>Material slots of a character mesh (one sub-mesh / draw call each).</summary>
    public enum Slot { Skin, Hair, HairTip, Jacket, Inner, Pants, Shoes, Sole, Accent, Accent2, Metal, Glass, Eye, Dark, Lips, Count }

    /// <summary>
    /// Builds one skinned character mesh from lathes, ellipsoids, tori and boxes. Every vertex carries bone weights, so the
    /// result is a genuine SkinnedMeshRenderer mesh that deforms with the bone hierarchy (smooth elbows, knees and spine).
    /// Normals are computed analytically (no seams). All geometry is built in the bind pose (standing, arms down).
    /// </summary>
    public class SkinBuilder
    {
        public readonly List<Transform> Bones = new List<Transform>();
        readonly List<Vector3> verts = new List<Vector3>(8192);
        readonly List<Vector3> norms = new List<Vector3>(8192);
        readonly List<Vector2> uvs = new List<Vector2>(8192);
        readonly List<BoneWeight> weights = new List<BoneWeight>(8192);
        readonly List<int>[] tris = new List<int>[(int)Slot.Count];

        public int VertexCount { get { return verts.Count; } }

        public SkinBuilder()
        {
            for (int i = 0; i < tris.Length; i++) tris[i] = new List<int>(1024);
        }

        public int AddBone(Transform t) { Bones.Add(t); return Bones.Count - 1; }

        // ---- bone weight helpers ----
        public static BoneWeight W(int bone)
        {
            var w = new BoneWeight();
            w.boneIndex0 = bone; w.weight0 = 1f;
            return w;
        }

        /// <summary>Blend of two bones: t = 0 gives all 'a', t = 1 gives all 'b'.</summary>
        public static BoneWeight W(int a, int b, float t)
        {
            t = Mathf.Clamp01(t);
            if (t < 0.002f) return W(a);
            if (t > 0.998f) return W(b);
            var w = new BoneWeight();
            w.boneIndex0 = a; w.weight0 = 1f - t;
            w.boneIndex1 = b; w.weight1 = t;
            return w;
        }

        void AddVertex(Vector3 p, Vector3 n, Vector2 uv, BoneWeight w)
        {
            verts.Add(p); norms.Add(n); uvs.Add(uv); weights.Add(w);
        }

        // ---------------------------------------------------------------- lathe (tube with elliptical rings)
        /// <summary>
        /// A tube made of rings stacked along local Y (ring 0 to last ring, in either direction).
        /// rx/rz = ellipse radii per ring, cx/cz = optional ring centre offsets, ringW = bone weights per ring.
        /// xf places the whole lathe in the model (rotation + translation only, no mirroring).
        /// </summary>
        public void Lathe(float[] y, float[] rx, float[] rz, int segs, Matrix4x4 xf, Slot slot, BoneWeight[] ringW,
            bool capStart, bool capEnd, float[] cx = null, float[] cz = null, float uTile = 1f, float vTile = 1f)
        {
            int rings = y.Length;
            if (rings < 2) return;
            Quaternion q = xf.rotation;
            int baseIdx = verts.Count;
            bool ascending = y[rings - 1] >= y[0];
            for (int i = 0; i < rings; i++)
            {
                float ox = cx != null ? cx[i] : 0f, oz = cz != null ? cz[i] : 0f;
                int i0 = Mathf.Max(0, i - 1), i1 = Mathf.Min(rings - 1, i + 1);
                float dy = y[i1] - y[i0];
                float dr = ((rx[i1] + rz[i1]) - (rx[i0] + rz[i0])) * 0.5f;
                float slope = Mathf.Abs(dy) > 1e-5f ? dr / dy : 0f;
                float rxi = Mathf.Max(rx[i], 1e-4f), rzi = Mathf.Max(rz[i], 1e-4f);
                for (int j = 0; j <= segs; j++)
                {
                    float a = j / (float)segs * Mathf.PI * 2f;
                    float c = Mathf.Cos(a), s = Mathf.Sin(a);
                    Vector3 p = new Vector3(ox + rxi * c, y[i], oz + rzi * s);
                    Vector3 n = new Vector3(c / rxi, 0f, s / rzi).normalized;
                    n = new Vector3(n.x, -slope, n.z).normalized;
                    AddVertex(xf.MultiplyPoint3x4(p), q * n, new Vector2(j / (float)segs * uTile, i / (float)(rings - 1) * vTile), ringW[i]);
                }
            }
            int stride = segs + 1;
            var t = tris[(int)slot];
            for (int i = 0; i < rings - 1; i++)
                for (int j = 0; j < segs; j++)
                {
                    int p = baseIdx + i * stride + j, qd = p + stride, r = p + 1, s2 = qd + 1;
                    if (ascending) { t.Add(p); t.Add(qd); t.Add(r); t.Add(qd); t.Add(s2); t.Add(r); }
                    else { t.Add(p); t.Add(r); t.Add(qd); t.Add(qd); t.Add(r); t.Add(s2); }
                }
            float dir = ascending ? 1f : -1f;
            if (capStart) Cap(0, y, rx, rz, cx, cz, segs, xf, q, slot, ringW[0], -dir, ascending, true);
            if (capEnd) Cap(rings - 1, y, rx, rz, cx, cz, segs, xf, q, slot, ringW[rings - 1], dir, ascending, false);
        }

        void Cap(int ring, float[] y, float[] rx, float[] rz, float[] cx, float[] cz, int segs, Matrix4x4 xf, Quaternion q, Slot slot,
            BoneWeight w, float normalY, bool ascending, bool isStart)
        {
            float ox = cx != null ? cx[ring] : 0f, oz = cz != null ? cz[ring] : 0f;
            Vector3 n = q * new Vector3(0f, normalY, 0f);
            int centre = verts.Count;
            AddVertex(xf.MultiplyPoint3x4(new Vector3(ox, y[ring], oz)), n, new Vector2(0.5f, 0.5f), w);
            int first = verts.Count;
            for (int j = 0; j <= segs; j++)
            {
                float a = j / (float)segs * Mathf.PI * 2f;
                AddVertex(xf.MultiplyPoint3x4(new Vector3(ox + rx[ring] * Mathf.Cos(a), y[ring], oz + rz[ring] * Mathf.Sin(a))), n,
                    new Vector2(Mathf.Cos(a) * 0.5f + 0.5f, Mathf.Sin(a) * 0.5f + 0.5f), w);
            }
            var t = tris[(int)slot];
            // a cap facing -Y (normalY < 0) uses (c, j, j+1); facing +Y uses (c, j+1, j)
            bool facingDown = normalY < 0f;
            for (int j = 0; j < segs; j++)
            {
                if (facingDown) { t.Add(centre); t.Add(first + j); t.Add(first + j + 1); }
                else { t.Add(centre); t.Add(first + j + 1); t.Add(first + j); }
            }
        }

        // ---------------------------------------------------------------- ellipsoid
        public void Ellipsoid(Vector3 c, Vector3 radii, Quaternion rot, Slot slot, BoneWeight w, int lon = 12, int lat = 8, float uTile = 1f)
        {
            int baseIdx = verts.Count;
            Vector3 inv = new Vector3(1f / Mathf.Max(radii.x, 1e-4f), 1f / Mathf.Max(radii.y, 1e-4f), 1f / Mathf.Max(radii.z, 1e-4f));
            for (int i = 0; i <= lat; i++)
            {
                float phi = Mathf.Lerp(-Mathf.PI * 0.5f, Mathf.PI * 0.5f, i / (float)lat);
                float yy = Mathf.Sin(phi), rr = Mathf.Cos(phi);
                for (int j = 0; j <= lon; j++)
                {
                    float a = j / (float)lon * Mathf.PI * 2f;
                    Vector3 d = new Vector3(Mathf.Cos(a) * rr, yy, Mathf.Sin(a) * rr);
                    Vector3 p = Vector3.Scale(d, radii);
                    Vector3 n = Vector3.Scale(d, inv); // gradient of the ellipsoid equation (up to scale)
                    n = Vector3.Scale(n, inv).normalized;
                    AddVertex(c + rot * p, rot * n, new Vector2(j / (float)lon * uTile, i / (float)lat), w);
                }
            }
            int stride = lon + 1;
            var t = tris[(int)slot];
            for (int i = 0; i < lat; i++)
                for (int j = 0; j < lon; j++)
                {
                    int p = baseIdx + i * stride + j, qd = p + stride, r = p + 1, s2 = qd + 1;
                    t.Add(p); t.Add(qd); t.Add(r); t.Add(qd); t.Add(s2); t.Add(r);
                }
        }

        public void Ellipsoid(Vector3 c, Vector3 radii, Slot slot, int bone, int lon = 12, int lat = 8)
        { Ellipsoid(c, radii, Quaternion.identity, slot, W(bone), lon, lat); }

        // ---------------------------------------------------------------- torus (rings, hoops, headphone bands)
        /// <summary>Torus lying in the local XZ plane (a ring around the Y axis). Rotate it with 'rot'.</summary>
        public void Torus(Vector3 c, float major, float minor, Quaternion rot, Slot slot, BoneWeight w, int segMajor = 18, int segMinor = 6)
        {
            int baseIdx = verts.Count;
            for (int i = 0; i <= segMajor; i++)
            {
                float u = i / (float)segMajor * Mathf.PI * 2f;
                float cu = Mathf.Cos(u), su = Mathf.Sin(u);
                for (int j = 0; j <= segMinor; j++)
                {
                    float v = j / (float)segMinor * Mathf.PI * 2f;
                    float cv = Mathf.Cos(v), sv = Mathf.Sin(v);
                    Vector3 p = new Vector3((major + minor * cv) * cu, minor * sv, (major + minor * cv) * su);
                    Vector3 n = new Vector3(cv * cu, sv, cv * su);
                    AddVertex(c + rot * p, rot * n, new Vector2(i / (float)segMajor, j / (float)segMinor), w);
                }
            }
            int stride = segMinor + 1;
            var t = tris[(int)slot];
            for (int i = 0; i < segMajor; i++)
                for (int j = 0; j < segMinor; j++)
                {
                    int a = baseIdx + i * stride + j, b = a + stride, cc = a + 1, d = b + 1; // a=(u,v) b=(u+1,v) c=(u,v+1) d=(u+1,v+1)
                    t.Add(a); t.Add(cc); t.Add(b);
                    t.Add(b); t.Add(cc); t.Add(d);
                }
        }

        // ---------------------------------------------------------------- box (flat shaded)
        public void Box(Vector3 c, Vector3 size, Quaternion rot, Slot slot, BoneWeight w)
        {
            Vector3 h = size * 0.5f;
            var t = tris[(int)slot];
            AddBoxFace(c, rot, Vector3.right, Vector3.forward, Vector3.up, h.x, h.z, h.y, slot, w);
            AddBoxFace(c, rot, Vector3.left, Vector3.back, Vector3.up, h.x, h.z, h.y, slot, w);
            AddBoxFace(c, rot, Vector3.up, Vector3.right, Vector3.forward, h.y, h.x, h.z, slot, w);
            AddBoxFace(c, rot, Vector3.down, Vector3.right, Vector3.back, h.y, h.x, h.z, slot, w);
            AddBoxFace(c, rot, Vector3.forward, Vector3.left, Vector3.up, h.z, h.x, h.y, slot, w);
            AddBoxFace(c, rot, Vector3.back, Vector3.right, Vector3.up, h.z, h.x, h.y, slot, w);
        }

        void AddBoxFace(Vector3 c, Quaternion rot, Vector3 n, Vector3 uA, Vector3 vA, float hn, float hu, float hv, Slot slot, BoneWeight w)
        {
            Vector3 centre = n * hn;
            Vector3 p0 = centre - uA * hu - vA * hv, p1 = centre - uA * hu + vA * hv, p2 = centre + uA * hu - vA * hv, p3 = centre + uA * hu + vA * hv;
            bool flip = Vector3.Dot(Vector3.Cross(p1 - p0, p2 - p0), n) < 0f;
            int i0 = verts.Count;
            Vector3 wn = rot * n;
            AddVertex(c + rot * p0, wn, new Vector2(0, 0), w);
            AddVertex(c + rot * p1, wn, new Vector2(0, 1), w);
            AddVertex(c + rot * p2, wn, new Vector2(1, 0), w);
            AddVertex(c + rot * p3, wn, new Vector2(1, 1), w);
            var t = tris[(int)slot];
            if (!flip) { t.Add(i0); t.Add(i0 + 1); t.Add(i0 + 2); t.Add(i0 + 1); t.Add(i0 + 3); t.Add(i0 + 2); }
            else { t.Add(i0); t.Add(i0 + 2); t.Add(i0 + 1); t.Add(i0 + 1); t.Add(i0 + 2); t.Add(i0 + 3); }
        }

        // ---------------------------------------------------------------- finish
        /// <summary>Creates the mesh with one sub-mesh per used slot. 'smr' defines the mesh space for the bind poses.</summary>
        public Mesh Build(Transform smr, List<Slot> usedSlots, string name)
        {
            var mesh = new Mesh();
            mesh.name = name;
            mesh.SetVertices(verts);
            mesh.SetNormals(norms);
            mesh.SetUVs(0, uvs);
            mesh.boneWeights = weights.ToArray();
            int count = 0;
            for (int i = 0; i < tris.Length; i++) if (tris[i].Count > 0) count++;
            mesh.subMeshCount = count;
            int sub = 0;
            for (int i = 0; i < tris.Length; i++)
            {
                if (tris[i].Count == 0) continue;
                mesh.SetTriangles(tris[i], sub++);
                usedSlots.Add((Slot)i);
            }
            var bind = new Matrix4x4[Bones.Count];
            for (int i = 0; i < bind.Length; i++) bind[i] = Bones[i].worldToLocalMatrix * smr.localToWorldMatrix;
            mesh.bindposes = bind;
            mesh.RecalculateBounds();
            return mesh;
        }
    }
}
