using System.Collections.Generic;
using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>Coins, gulal packets, water balloons, festival tokens and power-up pickups.</summary>
    public class Collectible : MonoBehaviour
    {
        /// <summary>All active collectibles (used by the Color Magnet, no scene searching needed).</summary>
        public static readonly List<Collectible> Active = new List<Collectible>(128);

        public CollectibleType Type;
        public PowerUpType PowerType;
        public Color PowderColor = Color.white;
        public float SpinSpeed = 180f;

        bool collected;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics() { Active.Clear(); }

        void OnEnable() { collected = false; Active.Add(this); }
        void OnDisable() { Active.Remove(this); }

        void Update()
        {
            transform.Rotate(0f, SpinSpeed * Time.deltaTime, 0f, Space.World);
        }

        /// <summary>Marks as collected (once) and returns it to the pool. Returns false if already collected.</summary>
        public bool TryCollect()
        {
            if (collected) return false;
            collected = true;
            var po = GetComponent<PooledObject>();
            if (po != null) po.Release(); else gameObject.SetActive(false);
            return true;
        }
    }
}
