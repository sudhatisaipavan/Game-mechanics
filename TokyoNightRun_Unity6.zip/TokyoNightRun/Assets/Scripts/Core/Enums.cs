namespace TokyoNightRun
{
    public enum GameState { Ready, Playing, Paused, GameOver }
    public enum ObstacleType { Cart, Barricade, Trolley, TrainStatic, TrainMoving, TrainCargo, Puddle, Banner, SupplyStack }
    /// <summary>How the player must deal with an obstacle.</summary>
    public enum ObstacleKind { Solid, Low, High, Slow }
    public enum CollectibleType { Coin, Gulal, WaterBalloon, Token, PowerUp }
    public enum PowerUpType { Magnet, Pichkari, Shield, Multiplier }
    public enum SfxId { Coin, Jump, Slide, Land, Hit, PowerUp, Burst, Click, GameOver, Milestone, Splash, Gulal }
    public enum MissionType { Coins, Distance, Gulal, Balloons }
    public enum InputCommand { None, Left, Right, Jump, Slide }
}
