using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// The only object the Game scene needs. On Awake it creates the camera, light, player, world, effects and UI
    /// and connects them with plain references (nothing to drag in the Inspector).
    /// </summary>
    public class GameBootstrap : MonoBehaviour
    {
        void Awake()
        {
            GameSettings.Apply();
            MissionManager.EnsureToday();

            // --- camera ---
            var camGo = new GameObject("Main Camera");
            camGo.tag = "MainCamera";
            var cam = camGo.AddComponent<Camera>();
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.nearClipPlane = 0.3f;
            cam.farClipPlane = 220f;
            cam.allowHDR = true;
            cam.allowMSAA = true;
            camGo.AddComponent<AudioListener>();
            var follow = camGo.AddComponent<CameraFollow>();
            camGo.AddComponent<CurvedWorld>();

            // --- light & fog (no real-time shadows on mobile) ---
            var lightGo = new GameObject("Sun");
            var sun = lightGo.AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.shadows = LightShadows.None;
            sun.intensity = Theme.Current.SunIntensity;
            lightGo.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogStartDistance = Theme.Current.FogStart;
            RenderSettings.fogEndDistance = Theme.Current.FogEnd;

            // --- sky, clouds and post-processing ---
            var sky = SkyDome.Create(cam);
            PostFx.SetupCamera(cam);

            // --- player ---
            var playerGo = new GameObject("Player");
            playerGo.tag = "Player";
            var player = playerGo.AddComponent<PlayerController>(); // adds Rigidbody + BoxCollider
            var input = playerGo.AddComponent<PlayerInput>();
            var collision = playerGo.AddComponent<PlayerCollision>();
            var save = SaveManager.Data;
            var visual = RunnerBuilder.Build(Catalog.FindCharacter(save.selectedCharacter), Catalog.FindOutfit(save.selectedOutfit));
            visual.transform.SetParent(playerGo.transform, false);
            player.Visual = visual;
            player.Controls = input;

            // --- managers ---
            var root = new GameObject("Game");
            var gm = root.AddComponent<GameManager>();
            var score = root.AddComponent<ScoreManager>();
            var power = root.AddComponent<PowerUpManager>();
            var atmosphere = root.AddComponent<AtmosphereController>();

            var fxGo = new GameObject("Effects");
            var fx = fxGo.AddComponent<EffectsManager>();
            fx.Init(playerGo.transform);

            var trackGo = new GameObject("Track");
            var track = trackGo.AddComponent<TrackManager>();

            var uiGo = new GameObject("UI");
            var ui = uiGo.AddComponent<UIManager>();

            gm.Player = player; gm.Score = score; gm.Powerups = power; gm.Track = track;
            gm.Cam = follow; gm.Fx = fx; gm.UI = ui;

            follow.Target = playerGo.transform;
            player.Init(gm);
            collision.Init(gm);
            power.Init(gm);
            atmosphere.Init(cam, sun, gm);
            atmosphere.SetSky(sky);
            track.Init(playerGo.transform, gm, System.Environment.TickCount);
            ui.Init(gm);

            follow.Snap();
            AudioManager.PlayMusic();
            SceneLoader.FadeIn();
            gm.Begin();
        }
    }
}
