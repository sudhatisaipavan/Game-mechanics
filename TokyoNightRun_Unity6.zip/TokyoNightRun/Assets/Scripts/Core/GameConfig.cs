using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// All gameplay tuning values live here so you can balance the game in one place.
    /// </summary>
    public static class GameConfig
    {
        public const string MenuScene = "MainMenu";
        public const string GameScene = "Game";

        // Lanes / movement
        public const float LaneWidth = 2.2f;
        public const int LaneCount = 3;
        public const float StartSpeed = 12f;
        public const float MaxSpeed = 30f;
        public const float SpeedRampPerSecond = 0.12f;
        public const float LaneSwitchSpeed = 16f;
        public const float JumpVelocity = 9f;
        public const float Gravity = 26f;
        public const float FastFallVelocity = -20f;
        public const float SlideDuration = 0.8f;
        public const float MaxDeltaTime = 0.04f; // clamps frame spikes so we never tunnel through obstacles

        // Testing switch: while true every character is available from the first launch (the first playable build).
        // Set to false to use the coin prices in Catalog.cs (progression). Not const so unit tests can toggle it.
        public static bool UnlockAllCharactersForTesting = true;

        // Railway
        public const float RailHalfGauge = 0.6f;     // rails sit at laneX +/- this
        public const float TrainLength = 9f;         // must stay below RowSpacing so rows never overlap
        public const float CargoLength = 6f;
        public const float TrainHeight = 3.6f;
        public const float MovingTrainSpeed = 4.5f;  // towards the player, only while the player is close
        public const float MovingTrainActivateDistance = 30f;

        // World
        public const float SegmentLength = 30f;
        public const int SegmentsAhead = 6;
        public const float RecycleBehind = 22f;
        public const int RowsPerSegment = 3;
        public const float RowSpacing = 10f;
        public const float ZoneLength = 600f;
        public const float MinActionRowGap = 30f; // min distance between "must jump / must slide" rows

        // Score / rewards
        public const int CoinScore = 10;
        public const int GulalScore = 25;
        public const int BalloonScore = 15;
        public const int TokenScore = 100;
        public const float EnergyMax = 100f;
        public const float EnergyPerGulal = 10f;
        public const int BurstBonusScore = 500;
        public const int BurstBonusCoins = 10;
        public const float BurstInvulnerableSeconds = 2.5f;
        public const int MilestoneEveryMeters = 500;
        public const int MilestoneBonusCoins = 10;

        // Power ups
        public const float BoostSpeedMultiplier = 1.5f;
        public const float ScoreMultiplierValue = 2f;
        public const float MagnetRadius = 8f;
        public const float MagnetPullSpeed = 28f;
        public const float SlowMultiplier = 0.65f;
        public const float SlowSeconds = 1.5f;
        public const float ShieldGraceSeconds = 1f;

        public static float PowerUpDuration(PowerUpType t)
        {
            switch (t)
            {
                case PowerUpType.Magnet: return 10f;
                case PowerUpType.Pichkari: return 6f;
                case PowerUpType.Shield: return 15f;
                default: return 12f;
            }
        }

        public static Color Hex(int rgb)
        {
            return new Color(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f, 1f);
        }

        public static readonly Color[] HoliColors =
        {
            Hex(0xE91E8C), Hex(0xFFD400), Hex(0x1E88E5), Hex(0xFF6F00), Hex(0x8E24AA), Hex(0x43A047)
        };

        public static readonly string[] MilestoneMessages =
        {
            "Holi Hai! Keep running!", "Rang barse! Amazing!", "Colour storm! Unstoppable!",
            "Bura na mano, Holi hai!", "Festival legend!", "What a run!"
        };

        public static readonly string[] GameOverMessages =
        {
            "Bura na mano, Holi hai! Run again!", "Every colour counts. Try once more!",
            "Great run! The festival awaits.", "Gulal in the air, spirit in your stride!"
        };
    }
}
