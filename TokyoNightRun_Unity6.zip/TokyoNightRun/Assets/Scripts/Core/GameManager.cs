using System;
using System.Collections;
using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Central game rules: run state, speed, hits, collecting, pause, game over. Other systems are plain
    /// references assigned by GameBootstrap (no scene searching). One instance per Game scene.
    /// </summary>
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        public GameState State { get; private set; }

        [NonSerialized] public PlayerController Player;
        [NonSerialized] public ScoreManager Score;
        [NonSerialized] public PowerUpManager Powerups;
        [NonSerialized] public TrackManager Track;
        [NonSerialized] public CameraFollow Cam;
        [NonSerialized] public EffectsManager Fx;
        [NonSerialized] public UIManager UI;

        public event Action RunStarted;
        public event Action RunEnded;
        public event Action<bool> PauseChanged;

        float runTime, slowTimer, graceTimer;
        bool runEnded;
        Coroutine countdown;

        public float RunTime { get { return runTime; } }
        public float BaseSpeed { get { return Mathf.Min(GameConfig.MaxSpeed, GameConfig.StartSpeed + GameConfig.SpeedRampPerSecond * runTime); } }
        public float Difficulty01 { get { return Mathf.InverseLerp(GameConfig.StartSpeed, GameConfig.MaxSpeed, BaseSpeed); } }

        public float CurrentSpeed
        {
            get
            {
                float s = BaseSpeed;
                if (Powerups != null && Powerups.BoostActive) s *= GameConfig.BoostSpeedMultiplier;
                if (slowTimer > 0f) s *= GameConfig.SlowMultiplier;
                return s;
            }
        }

        public bool IsInvulnerable { get { return graceTimer > 0f || (Powerups != null && Powerups.BoostActive); } }

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            State = GameState.Ready;
            Time.timeScale = 1f;
        }

        void OnDestroy()
        {
            if (Score != null) Score.MilestoneReached -= OnMilestone;
            if (Instance == this) Instance = null;
            Time.timeScale = 1f;
        }

        /// <summary>Called once by GameBootstrap after everything is wired.</summary>
        public void Begin()
        {
            Score.MilestoneReached -= OnMilestone; // avoid duplicate subscription
            Score.MilestoneReached += OnMilestone;
            if (countdown != null) StopCoroutine(countdown);
            countdown = StartCoroutine(CountdownThenStart());
        }

        IEnumerator CountdownThenStart()
        {
            State = GameState.Ready;
            string[] steps = { "3", "2", "1", "GO!" };
            for (int i = 0; i < steps.Length; i++)
            {
                UI.SetCountdown(steps[i]);
                yield return new WaitForSecondsRealtime(i == steps.Length - 1 ? 0.4f : 0.55f);
            }
            UI.SetCountdown(null);
            StartRun();
        }

        void StartRun()
        {
            runTime = 0f; slowTimer = 0f; graceTimer = 0f; runEnded = false;
            Score.ResetRun();
            Powerups.ResetAll();
            State = GameState.Playing;
            Time.timeScale = 1f;
            AudioManager.PlayMusic();
            if (RunStarted != null) RunStarted();
        }

        void Update()
        {
            if (Input.GetKeyDown(KeyCode.Escape)) // Android back button
            {
                if (State == GameState.Playing) Pause();
                else if (State == GameState.Paused) Resume();
                else if (State == GameState.GameOver) GoToMenu();
            }
            if (State != GameState.Playing) return;

            float dt = Mathf.Min(Time.deltaTime, GameConfig.MaxDeltaTime);
            runTime += dt;
            if (slowTimer > 0f) slowTimer -= dt;
            if (graceTimer > 0f) graceTimer -= dt;
            Score.Tick(dt, CurrentSpeed, Powerups.ScoreMultiplier);
        }

        void OnApplicationPause(bool paused) { if (paused && State == GameState.Playing) Pause(); }
        void OnApplicationFocus(bool focus) { if (!focus && State == GameState.Playing) Pause(); }

        // ---------- pause / navigation ----------
        public void Pause()
        {
            if (State != GameState.Playing) return;
            State = GameState.Paused;
            Time.timeScale = 0f;
            AudioManager.SetDucked(true);
            UI.ShowPause(true);
            if (PauseChanged != null) PauseChanged(true);
        }

        public void Resume()
        {
            if (State != GameState.Paused) return;
            State = GameState.Playing;
            Time.timeScale = 1f;
            AudioManager.SetDucked(false);
            Player.Controls.Clear();
            UI.ShowPause(false);
            if (PauseChanged != null) PauseChanged(false);
        }

        public void Restart() { AudioManager.SetDucked(false); SceneLoader.Load(GameConfig.GameScene); }
        public void GoToMenu() { AudioManager.SetDucked(false); SceneLoader.Load(GameConfig.MenuScene); }

        public void GrantGrace(float seconds) { graceTimer = Mathf.Max(graceTimer, seconds); }

        // ---------- hits ----------
        public void HandleObstacleHit(Obstacle o)
        {
            if (State != GameState.Playing) return;
            Vector3 pos = o.transform.position + Vector3.up;

            if (o.Kind == ObstacleKind.Slow) // puddle: slows you, never kills
            {
                if (!IsInvulnerable)
                {
                    slowTimer = GameConfig.SlowSeconds;
                    Fx.Splash(pos);
                    AudioManager.Play(SfxId.Splash);
                }
                return;
            }
            if (IsInvulnerable)
            {
                Fx.Powder(pos, Theme.RandomPal());
                o.Smash();
                return;
            }
            if (Powerups.ShieldActive)
            {
                Powerups.ConsumeShield();
                graceTimer = Mathf.Max(graceTimer, GameConfig.ShieldGraceSeconds);
                Fx.BigBurst(pos);
                Cam.Shake(0.5f);
                AudioManager.Play(SfxId.Hit);
                o.Smash();
                return;
            }
            EndRun();
        }

        void EndRun()
        {
            if (runEnded) return; // the run ends exactly once
            runEnded = true;
            State = GameState.GameOver;
            Time.timeScale = 1f;
            Powerups.ResetAll();

            var s = Score.Stats;
            var save = SaveManager.Data;
            bool newBest = s.Score > save.bestScore;
            if (newBest) save.bestScore = s.Score;
            save.bestDistance = Mathf.Max(save.bestDistance, (int)s.Distance);
            save.coins += s.Coins;
            save.tokens += s.Tokens;
            save.totalGulal += s.Gulal;
            save.totalRuns++;
            MissionManager.ReportRun(s);
            SaveManager.Save();

            Cam.Shake(1f);
            Fx.Powder(Player.transform.position + Vector3.up, new Color(1f, 0.9f, 0.7f, 0.9f));
            AudioManager.Play(SfxId.Hit);
            AudioManager.Vibrate();
            if (RunEnded != null) RunEnded();
            StartCoroutine(ShowGameOverAfterDelay(newBest));
        }

        IEnumerator ShowGameOverAfterDelay(bool newBest)
        {
            yield return new WaitForSecondsRealtime(0.9f);
            AudioManager.Play(SfxId.GameOver);
            string msg = Theme.Current.GameOvers[UnityEngine.Random.Range(0, Theme.Current.GameOvers.Length)];
            UI.ShowGameOver(Score.Stats, newBest, msg);
        }

        // ---------- collecting ----------
        public void HandleCollected(Collectible c)
        {
            if (State != GameState.Playing) return;
            Vector3 pos = c.transform.position + Vector3.up * 0.8f; // read position BEFORE the object returns to its pool
            CollectibleType type = c.Type;
            Color pc = c.PowderColor;
            PowerUpType pt = c.PowerType;
            if (!c.TryCollect()) return;

            var stats = Score.Stats;
            switch (type)
            {
                case CollectibleType.Coin:
                    stats.AddCoins(1, Powerups.ScoreMultiplier);
                    Fx.Sparkle(pos); Fx.CoinFly(pos); AudioManager.Play(SfxId.Coin);
                    break;
                case CollectibleType.Gulal:
                    stats.AddGulal(1);
                    Fx.Powder(pos, pc); AudioManager.Play(SfxId.Gulal);
                    break;
                case CollectibleType.WaterBalloon:
                    stats.AddBalloon();
                    Fx.Splash(pos); Fx.Powder(pos, pc); AudioManager.Play(SfxId.Splash);
                    break;
                case CollectibleType.Token:
                    stats.AddToken();
                    Fx.Sparkle(pos); Fx.Powder(pos, pc); AudioManager.Play(SfxId.PowerUp);
                    break;
                case CollectibleType.PowerUp:
                    Powerups.Activate(pt);
                    Fx.Powder(pos, pc);
                    break;
            }
            if (Player.Visual != null) Player.Visual.Pop();
        }

        // ---------- colour burst & milestones ----------
        /// <summary>Spends the full Color Energy meter for a celebration, bonus points/coins and a moment of safety.</summary>
        public bool TryColorBurst()
        {
            if (State != GameState.Playing) return false;
            if (!Score.Stats.TryConsumeEnergy()) return false;
            Score.Stats.AddBonusScore(GameConfig.BurstBonusScore);
            Score.Stats.AddBonusCoins(GameConfig.BurstBonusCoins);
            GrantGrace(GameConfig.BurstInvulnerableSeconds);
            Fx.BigBurst(Player.transform.position + new Vector3(0, 1.5f, 3f));
            Cam.Shake(0.4f);
            AudioManager.Play(SfxId.Burst);
            UI.Flash(Theme.RandomPal());
            UI.Toast(Theme.Current.BurstToast + "  +" + GameConfig.BurstBonusScore);
            return true;
        }

        void OnMilestone(int meters)
        {
            Score.Stats.AddBonusCoins(GameConfig.MilestoneBonusCoins);
            Fx.BigBurst(Player.transform.position + new Vector3(0, 2f, 5f));
            Cam.Shake(0.2f);
            AudioManager.Play(SfxId.Milestone);
            string msg = Theme.Current.Milestones[UnityEngine.Random.Range(0, Theme.Current.Milestones.Length)];
            UI.Toast(meters + " m!  " + msg + "  +" + GameConfig.MilestoneBonusCoins + " coins");
        }
    }
}
