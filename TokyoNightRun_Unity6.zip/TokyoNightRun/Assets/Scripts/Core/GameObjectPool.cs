using System;
using System.Collections.Generic;
using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>Marker added to every pooled object so it knows which pool owns it.</summary>
    public class PooledObject : MonoBehaviour
    {
        public GameObjectPool Pool;
        public bool InPool;
        public void Release()
        {
            if (Pool != null) Pool.Release(gameObject);
            else gameObject.SetActive(false);
        }
    }

    /// <summary>Simple reusable-object pool. Objects are created lazily by a factory function.</summary>
    public class GameObjectPool
    {
        readonly Func<GameObject> factory;
        readonly Stack<GameObject> free = new Stack<GameObject>();
        readonly Transform root;

        public int CreatedCount { get; private set; }
        public int ActiveCount { get; private set; }

        public GameObjectPool(string name, Func<GameObject> factory, Transform parent, int prewarm)
        {
            this.factory = factory;
            root = new GameObject("Pool_" + name).transform;
            if (parent != null) root.SetParent(parent, false);
            for (int i = 0; i < prewarm; i++)
            {
                var go = Create();
                ActiveCount++; // Return() decrements, so balance it for newly created objects
                Return(go.GetComponent<PooledObject>());
            }
        }

        GameObject Create()
        {
            var go = factory();
            var po = go.GetComponent<PooledObject>();
            if (po == null) po = go.AddComponent<PooledObject>();
            po.Pool = this;
            po.InPool = false;
            CreatedCount++;
            return go;
        }

        public GameObject Get(Transform parent)
        {
            GameObject go = null;
            while (free.Count > 0 && go == null) go = free.Pop();
            if (go == null) go = Create();
            var po = go.GetComponent<PooledObject>();
            po.InPool = false;
            ActiveCount++;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = Vector3.zero;
            go.transform.localRotation = Quaternion.identity;
            go.SetActive(true);
            return go;
        }

        public void Release(GameObject go)
        {
            if (go == null) return;
            var po = go.GetComponent<PooledObject>();
            if (po == null || po.InPool) return; // protects against double release
            Return(po);
        }

        void Return(PooledObject po)
        {
            po.InPool = true;
            ActiveCount--;
            po.gameObject.SetActive(false);
            po.transform.SetParent(root, false);
            free.Push(po.gameObject);
        }
    }
}
