using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>Applies the saved settings (graphics quality, frame rate, volumes) to Unity.</summary>
    public static class GameSettings
    {
        public static void Apply()
        {
            var d = SaveManager.Data;
            QualitySettings.vSyncCount = 0;
            QualitySettings.shadows = ShadowQuality.Disable; // real-time shadows are too expensive on mid-range phones
            QualitySettings.pixelLightCount = 1;
            switch (d.quality)
            {
                case 0: Application.targetFrameRate = 30; QualitySettings.antiAliasing = 0; EffectsManager.Density = 0.5f; break;
                case 2: Application.targetFrameRate = 60; QualitySettings.antiAliasing = 2; EffectsManager.Density = 1.5f; break;
                default: Application.targetFrameRate = 60; QualitySettings.antiAliasing = 0; EffectsManager.Density = 1f; break;
            }
            PostFx.ApplyQuality(d.quality);
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            Screen.orientation = ScreenOrientation.Portrait;
            if (Application.isPlaying) AudioManager.Instance.ApplyVolumes();
        }

        public static string QualityName(int q) { return q == 0 ? "LOW" : q == 2 ? "HIGH" : "MEDIUM"; }
    }
}
