using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>Plain data + rules for one run's score. No scene dependencies, so it is unit-testable.</summary>
    public class RunStats
    {
        public float Distance;
        public int Coins, Gulal, Tokens, Balloons;
        public float Energy;
        float scoreRaw;

        public int Score { get { return (int)scoreRaw; } }
        public bool EnergyFull { get { return Energy >= GameConfig.EnergyMax - 0.001f; } }

        public void AddDistance(float meters, float multiplier)
        {
            if (meters <= 0f) return;
            Distance += meters;
            scoreRaw += meters * Mathf.Max(1f, multiplier);
        }

        public void AddCoins(int n, float multiplier)
        {
            if (n <= 0) return;
            Coins += n;
            scoreRaw += n * GameConfig.CoinScore * Mathf.Max(1f, multiplier);
        }

        public void AddGulal(int n)
        {
            if (n <= 0) return;
            Gulal += n;
            Energy = Mathf.Min(GameConfig.EnergyMax, Energy + n * GameConfig.EnergyPerGulal);
            scoreRaw += n * GameConfig.GulalScore;
        }

        public void AddBalloon() { Balloons++; scoreRaw += GameConfig.BalloonScore; }
        public void AddToken() { Tokens++; scoreRaw += GameConfig.TokenScore; }
        public void AddBonusScore(int pts) { if (pts > 0) scoreRaw += pts; }
        public void AddBonusCoins(int n) { if (n > 0) Coins += n; } // bonus coins add no score

        /// <summary>Spends a full energy meter. Returns false if the meter is not full.</summary>
        public bool TryConsumeEnergy()
        {
            if (!EnergyFull) return false;
            Energy = 0f;
            return true;
        }
    }
}
