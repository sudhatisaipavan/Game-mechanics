using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace TokyoNightRun
{
    /// <summary>Fades to black, loads a scene, fades back in. Persists between scenes (never duplicated).</summary>
    public class SceneLoader : MonoBehaviour
    {
        static SceneLoader instance;
        Image fade;
        bool loading;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics() { instance = null; }

        static void Ensure()
        {
            if (instance != null) return;
            var go = new GameObject("SceneLoader");
            DontDestroyOnLoad(go);
            instance = go.AddComponent<SceneLoader>();
            var canvas = go.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 1000;
            var imgGo = new GameObject("Fade");
            imgGo.transform.SetParent(go.transform, false);
            instance.fade = imgGo.AddComponent<Image>();
            instance.fade.color = new Color(0, 0, 0, 0);
            instance.fade.raycastTarget = false;
            var rt = instance.fade.rectTransform;
            rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.offsetMin = rt.offsetMax = Vector2.zero;
        }

        public static void Load(string scene)
        {
            Ensure();
            if (instance.loading) return;
            instance.StartCoroutine(instance.Run(scene));
        }

        /// <summary>Call from a scene's bootstrap so the scene fades in from black.</summary>
        public static void FadeIn()
        {
            Ensure();
            instance.fade.color = new Color(0, 0, 0, 1f);
            instance.StartCoroutine(instance.Fade(1f, 0f, 0.35f));
        }

        IEnumerator Run(string scene)
        {
            loading = true;
            Time.timeScale = 1f;
            fade.raycastTarget = true; // block taps while loading
            yield return Fade(fade.color.a, 1f, 0.25f);
            var op = SceneManager.LoadSceneAsync(scene);
            while (op != null && !op.isDone) yield return null;
            loading = false;
            // the new scene's bootstrap calls FadeIn()
        }

        IEnumerator Fade(float from, float to, float seconds)
        {
            float t = 0f;
            while (t < seconds)
            {
                t += Time.unscaledDeltaTime;
                fade.color = new Color(0, 0, 0, Mathf.Lerp(from, to, t / seconds));
                yield return null;
            }
            fade.color = new Color(0, 0, 0, to);
            fade.raycastTarget = to > 0.5f;
        }
    }
}
