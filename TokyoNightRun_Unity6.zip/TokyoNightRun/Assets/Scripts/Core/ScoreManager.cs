using System;
using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>Owns the current run's RunStats and announces distance milestones.</summary>
    public class ScoreManager : MonoBehaviour
    {
        public RunStats Stats = new RunStats();
        public event Action<int> MilestoneReached;
        int nextMilestone = GameConfig.MilestoneEveryMeters;

        public void ResetRun()
        {
            Stats = new RunStats();
            nextMilestone = GameConfig.MilestoneEveryMeters;
        }

        public void Tick(float dt, float speed, float multiplier)
        {
            Stats.AddDistance(speed * dt, multiplier);
            if (Stats.Distance >= nextMilestone)
            {
                int m = nextMilestone;
                nextMilestone += GameConfig.MilestoneEveryMeters;
                if (MilestoneReached != null) MilestoneReached(m);
            }
        }
    }
}
