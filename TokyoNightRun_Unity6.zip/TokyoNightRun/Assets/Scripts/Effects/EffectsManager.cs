using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// All particle effects, created in code and reused round-robin (no allocations while playing).
    /// Particle counts are small and scaled by 'Density' (set from the graphics-quality setting).
    /// </summary>
    public class EffectsManager : MonoBehaviour
    {
        public static float Density = 1f;

        ParticleSystem[] sparkle, powder, splash, big;
        int iSparkle, iPowder, iSplash, iBig;
        ParticleSystem ambient, ambient2, trail, boost;

        // flying coin "ghosts": a collected coin swoops up above the runner and shrinks away
        const int FlyCount = 10;
        Transform[] flyT; Vector3[] flyFrom; float[] flyAge; int iFly;
        Transform follow;

        static ParticleSystem Create(Transform parent, string name, int max, float life, float speed, float size, float gravity, float shapeRadius, Material mat = null)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            var ps = go.AddComponent<ParticleSystem>();
            ps.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            var main = ps.main;
            main.playOnAwake = false;
            main.loop = false;
            main.simulationSpace = ParticleSystemSimulationSpace.World;
            main.maxParticles = max;
            main.startLifetime = new ParticleSystem.MinMaxCurve(life * 0.6f, life);
            main.startSpeed = new ParticleSystem.MinMaxCurve(speed * 0.4f, speed);
            main.startSize = new ParticleSystem.MinMaxCurve(size * 0.6f, size);
            main.gravityModifier = gravity;
            var em = ps.emission; em.enabled = false;
            var shape = ps.shape; shape.shapeType = ParticleSystemShapeType.Sphere; shape.radius = shapeRadius;
            var col = ps.colorOverLifetime; col.enabled = true;
            var g = new Gradient();
            g.SetKeys(new[] { new GradientColorKey(Color.white, 0f), new GradientColorKey(Color.white, 1f) },
                      new[] { new GradientAlphaKey(1f, 0f), new GradientAlphaKey(0.8f, 0.6f), new GradientAlphaKey(0f, 1f) });
            col.color = g;
            var r = go.GetComponent<ParticleSystemRenderer>();
            r.sharedMaterial = mat != null ? mat : MaterialLibrary.Particle();
            r.renderMode = ParticleSystemRenderMode.Billboard;
            r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            return ps;
        }

        static ParticleSystem[] CreateMany(Transform parent, string name, int count, int max, float life, float speed, float size, float gravity, float radius, Material mat = null)
        {
            var arr = new ParticleSystem[count];
            for (int i = 0; i < count; i++) arr[i] = Create(parent, name + i, max, life, speed, size, gravity, radius, mat);
            return arr;
        }

        public void Init(Transform followTarget)
        {
            sparkle = CreateMany(transform, "Sparkle", 8, 14, 0.5f, 2.8f, 0.5f, 0f, 0.2f, MaterialLibrary.Sparkle());
            powder = CreateMany(transform, "Powder", 6, 40, 0.9f, 3.5f, 0.55f, 0.1f, 0.3f);
            splash = CreateMany(transform, "Splash", 4, 30, 0.7f, 4f, 0.2f, 1.2f, 0.2f);
            big = CreateMany(transform, "Burst", 2, 160, 1.4f, 9f, 0.7f, 0.15f, 0.5f);

            follow = followTarget;
            flyT = new Transform[FlyCount]; flyFrom = new Vector3[FlyCount]; flyAge = new float[FlyCount];
            for (int i = 0; i < FlyCount; i++)
            {
                var g = new GameObject("CoinFly" + i);
                g.transform.SetParent(transform, false);
                var b = new MeshBatcher();
                ProceduralFactory.CoinMesh(b, Vector3.zero, 0.9f);
                b.Build(g.transform, "Coin");
                g.SetActive(false);
                flyT[i] = g.transform; flyAge[i] = 1f;
            }

            if (followTarget == null) return;

            // Ambient particles that give each theme its weather: powder clouds, snow, rain, petals, glints, dust
            ambient = CreateAmbient(followTarget, Theme.Current.Ambient);
            if (Theme.Current.HasAmbient2) ambient2 = CreateAmbient(followTarget, Theme.Current.Ambient2);

            // Colour trail behind the runner (colour comes from the equipped trail)
            trail = Create(followTarget, "Trail", 40, 0.7f, 0.3f, 0.35f, 0f, 0.1f);
            trail.transform.localPosition = new Vector3(0, 0.3f, -0.4f);
            var te = trail.emission; te.enabled = false; te.rateOverTime = 30f;
            var tm = trail.main; tm.loop = true;
            ApplyTrail();

            // Pichkari boost water stream
            boost = Create(followTarget, "BoostStream", 60, 0.45f, 9f, 0.3f, 0.2f, 0.1f);
            boost.transform.localPosition = new Vector3(0, 1.1f, 0.6f);
            var bm = boost.main; bm.loop = true; bm.startColor = Theme.Current.BoostColor;
            var be = boost.emission; be.enabled = false; be.rateOverTime = 60f;
            var bs = boost.shape; bs.shapeType = ParticleSystemShapeType.Cone; bs.angle = 18f; bs.radius = 0.15f;
            // Unity cones emit along the system's local +Z, which is the runner's forward direction.
        }

        /// <summary>Collection animation: the coin flies up above the runner while spinning and shrinking.</summary>
        public void CoinFly(Vector3 pos)
        {
            if (flyT == null) return;
            iFly = (iFly + 1) % FlyCount;
            flyFrom[iFly] = pos; flyAge[iFly] = 0f;
            flyT[iFly].position = pos;
            flyT[iFly].gameObject.SetActive(true);
        }

        void Update()
        {
            if (flyT == null) return;
            float dt = Time.deltaTime;
            for (int i = 0; i < FlyCount; i++)
            {
                if (flyAge[i] >= 1f) continue;
                flyAge[i] += dt / 0.4f;
                if (flyAge[i] >= 1f) { flyT[i].gameObject.SetActive(false); continue; }
                float k = flyAge[i];
                float ease = k * k * (3f - 2f * k);
                Vector3 target = (follow != null ? follow.position : flyFrom[i]) + new Vector3(0f, 2.8f, 1.5f);
                flyT[i].position = Vector3.Lerp(flyFrom[i], target, ease);
                flyT[i].localScale = Vector3.one * Mathf.Lerp(1f, 0.15f, ease);
                flyT[i].Rotate(0f, 900f * dt, 0f, Space.World);
            }
        }

        /// <summary>Weather / atmosphere particles that follow the runner (world space, so they stay behind as you run).</summary>
        static ParticleSystem CreateAmbient(Transform follow, AmbientKind kind)
        {
            var tint = Theme.Current.AmbientTint;
            ParticleSystem ps;
            switch (kind)
            {
                case AmbientKind.Snow:
                {
                    ps = Create(follow, "AmbientSnow", 260, 4.5f, 0.1f, 0.2f, 0f, 0.4f);
                    ps.transform.localPosition = new Vector3(0, 9f, 16f);
                    var m = ps.main; m.loop = true; m.startSize = new ParticleSystem.MinMaxCurve(0.1f, 0.22f); m.startColor = tint;
                    var e = ps.emission; e.enabled = true; e.rateOverTime = 55f;
                    var sh = ps.shape; sh.shapeType = ParticleSystemShapeType.Box; sh.scale = new Vector3(20f, 1f, 30f);
                    var vol = ps.velocityOverLifetime; vol.enabled = true; vol.space = ParticleSystemSimulationSpace.World;
                    vol.x = new ParticleSystem.MinMaxCurve(0f); vol.y = new ParticleSystem.MinMaxCurve(-2.2f); vol.z = new ParticleSystem.MinMaxCurve(0f);
                    var nz = ps.noise; nz.enabled = true; nz.strength = new ParticleSystem.MinMaxCurve(0.6f); nz.frequency = 0.35f;
                    ps.Play(); return ps;
                }
                case AmbientKind.Rain:
                {
                    ps = Create(follow, "AmbientRain", 400, 0.55f, 0.1f, 0.06f, 0f, 0.4f);
                    ps.transform.localPosition = new Vector3(0, 10f, 14f);
                    var m = ps.main; m.loop = true; m.startSize = new ParticleSystem.MinMaxCurve(0.04f, 0.07f); m.startColor = tint;
                    var e = ps.emission; e.enabled = true; e.rateOverTime = 230f;
                    var sh = ps.shape; sh.shapeType = ParticleSystemShapeType.Box; sh.scale = new Vector3(20f, 1f, 30f);
                    var vol = ps.velocityOverLifetime; vol.enabled = true; vol.space = ParticleSystemSimulationSpace.World;
                    vol.x = new ParticleSystem.MinMaxCurve(0f); vol.y = new ParticleSystem.MinMaxCurve(-20f); vol.z = new ParticleSystem.MinMaxCurve(0f);
                    var r = ps.GetComponent<ParticleSystemRenderer>();
                    r.renderMode = ParticleSystemRenderMode.Stretch; r.velocityScale = 0.04f; r.lengthScale = 2.2f;
                    ps.Play(); return ps;
                }
                case AmbientKind.Petals:
                {
                    ps = Create(follow, "AmbientPetals", 70, 6f, 0.1f, 0.2f, 0f, 0.4f);
                    ps.transform.localPosition = new Vector3(0, 6f, 16f);
                    var m = ps.main; m.loop = true; m.startSize = new ParticleSystem.MinMaxCurve(0.16f, 0.26f);
                    m.startColor = new ParticleSystem.MinMaxGradient(new Color(1f, 0.72f, 0.84f, 0.95f), new Color(1f, 0.55f, 0.75f, 0.95f)) { mode = ParticleSystemGradientMode.TwoColors };
                    var e = ps.emission; e.enabled = true; e.rateOverTime = 9f;
                    var sh = ps.shape; sh.shapeType = ParticleSystemShapeType.Box; sh.scale = new Vector3(20f, 3f, 30f);
                    var vol = ps.velocityOverLifetime; vol.enabled = true; vol.space = ParticleSystemSimulationSpace.World;
                    vol.x = new ParticleSystem.MinMaxCurve(-0.6f); vol.y = new ParticleSystem.MinMaxCurve(-0.9f); vol.z = new ParticleSystem.MinMaxCurve(0f);
                    var nz = ps.noise; nz.enabled = true; nz.strength = new ParticleSystem.MinMaxCurve(1.2f); nz.frequency = 0.3f;
                    ps.Play(); return ps;
                }
                case AmbientKind.Glints:
                {
                    ps = Create(follow, "AmbientGlints", 60, 3f, 0.3f, 0.35f, 0f, 0.4f, MaterialLibrary.Sparkle());
                    ps.transform.localPosition = new Vector3(0, 3f, 16f);
                    var m = ps.main; m.loop = true; m.startSize = new ParticleSystem.MinMaxCurve(0.2f, 0.5f);
                    m.startColor = new ParticleSystem.MinMaxGradient(new Color(1f, 0.85f, 0.5f, 0.9f), new Color(1f, 0.6f, 0.85f, 0.9f)) { mode = ParticleSystemGradientMode.TwoColors };
                    var e = ps.emission; e.enabled = true; e.rateOverTime = 14f;
                    var sh = ps.shape; sh.shapeType = ParticleSystemShapeType.Box; sh.scale = new Vector3(18f, 5f, 28f);
                    var vol = ps.velocityOverLifetime; vol.enabled = true; vol.space = ParticleSystemSimulationSpace.World;
                    vol.x = new ParticleSystem.MinMaxCurve(0f); vol.y = new ParticleSystem.MinMaxCurve(0.5f); vol.z = new ParticleSystem.MinMaxCurve(0f);
                    ps.Play(); return ps;
                }
                case AmbientKind.Dust:
                {
                    ps = Create(follow, "AmbientDust", 50, 5f, 0.2f, 0.12f, 0f, 0.4f);
                    ps.transform.localPosition = new Vector3(0, 3f, 16f);
                    var m = ps.main; m.loop = true; m.startSize = new ParticleSystem.MinMaxCurve(0.08f, 0.18f); m.startColor = tint;
                    var e = ps.emission; e.enabled = true; e.rateOverTime = 7f;
                    var sh = ps.shape; sh.shapeType = ParticleSystemShapeType.Box; sh.scale = new Vector3(16f, 4f, 26f);
                    ps.Play(); return ps;
                }
                default: // Holi powder clouds (original)
                {
                    ps = Create(follow, "AmbientPowder", 36, 5f, 0.4f, 4f, 0f, 1f);
                    ps.transform.localPosition = new Vector3(0, 3f, 18f);
                    var am = ps.main; am.loop = true; am.startSize = new ParticleSystem.MinMaxCurve(3f, 5f);
                    am.startColor = new ParticleSystem.MinMaxGradient(Tint(0.2f), Tint(0.2f)) { mode = ParticleSystemGradientMode.TwoColors };
                    var ae = ps.emission; ae.enabled = true; ae.rateOverTime = 5f;
                    var ash = ps.shape; ash.shapeType = ParticleSystemShapeType.Box; ash.scale = new Vector3(14f, 3f, 24f);
                    ps.Play(); return ps;
                }
            }
        }

        static Color Tint(float a)
        {
            var c = Theme.RandomPal();
            c.a = a;
            return c;
        }

        public void ApplyTrail()
        {
            if (trail == null) return;
            var def = Catalog.FindTrail(SaveManager.Data.selectedTrail);
            var em = trail.emission; em.enabled = !def.None;
            var m = trail.main;
            if (def.Rainbow) m.startColor = new ParticleSystem.MinMaxGradient(RainbowGradient()) { mode = ParticleSystemGradientMode.RandomColor };
            else m.startColor = def.Color;
        }

        static Gradient RainbowGradient()
        {
            var g = new Gradient();
            var keys = new GradientColorKey[6];
            for (int i = 0; i < 6; i++) keys[i] = new GradientColorKey(Theme.Pal(i), i / 5f);
            g.SetKeys(keys, new[] { new GradientAlphaKey(1f, 0f), new GradientAlphaKey(1f, 1f) });
            return g;
        }

        public void SetBoost(bool on)
        {
            if (boost == null) return;
            var e = boost.emission; e.enabled = on;
        }

        static void EmitColored(ParticleSystem ps, Vector3 pos, Color c, int count)
        {
            ps.transform.position = pos;
            var ep = new ParticleSystem.EmitParams();
            ep.startColor = c;
            ps.Emit(ep, Mathf.Max(1, Mathf.RoundToInt(count * Density)));
        }

        public void Sparkle(Vector3 pos)
        {
            if (sparkle == null) return;
            iSparkle = (iSparkle + 1) % sparkle.Length;
            EmitColored(sparkle[iSparkle], pos, new Color(1f, 0.85f, 0.2f, 1f), 8);
        }

        public void Powder(Vector3 pos, Color c)
        {
            if (powder == null) return;
            iPowder = (iPowder + 1) % powder.Length;
            EmitColored(powder[iPowder], pos, c, 24);
        }

        public void Splash(Vector3 pos)
        {
            if (splash == null) return;
            iSplash = (iSplash + 1) % splash.Length;
            EmitColored(splash[iSplash], pos, Theme.Current.SplashColor, 20);
        }

        /// <summary>Large multi-coloured explosion (Color Burst and milestones). Capped at 160 particles.</summary>
        public void BigBurst(Vector3 pos)
        {
            if (big == null) return;
            iBig = (iBig + 1) % big.Length;
            var ps = big[iBig];
            ps.transform.position = pos;
            var ep = new ParticleSystem.EmitParams();
            int per = Mathf.Max(1, Mathf.RoundToInt(20 * Density));
            for (int i = 0; i < Theme.Current.Palette.Length; i++)
            {
                ep.startColor = Theme.Pal(i);
                ps.Emit(ep, per);
            }
        }
    }
}
