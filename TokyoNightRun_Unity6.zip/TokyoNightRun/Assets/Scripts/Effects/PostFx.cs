using System;
using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Pipeline-neutral entry point for post-processing and render quality. The Universal Render Pipeline implementation lives in
    /// Scripts/URP (only compiled when the URP package is installed) and registers itself here. Without URP these calls do nothing.
    /// </summary>
    public static class PostFx
    {
        /// <summary>Set by the URP assembly. Prepares a camera (HDR, post-processing on) and creates the colour-grading volume.</summary>
        public static Action<Camera> CameraSetup;
        /// <summary>Set by the URP assembly. Applies graphics quality 0 (low), 1 (medium), 2 (high).</summary>
        public static Action<int> QualitySetup;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics() { CameraSetup = null; QualitySetup = null; }

        public static void SetupCamera(Camera cam) { if (CameraSetup != null && cam != null) CameraSetup(cam); }
        public static void ApplyQuality(int quality) { if (QualitySetup != null) QualitySetup(quality); }
    }
}
