using System;
using System.Collections.Generic;

namespace TokyoNightRun
{
    /// <summary>
    /// Daily challenge framework. Three objectives are generated from today's date (so everyone with the same
    /// date gets the same challenges) and progress is stored locally. No server needed.
    /// To add a new objective type: add it to MissionType, generate it in Generate(), report it in ReportRun().
    /// </summary>
    public static class MissionManager
    {
        public static string TodayKey() { return DateTime.Now.ToString("yyyy-MM-dd"); }

        public static void EnsureToday(string key = null)
        {
            if (key == null) key = TodayKey();
            var d = SaveManager.Data;
            if (d.missionDate == key && d.missions != null && d.missions.Count == 3) return;
            d.missionDate = key;
            d.missions = Generate(key);
            SaveManager.Save();
        }

        static int StableHash(string s)
        {
            unchecked
            {
                int h = 17;
                for (int i = 0; i < s.Length; i++) h = h * 31 + s[i];
                return h;
            }
        }

        public static List<MissionState> Generate(string key)
        {
            var rng = new Random(StableHash(key));
            var list = new List<MissionState>();
            int coinTarget = 100 + 50 * rng.Next(0, 5);
            list.Add(new MissionState { type = (int)MissionType.Coins, target = coinTarget, reward = coinTarget / 2 });
            int dist = 1500 + 500 * rng.Next(0, 4);
            list.Add(new MissionState { type = (int)MissionType.Distance, target = dist, reward = dist / 20 });
            if (rng.Next(0, 2) == 0)
            {
                int g = 15 + 5 * rng.Next(0, 4);
                list.Add(new MissionState { type = (int)MissionType.Gulal, target = g, reward = g * 4 });
            }
            else
            {
                int b = 8 + 2 * rng.Next(0, 4);
                list.Add(new MissionState { type = (int)MissionType.Balloons, target = b, reward = b * 8 });
            }
            return list;
        }

        public static string Describe(MissionState m)
        {
            switch ((MissionType)m.type)
            {
                case MissionType.Coins: return "Collect " + m.target + " coins";
                case MissionType.Distance: return "Run " + m.target + " metres in total";
                case MissionType.Gulal: return string.Format(Theme.Current.MissionA, m.target);
                default: return string.Format(Theme.Current.MissionB, m.target);
            }
        }

        /// <summary>Adds the results of a finished run to today's objectives. Caller saves afterwards.</summary>
        public static void ReportRun(RunStats s)
        {
            EnsureToday();
            var list = SaveManager.Data.missions;
            for (int i = 0; i < list.Count; i++)
            {
                var m = list[i];
                int add = 0;
                switch ((MissionType)m.type)
                {
                    case MissionType.Coins: add = s.Coins; break;
                    case MissionType.Distance: add = (int)s.Distance; break;
                    case MissionType.Gulal: add = s.Gulal; break;
                    case MissionType.Balloons: add = s.Balloons; break;
                }
                m.progress = Math.Min(m.target, m.progress + Math.Max(0, add));
            }
        }

        public static bool Claim(int index)
        {
            EnsureToday();
            var list = SaveManager.Data.missions;
            if (index < 0 || index >= list.Count) return false;
            var m = list[index];
            if (m.claimed || m.progress < m.target) return false;
            m.claimed = true;
            SaveManager.Data.coins += m.reward;
            SaveManager.Save();
            return true;
        }
    }
}
