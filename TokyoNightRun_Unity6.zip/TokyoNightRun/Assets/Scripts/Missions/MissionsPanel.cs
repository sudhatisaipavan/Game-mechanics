using UnityEngine;
using UnityEngine.UI;

namespace TokyoNightRun
{
    /// <summary>Menu screen showing today's three daily challenges with progress and claim buttons.</summary>
    public class MissionsPanel
    {
        public GameObject Root;
        MainMenuController menu;
        Text[] desc = new Text[3], prog = new Text[3];
        Bar[] bars = new Bar[3];
        Button[] claim = new Button[3];
        Text coinsText;

        public void Build(RectTransform parent, MainMenuController m)
        {
            menu = m;
            System.Func<float, float, Vector2> V = UIBuilder.V;
            Root = UIBuilder.Box(parent, "Missions", UIBuilder.Panel, Vector2.zero, Vector2.one).gameObject;
            var r = Root.transform;
            UIBuilder.Label(r, "DAILY CHALLENGES", 70, UIBuilder.Yellow, TextAnchor.MiddleCenter, V(0.05f, 0.88f), V(0.95f, 0.97f));
            coinsText = UIBuilder.Label(r, "", 40, Color.white, TextAnchor.MiddleCenter, V(0.2f, 0.83f), V(0.8f, 0.88f));
            for (int i = 0; i < 3; i++)
            {
                int idx = i;
                float top = 0.8f - i * 0.2f;
                var card = UIBuilder.Box(r, "Mission" + i, new Color(1, 1, 1, 0.08f), V(0.04f, top - 0.17f), V(0.96f, top)).transform;
                desc[i] = UIBuilder.Label(card, "", 42, Color.white, TextAnchor.MiddleLeft, V(0.04f, 0.6f), V(0.96f, 0.95f));
                bars[i] = UIBuilder.MakeBar(card, new Color(0, 0, 0, 0.5f), UIBuilder.Pink, V(0.04f, 0.36f), V(0.96f, 0.52f));
                prog[i] = UIBuilder.Label(card, "", 34, Color.white, TextAnchor.MiddleLeft, V(0.04f, 0.04f), V(0.45f, 0.32f));
                claim[i] = UIBuilder.MakeButton(card, "CLAIM", UIBuilder.Green, V(0.5f, 0.04f), V(0.96f, 0.32f), () => OnClaim(idx), 34);
            }
            UIBuilder.MakeButton(r, "BACK", UIBuilder.Pink, V(0.3f, 0.04f), V(0.7f, 0.12f), () => menu.Back(), 48);
        }

        public void Refresh()
        {
            MissionManager.EnsureToday();
            var d = SaveManager.Data;
            coinsText.text = "COINS " + d.coins;
            for (int i = 0; i < 3 && i < d.missions.Count; i++)
            {
                var ms = d.missions[i];
                desc[i].text = MissionManager.Describe(ms);
                bars[i].Set(ms.target > 0 ? (float)ms.progress / ms.target : 0f);
                prog[i].text = ms.progress + " / " + ms.target + "   Reward: " + ms.reward;
                bool done = ms.progress >= ms.target;
                claim[i].interactable = done && !ms.claimed;
                UIBuilder.SetButtonText(claim[i], ms.claimed ? "CLAIMED" : done ? "CLAIM +" + ms.reward : "IN PROGRESS");
            }
        }

        void OnClaim(int i)
        {
            if (MissionManager.Claim(i)) { Refresh(); menu.RefreshHeader(); }
        }
    }
}
