using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Put on the root of every obstacle (with a trigger BoxCollider). The Kind tells the game what a hit means:
    /// Solid/Low/High end the run (unless shield/boost), Slow only slows the player down.
    /// Moving trains stay parked until the player is close, then roll towards the player.
    /// </summary>
    public class Obstacle : MonoBehaviour
    {
        public ObstacleType Type;
        public ObstacleKind Kind;
        public float MoveSpeed; // > 0 means it drives toward the player once the player is near

        public void Configure(ObstacleType type, ObstacleKind kind, float moveSpeed)
        {
            Type = type;
            Kind = kind;
            MoveSpeed = moveSpeed;
            enabled = moveSpeed > 0f; // static obstacles skip Update entirely
        }

        void Update()
        {
            var gm = GameManager.Instance;
            if (gm == null || gm.State != GameState.Playing || gm.Player == null) return;
            float gap = transform.position.z - gm.Player.transform.position.z;
            if (gap > GameConfig.MovingTrainActivateDistance || gap < -20f) return; // parked until the player is close
            transform.position += Vector3.back * (MoveSpeed * Time.deltaTime);
        }

        /// <summary>Called when a shield, boost or colour burst smashes through this obstacle.</summary>
        public void Smash()
        {
            gameObject.SetActive(false); // stays in its segment's list and is released with it
        }
    }
}
