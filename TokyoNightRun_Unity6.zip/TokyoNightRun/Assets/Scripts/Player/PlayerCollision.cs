using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>Receives trigger hits and forwards them to the GameManager. Contains no game rules itself.</summary>
    public class PlayerCollision : MonoBehaviour
    {
        GameManager gm;
        public void Init(GameManager manager) { gm = manager; }

        void OnTriggerEnter(Collider other)
        {
            if (gm == null || gm.State != GameState.Playing) return;
            Obstacle ob;
            if (other.TryGetComponent(out ob)) { gm.HandleObstacleHit(ob); return; }
            Collectible c;
            if (other.TryGetComponent(out c)) gm.HandleCollected(c);
        }
    }
}
