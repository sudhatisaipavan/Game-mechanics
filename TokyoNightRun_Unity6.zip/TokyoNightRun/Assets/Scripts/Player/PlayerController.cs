using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Moves the runner: automatic forward run, 3 lanes, jump, slide. The world never moves; the player does.
    /// Uses a kinematic Rigidbody + trigger BoxCollider (hit detection lives in PlayerCollision).
    /// </summary>
    [RequireComponent(typeof(Rigidbody), typeof(BoxCollider))]
    public class PlayerController : MonoBehaviour
    {
        public RunnerVisual Visual;
        public PlayerInput Controls;

        GameManager gm;
        BoxCollider col;
        int lane = 1;
        float x, y, z, yVel;
        bool grounded = true, sliding, slideQueued;
        float slideTimer;

        public int Lane { get { return lane; } }
        public bool IsGrounded { get { return grounded; } }
        public bool IsSliding { get { return sliding; } }
        public float Height { get { return y; } }

        public static float LaneX(int laneIndex) { return (laneIndex - 1) * GameConfig.LaneWidth; }

        public void Init(GameManager manager)
        {
            gm = manager;
            col = GetComponent<BoxCollider>();
            var rb = GetComponent<Rigidbody>();
            rb.isKinematic = true;
            rb.useGravity = false;
            col.isTrigger = true;
            ResetState();
        }

        public void ResetState()
        {
            lane = 1; x = 0; y = 0; z = 0; yVel = 0;
            grounded = true; sliding = false; slideQueued = false; slideTimer = 0;
            transform.position = Vector3.zero;
            ApplyCollider();
            if (Controls != null) Controls.Clear();
        }

        void Update()
        {
            if (gm == null) return;
            float dt = Mathf.Min(Time.deltaTime, GameConfig.MaxDeltaTime);
            float targetX = LaneX(lane);

            if (gm.State == GameState.GameOver)
            {
                if (Visual != null) Visual.Apply(RunnerVisual.Pose.Dead, dt, 0f, 0f);
                return;
            }
            if (gm.State != GameState.Playing)
            {
                if (Visual != null) Visual.Apply(RunnerVisual.Pose.Idle, Time.unscaledDeltaTime, 0f, 0f);
                return;
            }

            // ---- input ----
            InputCommand cmd;
            while ((cmd = Controls.Dequeue()) != InputCommand.None)
            {
                switch (cmd)
                {
                    case InputCommand.Left: if (lane > 0) { lane--; } break;
                    case InputCommand.Right: if (lane < GameConfig.LaneCount - 1) { lane++; } break;
                    case InputCommand.Jump: TryJump(); break;
                    case InputCommand.Slide: TrySlide(); break;
                }
            }
            targetX = LaneX(lane);

            // ---- movement ----
            x = Mathf.MoveTowards(x, targetX, GameConfig.LaneSwitchSpeed * dt);
            z += gm.CurrentSpeed * dt;

            if (!grounded)
            {
                y += yVel * dt;
                yVel -= GameConfig.Gravity * dt;
                if (y <= 0f)
                {
                    y = 0f; yVel = 0f; grounded = true;
                    AudioManager.Play(SfxId.Land);
                    gm.Fx.Powder(new Vector3(x, 0.1f, z), new Color(0.9f, 0.85f, 0.8f, 0.7f));
                    if (slideQueued) { slideQueued = false; StartSlide(); }
                }
            }
            if (sliding)
            {
                slideTimer -= dt;
                if (slideTimer <= 0f) { sliding = false; ApplyCollider(); }
            }

            transform.position = new Vector3(x, y, z);

            // ---- visuals ----
            RunnerVisual.Pose pose = !grounded ? (yVel > 0f ? RunnerVisual.Pose.Jump : RunnerVisual.Pose.Fall)
                : sliding ? RunnerVisual.Pose.Slide : RunnerVisual.Pose.Run;
            float lean = Mathf.Clamp((targetX - x) * 12f, -22f, 22f);
            if (Visual != null) Visual.Apply(pose, dt, gm.Difficulty01, lean);
        }

        void TryJump()
        {
            if (!grounded) return;
            grounded = false;
            yVel = GameConfig.JumpVelocity;
            if (sliding) { sliding = false; ApplyCollider(); }
            AudioManager.Play(SfxId.Jump);
        }

        void TrySlide()
        {
            if (!grounded)
            {
                yVel = GameConfig.FastFallVelocity; // swipe down in the air = fast fall, then slide on landing
                slideQueued = true;
                return;
            }
            StartSlide();
        }

        void StartSlide()
        {
            sliding = true;
            slideTimer = GameConfig.SlideDuration;
            ApplyCollider();
            AudioManager.Play(SfxId.Slide);
        }

        void ApplyCollider()
        {
            if (col == null) return;
            if (sliding) { col.size = new Vector3(0.6f, 0.7f, 0.7f); col.center = new Vector3(0, 0.35f, 0); }
            else { col.size = new Vector3(0.6f, 1.7f, 0.7f); col.center = new Vector3(0, 0.85f, 0); }
        }
    }
}
