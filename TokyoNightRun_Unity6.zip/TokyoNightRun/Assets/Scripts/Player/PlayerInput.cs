using UnityEngine;
using UnityEngine.EventSystems;

namespace TokyoNightRun
{
    /// <summary>
    /// Turns touch swipes (and keyboard / mouse in the Editor) into commands.
    /// A tiny queue means a quick double swipe is not lost.
    /// </summary>
    public class PlayerInput : MonoBehaviour
    {
        const int QueueSize = 3;
        readonly InputCommand[] queue = new InputCommand[QueueSize];
        int count;

        Vector2 startPos;
        bool tracking;
        int trackedId = -1;
        bool startedOverUI;

        public void Enqueue(InputCommand c)
        {
            if (c == InputCommand.None || count >= QueueSize) return;
            queue[count++] = c;
        }

        public InputCommand Dequeue()
        {
            if (count == 0) return InputCommand.None;
            var c = queue[0];
            for (int i = 1; i < count; i++) queue[i - 1] = queue[i];
            count--;
            return c;
        }

        public void Clear() { count = 0; tracking = false; }

        void Update()
        {
            if (Time.timeScale == 0f) return;
            // Keyboard (Editor / testing)
            if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A)) Enqueue(InputCommand.Left);
            if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D)) Enqueue(InputCommand.Right);
            if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.Space)) Enqueue(InputCommand.Jump);
            if (Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S)) Enqueue(InputCommand.Slide);

            float threshold = Mathf.Max(40f, Screen.height * 0.035f);

            if (Input.touchCount > 0)
            {
                for (int i = 0; i < Input.touchCount; i++)
                {
                    Touch t = Input.GetTouch(i);
                    if (t.phase == TouchPhase.Began && !tracking)
                    {
                        tracking = true; trackedId = t.fingerId; startPos = t.position;
                        startedOverUI = IsOverUI(t.fingerId);
                    }
                    else if (tracking && t.fingerId == trackedId)
                    {
                        if (t.phase == TouchPhase.Moved || t.phase == TouchPhase.Stationary) Evaluate(t.position, threshold);
                        if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) tracking = false;
                    }
                }
            }
            else
            {
                // Mouse drag for testing in the Editor
                if (Input.GetMouseButtonDown(0)) { tracking = true; startPos = Input.mousePosition; startedOverUI = IsOverUI(-1); }
                else if (tracking && Input.GetMouseButton(0)) Evaluate(Input.mousePosition, threshold);
                if (Input.GetMouseButtonUp(0)) tracking = false;
            }
        }

        static bool IsOverUI(int id)
        {
            return EventSystem.current != null && EventSystem.current.IsPointerOverGameObject(id);
        }

        void Evaluate(Vector2 pos, float threshold)
        {
            if (startedOverUI) { tracking = false; return; } // a swipe that began on a button is ignored
            Vector2 d = pos - startPos;
            if (d.magnitude < threshold) return;
            if (Mathf.Abs(d.x) > Mathf.Abs(d.y)) Enqueue(d.x > 0 ? InputCommand.Right : InputCommand.Left);
            else Enqueue(d.y > 0 ? InputCommand.Jump : InputCommand.Slide);
            tracking = false; // one command per swipe
        }
    }
}
