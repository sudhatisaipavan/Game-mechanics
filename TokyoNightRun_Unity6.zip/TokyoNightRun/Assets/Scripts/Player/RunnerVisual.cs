using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// The visible runner: a skinned humanoid (see CharacterBuilder) driven by a small pose state machine.
    /// Each frame the pose for the current state is evaluated (CharacterPoses) and the bone rotations are cross-faded
    /// towards it, so Run, Jump, Fall, Land, Slide, Dead, Idle and Victory blend smoothly. If a prefab with an Animator
    /// is found in Resources/Characters/&lt;characterId&gt;, the same states are played through that Animator instead
    /// (state names = the Pose names).
    /// </summary>
    public class RunnerVisual : MonoBehaviour
    {
        public enum Pose { Idle, Run, Jump, Fall, Land, Slide, Dead, Victory }

        public Transform Body;                          // rig root (scaled for the collect "pop")
        public Transform[] Bones = new Transform[(int)BoneId.Count];
        public CharacterStyle Style;
        public float HipH = 0.95f;
        public Vector3 HipsBind;
        public GameObject ShieldBubble;
        public Animator ExternalAnimator;               // optional imported model

        readonly PoseFrame target = new PoseFrame(), cur = new PoseFrame();
        Pose current = Pose.Idle;
        float phase, stateTime, airTime, landTimer, victoryTimer, pop, flip;

        public Pose CurrentPose { get { return current; } }
        public float StateTime { get { return stateTime; } }

        /// <summary>Tiny squash-and-stretch when something is collected.</summary>
        public void Pop() { pop = 1f; }

        /// <summary>Plays the victory animation for a while (used by the menu when a runner is selected).</summary>
        public void Celebrate(float seconds) { victoryTimer = seconds; }

        static float Rate(Pose p)
        {
            switch (p)
            {
                case Pose.Jump: return 22f;
                case Pose.Fall: return 14f;
                case Pose.Land: return 28f;
                case Pose.Slide: return 18f;
                case Pose.Dead: return 14f;
                case Pose.Victory: return 18f;
                case Pose.Idle: return 8f;
                default: return 16f;
            }
        }

        public void Apply(Pose pose, float dt, float speed01, float lean)
        {
            if (dt <= 0f) dt = 0.0001f;
            bool wasAir = current == Pose.Jump || current == Pose.Fall;
            if (wasAir && pose == Pose.Run) landTimer = 0.22f; // brief landing crouch before running again
            if (landTimer > 0f) { landTimer -= dt; if (pose == Pose.Run) pose = Pose.Land; }
            if (victoryTimer > 0f) { victoryTimer -= dt; if (pose == Pose.Idle) pose = Pose.Victory; }
            if (pose != current) { stateTime = 0f; current = pose; PlayExternal(pose); } else stateTime += dt;

            bool air = pose == Pose.Jump || pose == Pose.Fall;
            airTime = air ? airTime + dt : 0f;
            RunStyle rs = CharacterPoses.StyleFor(Style);
            if (pose == Pose.Run || pose == Pose.Land) phase += dt * rs.Cadence * Mathf.Lerp(9f, 14f, speed01);

            pop = Mathf.MoveTowards(pop, 0f, dt * 6f);
            if (Body != null) Body.localScale = Vector3.one * (1f + pop * 0.08f);
            if (ExternalAnimator != null) return; // the Animator does the rest

            CharacterPoses.Evaluate(pose, Style, phase, air ? airTime : stateTime, speed01, HipH, target);
            float k = 1f - Mathf.Exp(-Rate(pose) * dt);
            for (int i = 0; i < cur.E.Length; i++) cur.E[i] = Vector3.Lerp(cur.E[i], target.E[i], k);
            cur.HipsY = Mathf.Lerp(cur.HipsY, target.HipsY, k);

            // whole-body flips (Sandy) are applied directly; after landing mid-flip, finish the turn quickly
            if (target.Flip > 0f) flip = target.Flip;
            else if (flip > 0f) { flip = Mathf.MoveTowards(flip, 360f, dt * 1500f); if (flip >= 359.9f) flip = 0f; }

            for (int i = 0; i < Bones.Length; i++)
            {
                var b = Bones[i];
                if (b == null) continue;
                Vector3 e = cur.E[i];
                if (i == (int)BoneId.Hips)
                {
                    e.x += flip;
                    e.z += -lean;          // roll into the turn
                    e.y += lean * 0.8f;    // and yaw a little
                    b.localPosition = HipsBind + new Vector3(0f, cur.HipsY, 0f);
                }
                b.localRotation = Quaternion.Euler(e);
            }
        }

        void PlayExternal(Pose p)
        {
            if (ExternalAnimator == null) return;
            int hash = Animator.StringToHash(p.ToString());
            if (ExternalAnimator.HasState(0, hash)) ExternalAnimator.CrossFadeInFixedTime(hash, 0.12f);
        }

        public void SetShield(bool on)
        {
            if (ShieldBubble != null && ShieldBubble.activeSelf != on) ShieldBubble.SetActive(on);
        }
    }

    /// <summary>Soft blob under the runner so it always looks grounded (no real-time shadows needed on phones).</summary>
    public class BlobShadow : MonoBehaviour
    {
        public Transform Follow;
        void LateUpdate()
        {
            if (Follow == null) return;
            float h = Mathf.Max(0f, Follow.position.y);
            transform.position = new Vector3(Follow.position.x, 0.03f, Follow.position.z);
            transform.rotation = Quaternion.identity;
            float s = Mathf.Lerp(1.1f, 0.6f, Mathf.Clamp01(h / 2f));
            transform.localScale = new Vector3(s, 1f, s);
        }
    }

    public static class RunnerBuilder
    {
        /// <summary>Builds the runner for a character + outfit (imported prefab if present, otherwise the procedural model).</summary>
        public static RunnerVisual Build(CharacterDef c, OutfitDef outfit)
        {
            return CharacterBuilder.Build(c, outfit);
        }
    }
}
