using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Applies the four power-ups. Timing rules live in PowerUpTimers; this class only reacts to
    /// "started" / "expired" and runs the magnet. Re-collecting a power-up just refreshes its timer.
    /// </summary>
    public class PowerUpManager : MonoBehaviour
    {
        public readonly PowerUpTimers Timers = new PowerUpTimers();
        GameManager gm;

        public bool MagnetActive { get { return Timers.IsActive(PowerUpType.Magnet); } }
        public bool BoostActive { get { return Timers.IsActive(PowerUpType.Pichkari); } }
        public bool ShieldActive { get { return Timers.IsActive(PowerUpType.Shield); } }
        public bool MultiplierActive { get { return Timers.IsActive(PowerUpType.Multiplier); } }
        public float ScoreMultiplier { get { return MultiplierActive ? GameConfig.ScoreMultiplierValue : 1f; } }

        public void Init(GameManager manager)
        {
            gm = manager;
            Timers.Started -= OnStarted; Timers.Expired -= OnExpired; // never subscribe twice
            Timers.Started += OnStarted;
            Timers.Expired += OnExpired;
        }

        void OnDestroy()
        {
            Timers.Started -= OnStarted;
            Timers.Expired -= OnExpired;
        }

        public void Activate(PowerUpType t)
        {
            Timers.Activate(t);
            AudioManager.Play(SfxId.PowerUp);
            if (gm != null && gm.UI != null) gm.UI.Toast(ProceduralFactory.PowerUpName(t));
        }

        public void ConsumeShield() { Timers.Cancel(PowerUpType.Shield); }

        public void ResetAll()
        {
            Timers.ClearAll();
            if (gm != null && gm.Player != null && gm.Player.Visual != null) gm.Player.Visual.SetShield(false);
            if (gm != null && gm.Fx != null) gm.Fx.SetBoost(false);
        }

        void OnStarted(PowerUpType t)
        {
            if (gm == null) return;
            if (t == PowerUpType.Shield && gm.Player.Visual != null) gm.Player.Visual.SetShield(true);
            if (t == PowerUpType.Pichkari) { gm.Fx.SetBoost(true); gm.Cam.Shake(0.2f); }
        }

        void OnExpired(PowerUpType t)
        {
            if (gm == null) return;
            if (t == PowerUpType.Shield && gm.Player.Visual != null) gm.Player.Visual.SetShield(false);
            if (t == PowerUpType.Pichkari) { gm.Fx.SetBoost(false); gm.GrantGrace(1f); } // a moment of safety after the boost
        }

        void Update()
        {
            if (gm == null || gm.State != GameState.Playing) return;
            float dt = Time.deltaTime;
            Timers.Tick(dt);
            if (MagnetActive) PullCollectibles(dt);
        }

        void PullCollectibles(float dt)
        {
            Vector3 target = gm.Player.transform.position + Vector3.up * 0.8f;
            float r2 = GameConfig.MagnetRadius * GameConfig.MagnetRadius;
            var list = Collectible.Active;
            for (int i = 0; i < list.Count; i++)
            {
                var c = list[i];
                if (c.Type == CollectibleType.PowerUp) continue;
                Vector3 p = c.transform.position;
                if (p.z < target.z - 1f) continue;
                if ((p - target).sqrMagnitude > r2) continue;
                c.transform.position = Vector3.MoveTowards(p, target, GameConfig.MagnetPullSpeed * dt);
            }
        }
    }
}
