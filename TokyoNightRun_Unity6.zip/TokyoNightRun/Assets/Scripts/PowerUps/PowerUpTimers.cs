using System;

namespace TokyoNightRun
{
    /// <summary>
    /// Pure-logic timers for the four power-ups. Picking up an active power-up refreshes its timer
    /// (it never starts a second timer), and expiry fires exactly once.
    /// </summary>
    public class PowerUpTimers
    {
        const int Count = 4;
        readonly float[] remaining = new float[Count];

        public event Action<PowerUpType> Started;
        public event Action<PowerUpType> Expired;

        /// <summary>Returns true if the power-up was newly started, false if it was only refreshed.</summary>
        public bool Activate(PowerUpType t)
        {
            int i = (int)t;
            bool wasActive = remaining[i] > 0f;
            remaining[i] = GameConfig.PowerUpDuration(t);
            if (!wasActive && Started != null) Started(t);
            return !wasActive;
        }

        public void Tick(float dt)
        {
            for (int i = 0; i < Count; i++)
            {
                if (remaining[i] <= 0f) continue;
                remaining[i] -= dt;
                if (remaining[i] <= 0f)
                {
                    remaining[i] = 0f;
                    if (Expired != null) Expired((PowerUpType)i);
                }
            }
        }

        /// <summary>Ends a power-up early (e.g. the shield was used up). Fires Expired once.</summary>
        public void Cancel(PowerUpType t)
        {
            int i = (int)t;
            if (remaining[i] <= 0f) return;
            remaining[i] = 0f;
            if (Expired != null) Expired(t);
        }

        public bool IsActive(PowerUpType t) { return remaining[(int)t] > 0f; }
        public float Remaining(PowerUpType t) { return remaining[(int)t]; }
        public float Fraction(PowerUpType t) { return remaining[(int)t] / GameConfig.PowerUpDuration(t); }

        /// <summary>Silently clears everything (used when a run starts or ends).</summary>
        public void ClearAll() { for (int i = 0; i < Count; i++) remaining[i] = 0f; }
    }
}
