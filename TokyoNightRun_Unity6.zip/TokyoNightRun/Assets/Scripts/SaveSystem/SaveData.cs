using System;
using System.Collections.Generic;
using UnityEngine;

namespace TokyoNightRun
{
    [Serializable]
    public class MissionState
    {
        public int type;      // MissionType as int (JsonUtility friendly)
        public int target;
        public int progress;
        public int reward;
        public bool claimed;
    }

    /// <summary>Everything we store on the phone. Versioned so future updates can migrate old saves.</summary>
    [Serializable]
    public class SaveData
    {
        public const int CurrentVersion = 1;

        public int version = CurrentVersion;
        public int coins;
        public int tokens;
        public int bestScore;
        public int bestDistance;
        public int totalGulal;
        public int totalRuns;

        public float musicVolume = 0.7f;
        public float sfxVolume = 1f;
        public bool vibration = true;
        public bool onScreenButtons;
        public int quality = 1; // 0 low, 1 medium, 2 high

        public List<string> unlocked = new List<string>();
        public string selectedCharacter = Catalog.DefaultCharacter;
        public string selectedOutfit = Catalog.DefaultOutfit;
        public string selectedTrail = Catalog.DefaultTrail;

        public string missionDate = "";
        public List<MissionState> missions = new List<MissionState>();

        public static SaveData CreateDefault()
        {
            var d = new SaveData();
            d.Validate();
            return d;
        }

        /// <summary>Repairs any invalid or missing values so the game never crashes on a bad save.</summary>
        public void Validate()
        {
            if (version <= 0) version = CurrentVersion;
            version = CurrentVersion; // (future: migrate older versions here before overwriting)
            coins = Mathf.Max(0, coins);
            tokens = Mathf.Max(0, tokens);
            bestScore = Mathf.Max(0, bestScore);
            bestDistance = Mathf.Max(0, bestDistance);
            totalGulal = Mathf.Max(0, totalGulal);
            totalRuns = Mathf.Max(0, totalRuns);
            musicVolume = float.IsNaN(musicVolume) ? 0.7f : Mathf.Clamp01(musicVolume);
            sfxVolume = float.IsNaN(sfxVolume) ? 1f : Mathf.Clamp01(sfxVolume);
            quality = Mathf.Clamp(quality, 0, 2);
            if (unlocked == null) unlocked = new List<string>();
            if (missions == null) missions = new List<MissionState>();
            if (missionDate == null) missionDate = "";

            Ensure(Catalog.DefaultCharacter);
            Ensure(Catalog.DefaultOutfit);
            Ensure(Catalog.DefaultTrail);
            if (GameConfig.UnlockAllCharactersForTesting)
                for (int i = 0; i < Catalog.Characters.Length; i++) Ensure(Catalog.Characters[i].Id); // testing build: all five runners

            if (!unlocked.Contains(selectedCharacter ?? "")) selectedCharacter = Catalog.DefaultCharacter;
            if (!unlocked.Contains(selectedOutfit ?? "")) selectedOutfit = Catalog.DefaultOutfit;
            if (!unlocked.Contains(selectedTrail ?? "")) selectedTrail = Catalog.DefaultTrail;

            // Drop unknown ids (e.g. from a hand-edited file)
            unlocked.RemoveAll(id => Catalog.CostOf(id) < 0);
        }

        void Ensure(string id)
        {
            if (!unlocked.Contains(id)) unlocked.Add(id);
        }
    }
}
