using System;
using System.IO;
using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Loads / saves SaveData as JSON in the app's private folder. Writes via a temp file and keeps a .bak copy,
    /// so a crash during saving can not destroy the player's progress.
    /// </summary>
    public static class SaveManager
    {
        /// <summary>Tests set this to a temp folder.</summary>
        public static string PathOverride;

        static SaveData data;

        static string FilePath
        {
            get { return Path.Combine(PathOverride ?? Application.persistentDataPath, "tokyonightrun_save.json"); }
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics() { data = null; }

        public static SaveData Data
        {
            get
            {
                if (data == null) Load();
                return data;
            }
        }

        public static void Load()
        {
            data = TryRead(FilePath);
            if (data == null) data = TryRead(FilePath + ".bak");
            if (data == null) data = SaveData.CreateDefault();
        }

        static SaveData TryRead(string path)
        {
            try
            {
                if (!File.Exists(path)) return null;
                string json = File.ReadAllText(path);
                if (string.IsNullOrWhiteSpace(json)) return null;
                var d = JsonUtility.FromJson<SaveData>(json);
                if (d == null) return null;
                d.Validate();
                return d;
            }
            catch (Exception e)
            {
                Debug.LogWarning("[TokyoNightRun] Could not read save file '" + path + "': " + e.Message);
                return null;
            }
        }

        public static void Save()
        {
            try
            {
                string path = FilePath;
                string dir = Path.GetDirectoryName(path);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir)) Directory.CreateDirectory(dir);
                string tmp = path + ".tmp";
                File.WriteAllText(tmp, JsonUtility.ToJson(Data));
                if (File.Exists(path)) File.Copy(path, path + ".bak", true);
                File.Copy(tmp, path, true);
                File.Delete(tmp);
            }
            catch (Exception e)
            {
                Debug.LogWarning("[TokyoNightRun] Could not save progress: " + e.Message);
            }
        }

        /// <summary>Wipes all progress (used by Settings > Reset).</summary>
        public static void ResetAll()
        {
            data = SaveData.CreateDefault();
            Save();
        }

        /// <summary>Forget the in-memory copy so the next access reloads from disk (used by tests).</summary>
        public static void ForgetCache() { data = null; }
    }
}
