using System;
using System.Collections.Generic;
using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Endless world generator. Keeps ~6 segments spawned ahead of the player and recycles the ones behind.
    /// Segments are placed edge-to-edge (no gaps). Every obstacle row leaves one fully open "safe lane",
    /// and the safe lane moves at most one lane between rows, so every layout is fair.
    /// </summary>
    public class TrackManager : MonoBehaviour
    {
        Transform player;
        GameManager gm;
        System.Random rng;

        readonly List<TrackSegment> active = new List<TrackSegment>();
        readonly GameObjectPool[] envPools = new GameObjectPool[3];
        readonly Dictionary<ObstacleType, GameObjectPool> obstaclePools = new Dictionary<ObstacleType, GameObjectPool>();
        GameObjectPool coinPool, gulalPool, balloonPool, tokenPool;
        readonly GameObjectPool[] powerPools = new GameObjectPool[4];

        int index;
        float nextZ;
        int safeLane = 1;
        float lastActionZ = -1000f;

        public int ActiveSegmentCount { get { return active.Count; } }
        public IReadOnlyList<TrackSegment> Segments { get { return active; } }

        /// <summary>World z where segment number 'i' starts. Segment 0 starts one segment behind the player.</summary>
        public static float SegmentStart(int i) { return (i - 1) * GameConfig.SegmentLength; }

        /// <summary>Picks the next safe lane: stays within 1 lane of the previous one and inside 0..2.</summary>
        public static int NextSafeLane(int previous, System.Random r)
        {
            return Mathf.Clamp(previous + r.Next(-1, 2), 0, GameConfig.LaneCount - 1);
        }

        public void Init(Transform playerTransform, GameManager manager, int seed)
        {
            player = playerTransform;
            gm = manager;
            rng = new System.Random(seed);

            for (int v = 0; v < 3; v++)
            {
                int variant = v;
                envPools[v] = new GameObjectPool("Env" + v, () =>
                {
                    var go = ProceduralEnvironment.BuildSegment(variant, rng);
                    go.AddComponent<TrackSegment>();
                    return go;
                }, transform, 2);
            }
            foreach (ObstacleType t in Enum.GetValues(typeof(ObstacleType)))
            {
                ObstacleType type = t;
                obstaclePools[t] = new GameObjectPool("Ob_" + t, () => ProceduralFactory.BuildObstacle(type, rng), transform, 3);
            }
            coinPool = new GameObjectPool("Coin", ProceduralFactory.BuildCoin, transform, 60);
            int gi = 0, bi = 0;
            gulalPool = new GameObjectPool("Gulal", () => ProceduralFactory.BuildGulal(Theme.Pal(gi++)), transform, 12);
            balloonPool = new GameObjectPool("Balloon", () => ProceduralFactory.BuildBalloon(Theme.Pal(bi++)), transform, 12);
            tokenPool = new GameObjectPool("Token", ProceduralFactory.BuildToken, transform, 2);
            for (int p = 0; p < 4; p++)
            {
                PowerUpType pt = (PowerUpType)p;
                powerPools[p] = new GameObjectPool("Power_" + pt, () => ProceduralFactory.BuildPowerUp(pt), transform, 1);
            }
            ResetTrack();
        }

        public void ResetTrack()
        {
            for (int i = 0; i < active.Count; i++) RecycleSegment(active[i]);
            active.Clear();
            index = 0;
            nextZ = SegmentStart(0);
            safeLane = 1;
            lastActionZ = -1000f;
            while (nextZ < SegmentsAheadZ(0f)) SpawnNext();
        }

        static float SegmentsAheadZ(float playerZ) { return playerZ + GameConfig.SegmentsAhead * GameConfig.SegmentLength; }

        void Update()
        {
            if (player == null) return;
            float pz = player.position.z;
            while (nextZ < SegmentsAheadZ(pz)) SpawnNext();
            while (active.Count > 0 && active[0].EndZ < pz - GameConfig.RecycleBehind)
            {
                RecycleSegment(active[0]);
                active.RemoveAt(0);
            }
        }

        void RecycleSegment(TrackSegment seg)
        {
            seg.ClearDynamics();
            var po = seg.GetComponent<PooledObject>();
            if (po != null) po.Release();
        }

        void SpawnNext()
        {
            int zone = AtmosphereController.ZoneAt(Mathf.Max(0f, nextZ));
            int variant = rng.NextDouble() < 0.25 ? rng.Next(3) : zone; // mostly follows the zone, sometimes mixes it up
            var go = envPools[variant].Get(transform);
            var seg = go.GetComponent<TrackSegment>();
            seg.Setup(index, nextZ, variant);
            PopulateSegment(seg);
            active.Add(seg);
            nextZ += GameConfig.SegmentLength; // edge to edge: guarantees there are never gaps
            index++;
        }

        // ---------- content generation ----------
        void PopulateSegment(TrackSegment seg)
        {
            float diff = gm != null ? gm.Difficulty01 : 0f;
            int rows = GameConfig.RowsPerSegment;

            // decide every row's safe lane first, so a moving train can keep its lane clear on both sides
            var safe = new int[rows];
            for (int row = 0; row < rows; row++) { safeLane = NextSafeLane(safeLane, rng); safe[row] = safeLane; }

            // Optionally one moving train in the middle row (never in the safe lane). Rows before and after leave that lane empty.
            int movingLane = -1;
            if (seg.Index >= 3 && diff > 0.15f && rng.NextDouble() < 0.28)
            {
                int pick = rng.Next(GameConfig.LaneCount);
                if (pick != safe[1]) movingLane = pick;
            }

            for (int row = 0; row < rows; row++)
            {
                float lz = 6f + row * GameConfig.RowSpacing;
                float wz = seg.StartZ + lz;
                int sl = safe[row];

                PlaceCollectibleLine(seg, lz - 5f, sl);

                if (seg.Index < 2 || wz < 40f) continue; // grace period at the start

                bool actionAllowed = wz - lastActionZ >= GameConfig.MinActionRowGap && movingLane < 0;
                if (actionAllowed && rng.NextDouble() < 0.18 + 0.22 * diff)
                {
                    bool slide = rng.NextDouble() < 0.5;
                    for (int lane = 0; lane < GameConfig.LaneCount; lane++)
                        PlaceObstacle(seg, slide ? ObstacleType.Banner : ObstacleType.Barricade, lane, lz);
                    lastActionZ = wz;
                    if (slide)
                        for (int i = 0; i < 5; i++) PlaceItem(seg, coinPool, new Vector3(PlayerController.LaneX(1), 0f, lz - 2f + i));
                    else
                        for (int i = 0; i < 7; i++)
                            PlaceItem(seg, coinPool, new Vector3(PlayerController.LaneX(1), 0.2f + Mathf.Sin(i / 6f * Mathf.PI) * 0.8f, lz - 3f + i));
                    continue;
                }

                for (int lane = 0; lane < GameConfig.LaneCount; lane++)
                {
                    if (lane == sl)
                    {
                        if (rng.NextDouble() < 0.07 && lane != movingLane) PlaceObstacle(seg, ObstacleType.Puddle, lane, lz); // jump it or get slowed
                        continue;
                    }
                    if (lane == movingLane)
                    {
                        if (row == 1) PlaceObstacle(seg, ObstacleType.TrainMoving, lane, lz);
                        continue; // rows 0 and 2 stay empty in this lane
                    }
                    if (rng.NextDouble() < 0.6 + 0.3 * diff) PlaceObstacle(seg, PickObstacle(), lane, lz);
                }
            }
        }

        ObstacleType PickObstacle()
        {
            double r = rng.NextDouble();
            if (r < 0.30) return ObstacleType.TrainStatic;
            if (r < 0.42) return ObstacleType.TrainCargo;
            if (r < 0.54) return ObstacleType.Cart;
            if (r < 0.70) return ObstacleType.SupplyStack;
            if (r < 0.85) return ObstacleType.Trolley;
            return ObstacleType.Barricade;
        }

        void PlaceObstacle(TrackSegment seg, ObstacleType type, int lane, float lz)
        {
            var go = obstaclePools[type].Get(seg.transform);
            go.transform.localPosition = new Vector3(PlayerController.LaneX(lane), 0f, lz);
            go.transform.localRotation = Quaternion.identity;
            seg.Track(go);
        }

        void PlaceItem(TrackSegment seg, GameObjectPool pool, Vector3 localPos)
        {
            var go = pool.Get(seg.transform);
            go.transform.localPosition = localPos;
            seg.Track(go);
        }

        void PlaceCollectibleLine(TrackSegment seg, float centerZ, int lane)
        {
            float x = PlayerController.LaneX(lane);
            double r = rng.NextDouble();
            double extra = rng.NextDouble();
            bool powerUp = extra < 0.06 && seg.Index >= 1;
            bool token = !powerUp && extra < 0.085;

            if (r < 0.12)
            {
                for (int i = 0; i < 3; i++) PlaceItem(seg, gulalPool, new Vector3(x, 0f, centerZ + (i - 1) * 1.6f));
            }
            else if (r < 0.22)
            {
                for (int i = 0; i < 4; i++)
                    PlaceItem(seg, balloonPool, new Vector3(x, 0.3f + Mathf.Sin(i / 3f * Mathf.PI) * 0.8f, centerZ + (i - 1.5f) * 1.5f));
            }
            else
            {
                for (int i = 0; i < 5; i++)
                {
                    if (i == 2 && (powerUp || token)) continue;
                    PlaceItem(seg, coinPool, new Vector3(x, 0f, centerZ + (i - 2) * 1.2f));
                }
            }
            if (powerUp) PlaceItem(seg, powerPools[rng.Next(4)], new Vector3(x, 0f, centerZ));
            else if (token) PlaceItem(seg, tokenPool, new Vector3(x, 0f, centerZ));
        }
    }
}
