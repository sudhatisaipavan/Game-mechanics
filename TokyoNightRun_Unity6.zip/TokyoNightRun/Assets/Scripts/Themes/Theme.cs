using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Which theme this project is. Change DefaultTheme to re-skin the whole game with another of the five themes
    /// (Holi, ClassicCity, WinterHoliday, TokyoNight, MiamiBeach): world, trains, obstacles, pickups, sky, music, UI text.
    /// </summary>
    public static class ThemeConfig
    {
        public const ThemeId DefaultTheme = ThemeId.TokyoNight;
    }

    public static class Theme
    {
        static ThemeDef cur;

        public static ThemeDef Current
        {
            get { if (cur == null) cur = ThemeLibrary.Get(ThemeConfig.DefaultTheme); return cur; }
        }

        public static void Select(ThemeId id) { cur = ThemeLibrary.Get(id); }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void Reset() { cur = null; }

        public static Color Pal(int i) { var p = Current.Palette; return p[((i % p.Length) + p.Length) % p.Length]; }
        public static Color RandomPal(System.Random r) { var p = Current.Palette; return p[r.Next(p.Length)]; }
        public static Color RandomPal() { var p = Current.Palette; return p[Random.Range(0, p.Length)]; }
        public static bool IsHoli { get { return Current.Id == ThemeId.Holi; } }

        /// <summary>Title with one rich-text colour per letter.</summary>
        public static string LogoRich()
        {
            var t = Current; var sb = new System.Text.StringBuilder(); int k = 0;
            for (int i = 0; i < t.LogoText.Length; i++)
            {
                char ch = t.LogoText[i];
                if (ch == ' ' || ch == '\n') { sb.Append(ch); continue; }
                int rgb = t.LogoColors[k++ % t.LogoColors.Length];
                sb.Append("<color=#").Append(rgb.ToString("X6")).Append('>').Append(ch).Append("</color>");
            }
            return sb.ToString();
        }
    }
}
