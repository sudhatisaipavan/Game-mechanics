using UnityEngine;

namespace TokyoNightRun
{
    public enum ThemeId { Holi, ClassicCity, WinterHoliday, TokyoNight, MiamiBeach }
    public enum AmbientKind { Powder, Dust, Snow, Rain, Petals, Glints }
    public enum MusicStyle { Festival, UrbanFunk, Jingle, CityPop, Tropical }

    /// <summary>Sky / light colours for one time-of-day zone (blended by AtmosphereController).</summary>
    public struct SkyZone
    {
        public Color Top, Mid, Horizon, Bottom, Sun, SunLight, Ambient, Cloud;
        public Vector3 SunDir;
    }

    /// <summary>Colours and textures used by the shared railway corridor (tracks, platforms, masts).</summary>
    public class EnvStyle
    {
        public int Ballast = 0x8C857C, Trench = 0x6F6A64, Sleeper = 0x7A6350, RailBody = 0x8E9298, RailHead = 0xC9CDD2;
        public int PlatformBody = 0xBDB6AE, PlatformTop = 0xD8D2CA, PlatformFace = 0xA39D95, Strip = 0xFFD400, Mast = 0x7C8590;
        public int BackWall = 0xD0C8C0, BackWallTrim = 0x9AA3AD;
        public TexId BallastTex = TexId.Ballast, PlatformTopTex = TexId.Tile, BackWallTex = TexId.Brick;
        public bool Snow;              // snow caps on ballast, platform edge, masts
        public bool WallGraffiti;      // painted murals on the back wall
    }

    /// <summary>Everything that makes one theme look, sound and read differently. See ThemeLibrary.</summary>
    public class ThemeDef
    {
        public ThemeId Id;
        public string GameName;          // "Winter Holiday Run"
        public string LogoText;          // big title on the menu (rich text colours are generated from LogoColors)
        public int[] LogoColors;
        public string Tagline;
        public string ShopTitle;
        public Color[] Palette;          // 6 accent colours (stripes, pickups, particles, graffiti splatter)

        // game vocabulary
        public string EnergyLabel, BurstButton, BurstToast;
        public string PickupAName, PickupBName;          // shown on game-over and in missions
        public string MissionA, MissionB;                // "Collect {0} spray cans"
        public string[] PowerNames = new string[4];      // magnet, boost, shield, multiplier
        public int[] PowerColors = new int[4];
        public string[] TrailNames = new string[2];
        public int[] TrailColors = new int[2];
        public string[] Milestones, GameOvers;

        // atmosphere
        public SkyZone[] Zones;
        public float SunIntensity = 1.25f, FogStart = 80f, FogEnd = 190f;
        public bool Stars;               // star field + moon for night themes
        public int MenuZone;

        // post processing
        public float BloomThreshold = 0.92f, BloomIntensity = 0.55f, BloomScatter = 0.62f, Saturation = 14f, Contrast = 10f, Exposure = 0.12f;
        public Color VignetteColor = new Color(0.18f, 0.05f, 0.3f);
        public float VignetteIntensity = 0.2f;

        // street art
        public string[] GraffitiWords;
        public int[] GraffitiBackgrounds;
        public int[][] GraffitiFills;
        public int GraffitiOutline = 0x1A1034;

        // rolling stock
        public int[][] TrainPalettes;

        // world dressing
        public EnvStyle Env = new EnvStyle();

        // particles / audio
        public AmbientKind Ambient = AmbientKind.Powder;
        public AmbientKind Ambient2 = AmbientKind.Powder; public bool HasAmbient2;
        public Color AmbientTint = Color.white;
        public Color SplashColor = new Color(0.45f, 0.8f, 1f, 0.9f);
        public Color BoostColor = new Color(0.4f, 0.8f, 1f, 0.9f);
        public MusicStyle Music = MusicStyle.Festival;
    }
}
