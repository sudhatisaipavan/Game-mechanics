using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>The five theme definitions. Holi is the original look; the others re-skin everything.</summary>
    public static class ThemeLibrary
    {
        static ThemeDef[] cache = new ThemeDef[5];

        public static ThemeDef Get(ThemeId id)
        {
            int i = (int)id;
            if (cache[i] == null) cache[i] = Make(id);
            return cache[i];
        }

        static Color H(int rgb) { return GameConfig.Hex(rgb); }
        static Color[] Cols(params int[] rgb) { var c = new Color[rgb.Length]; for (int i = 0; i < rgb.Length; i++) c[i] = H(rgb[i]); return c; }
        static SkyZone Z(int top, int mid, int hor, int bot, int sun, int sunLight, int amb, int cloud, float dx, float dy, float dz)
        {
            return new SkyZone { Top = H(top), Mid = H(mid), Horizon = H(hor), Bottom = H(bot), Sun = H(sun), SunLight = H(sunLight), Ambient = H(amb), Cloud = H(cloud), SunDir = new Vector3(dx, dy, dz) };
        }

        static ThemeDef Make(ThemeId id)
        {
            switch (id)
            {
                case ThemeId.ClassicCity: return Classic();
                case ThemeId.WinterHoliday: return Winter();
                case ThemeId.TokyoNight: return Tokyo();
                case ThemeId.MiamiBeach: return Miami();
                default: return Holi();
            }
        }

        // ------------------------------------------------------------------ HOLI (original)
        static ThemeDef Holi()
        {
            return new ThemeDef
            {
                Id = ThemeId.Holi, GameName = "Holi Rush", LogoText = "HOLI RUSH",
                LogoColors = new[] { 0xE91E8C, 0xFFC107, 0x1E88E5, 0xFF6F00, 0x8E24AA, 0x43A047, 0xE91E8C, 0xFFC107 },
                Tagline = "Colours. Courage. Run!", ShopTitle = "FESTIVAL SHOP",
                Palette = GameConfig.HoliColors,
                EnergyLabel = "COLOR ENERGY", BurstButton = "BURST!", BurstToast = "COLOR BURST!",
                PickupAName = "Gulal", PickupBName = "Balloons", MissionA = "Collect {0} gulal packets", MissionB = "Catch {0} water balloons",
                PowerNames = new[] { "COLOR MAGNET", "PICHKARI BOOST", "COLOR SHIELD", "FESTIVAL x2" },
                PowerColors = new[] { 0xE53935, 0x1E88E5, 0x43A047, 0xFDD835 },
                TrailNames = new[] { "Gulal Pink Trail", "Krishna Blue Trail" }, TrailColors = new[] { 0xE91E8C, 0x1E88E5 },
                Milestones = GameConfig.MilestoneMessages, GameOvers = GameConfig.GameOverMessages,
                Zones = new[]
                {
                    Z(0x2E86F0, 0x7CC4FF, 0xFFD2E4, 0xF6C3DA, 0xFFE9A8, 0xFFF1D6, 0xC8B4D4, 0xFFFFFF, 0.25f, 0.30f, 0.92f),
                    Z(0x1580E8, 0x4FC3FF, 0xD8F3FF, 0xBFE8F8, 0xFFFBD0, 0xFFFFFF, 0xB5CFE8, 0xFFFFFF, -0.15f, 0.55f, 0.82f),
                    Z(0x4B2A9C, 0xC2459B, 0xFFA45C, 0xE8826E, 0xFFB066, 0xFFC08A, 0xA58AC4, 0xFFC9D8, 0.1f, 0.08f, 0.99f),
                },
                GraffitiWords = new[] { "HOLI", "RANG", "RUSH", "HAI" },
                GraffitiBackgrounds = new[] { 0x1E88E5, 0xE91E8C, 0x8E24AA, 0xFF6F00 },
                GraffitiFills = new[] {
                    new[] { 0xFFD400, 0xFF6F00, 0xE91E8C, 0xFFFFFF }, new[] { 0xFFD400, 0x43A047, 0x1E88E5, 0xFFFFFF },
                    new[] { 0xFFD400, 0xFF4081, 0x00E5FF, 0xFFFFFF }, new[] { 0xFFFFFF, 0x8E24AA, 0xFFD400, 0x1E88E5 } },
                TrainPalettes = new[] { new[] { 0x2B5BA8, 0xF1ECDD }, new[] { 0x8C2F39, 0xE9DFC8 }, new[] { 0xFF8A1F, 0xF7F7F2 }, new[] { 0x0F8F86, 0xE8F3F1 }, new[] { 0x6A2C91, 0xF8E7B0 } },
                Ambient = AmbientKind.Powder, Music = MusicStyle.Festival,
            };
        }

        // ------------------------------------------------------------------ CLASSIC CITY
        static ThemeDef Classic()
        {
            return new ThemeDef
            {
                Id = ThemeId.ClassicCity, GameName = "Classic City Rush", LogoText = "CITY RUSH",
                LogoColors = new[] { 0xFF3D3D, 0xFFC400, 0x1E88E5, 0xFF7A00, 0x00C2A8, 0x8E44AD, 0xFF3D3D, 0xFFC400, 0x1E88E5 },
                Tagline = "Tag it. Dash it. Run the rails!", ShopTitle = "STREET SHOP",
                Palette = Cols(0xFF3D3D, 0xFFC400, 0x1E88E5, 0xFF7A00, 0x00C2A8, 0x8E44AD),
                EnergyLabel = "HYPE METER", BurstButton = "HYPE!", BurstToast = "HYPE BURST!",
                PickupAName = "Spray cans", PickupBName = "Sodas", MissionA = "Collect {0} spray cans", MissionB = "Grab {0} soda cans",
                PowerNames = new[] { "COIN MAGNET", "JET BOOST", "SUPER SHIELD", "SCORE x2" },
                PowerColors = new[] { 0xE53935, 0xFF7A00, 0x1E88E5, 0xFDD835 },
                TrailNames = new[] { "Spray Pink Trail", "Street Blue Trail" }, TrailColors = new[] { 0xFF4F9A, 0x1E88E5 },
                Milestones = new[] { "Smooth moves!", "The city is yours!", "Rail runner!", "Unstoppable!", "Street legend!", "What a run!" },
                GameOvers = new[] { "Busted! Dash again!", "The inspector got you. Try once more!", "Great run, runner!", "Every tag counts. Go again!" },
                Zones = new[]
                {
                    Z(0x3B8FE8, 0x86C8FF, 0xFFE9C9, 0xF2D9B8, 0xFFF2B8, 0xFFF4DC, 0xB9C6D8, 0xFFFFFF, 0.25f, 0.30f, 0.92f),
                    Z(0x1E7FE0, 0x57BDFF, 0xDDF1FF, 0xC9E6F5, 0xFFFDD8, 0xFFFFFF, 0xB4CBE4, 0xFFFFFF, -0.15f, 0.55f, 0.82f),
                    Z(0x3A3F9E, 0xD0577A, 0xFFB05A, 0xE89268, 0xFFB868, 0xFFC896, 0xA38CBF, 0xFFD3C0, 0.1f, 0.08f, 0.99f),
                },
                Saturation = 16f, Contrast = 12f,
                GraffitiWords = new[] { "CITY", "RUSH", "DASH", "RAIL" },
                GraffitiBackgrounds = new[] { 0x2B2D42, 0x1E88E5, 0xE53935, 0x00A896 },
                GraffitiFills = new[] {
                    new[] { 0xFFD400, 0xFF4081, 0x00E5FF, 0xFFFFFF }, new[] { 0xFFD400, 0xFF7A00, 0xFFFFFF, 0xFF4081 },
                    new[] { 0xFFFFFF, 0xFFD400, 0x00E5FF, 0x69F0AE }, new[] { 0xFFD400, 0xFFFFFF, 0xFF4081, 0x7C4DFF } },
                TrainPalettes = new[] { new[] { 0x2E6FD8, 0xE8EEF5 }, new[] { 0xD9342B, 0xF2E9D8 }, new[] { 0x20A07A, 0xF0F5EE }, new[] { 0xF2A900, 0x34343A }, new[] { 0x7A3FB5, 0xEEEAF5 } },
                Env = new EnvStyle { Ballast = 0x8A8780, Trench = 0x64605B, PlatformBody = 0xB4B6BA, PlatformTop = 0xCFD2D6, PlatformFace = 0x93979C, Strip = 0xFFD400,
                    BackWall = 0xB5654A, BackWallTex = TexId.Brick, WallGraffiti = true },
                Ambient = AmbientKind.Dust, AmbientTint = new Color(1f, 0.95f, 0.8f, 0.25f),
                SplashColor = new Color(0.6f, 0.7f, 0.85f, 0.9f), BoostColor = new Color(1f, 0.6f, 0.15f, 0.95f),
                Music = MusicStyle.UrbanFunk,
            };
        }

        // ------------------------------------------------------------------ WINTER HOLIDAY
        static ThemeDef Winter()
        {
            return new ThemeDef
            {
                Id = ThemeId.WinterHoliday, GameName = "Winter Holiday Run", LogoText = "WINTER RUN",
                LogoColors = new[] { 0xE53935, 0xFFFFFF, 0x2E9E5B, 0xFFD54F, 0x4FC3F7, 0xFFFFFF, 0xE53935, 0x2E9E5B, 0xFFD54F },
                Tagline = "Snow, lights and holiday cheer!", ShopTitle = "HOLIDAY SHOP",
                Palette = Cols(0xE53935, 0x2E9E5B, 0x4FC3F7, 0xFFD54F, 0xFF8FB1, 0xCFD8DC),
                EnergyLabel = "CHEER METER", BurstButton = "CHEER!", BurstToast = "HOLIDAY CHEER!",
                PickupAName = "Snowflakes", PickupBName = "Ornaments", MissionA = "Collect {0} snowflakes", MissionB = "Catch {0} ornaments",
                PowerNames = new[] { "COCOA MAGNET", "ICE SLED BOOST", "SNOW GLOBE SHIELD", "HOLIDAY x2" },
                PowerColors = new[] { 0xE53935, 0x4FC3F7, 0x2E9E5B, 0xFFD54F },
                TrailNames = new[] { "Candy Cane Trail", "Frost Blue Trail" }, TrailColors = new[] { 0xE53935, 0x4FC3F7 },
                Milestones = new[] { "Merry and bright!", "Jingle all the way!", "Frosty speed!", "Santa is impressed!", "Winter legend!", "What a run!" },
                GameOvers = new[] { "Slipped on the ice! Run again!", "Warm up with cocoa and try again!", "Great run! The holidays await.", "Snow problem, go again!" },
                Zones = new[]
                {
                    Z(0x7FA6E0, 0xB9D3F2, 0xFFE3EC, 0xEAF0FA, 0xFFEFD0, 0xFFF0E0, 0xB8C6E0, 0xFFFFFF, 0.25f, 0.30f, 0.92f),
                    Z(0x4E9DEB, 0x9ADCFF, 0xEAF8FF, 0xDDEFFA, 0xFFFFFF, 0xFFFFFF, 0xC4D8F0, 0xFFFFFF, -0.15f, 0.55f, 0.82f),
                    Z(0x1C2860, 0x4B4F9E, 0xF2A5B0, 0xC98FB4, 0xFFC8A0, 0xC8B8F0, 0x8E94CC, 0xE6C8E8, 0.1f, 0.08f, 0.99f),
                },
                FogStart = 55f, FogEnd = 165f, Saturation = 10f, BloomIntensity = 0.65f,
                VignetteColor = new Color(0.1f, 0.12f, 0.35f), VignetteIntensity = 0.18f,
                GraffitiWords = new[] { "SNOW", "NOEL", "JOY", "YULE" },
                GraffitiBackgrounds = new[] { 0x2E9E5B, 0xC62828, 0x1E5AA8, 0x7E57C2 },
                GraffitiFills = new[] {
                    new[] { 0xFFFFFF, 0xFFD54F, 0xE53935, 0xFFFFFF }, new[] { 0xFFFFFF, 0x2E9E5B, 0xFFD54F, 0xFFFFFF },
                    new[] { 0xFFD54F, 0xFFFFFF, 0xE53935, 0x81D4FA }, new[] { 0xFFFFFF, 0xFFD54F, 0xFF8FB1, 0x81D4FA } },
                GraffitiOutline = 0x14233F,
                TrainPalettes = new[] { new[] { 0xC62828, 0xF8F3EA }, new[] { 0x1B7F4B, 0xF4EEDC }, new[] { 0x1E5AA8, 0xF3F8FF }, new[] { 0x6FB7E6, 0xFFFFFF }, new[] { 0x8E1B3A, 0xFFE9B0 } },
                Env = new EnvStyle { Ballast = 0xE8EEF5, Trench = 0xC9D6E3, Sleeper = 0x6B5646, PlatformBody = 0xC8D3DE, PlatformTop = 0xF4F8FC, PlatformFace = 0xAEBBC9,
                    Strip = 0xE53935, Mast = 0x6C7A8A, BackWall = 0x8B5A3C, BackWallTrim = 0xFFFFFF, BallastTex = TexId.Snow, PlatformTopTex = TexId.Snow,
                    BackWallTex = TexId.Wood, Snow = true },
                Ambient = AmbientKind.Snow, AmbientTint = new Color(1f, 1f, 1f, 0.9f),
                SplashColor = new Color(0.9f, 0.97f, 1f, 0.95f), BoostColor = new Color(0.7f, 0.92f, 1f, 0.95f),
                Music = MusicStyle.Jingle,
            };
        }

        // ------------------------------------------------------------------ TOKYO NIGHT
        static ThemeDef Tokyo()
        {
            return new ThemeDef
            {
                Id = ThemeId.TokyoNight, GameName = "Tokyo Night Run", LogoText = "TOKYO RUN",
                LogoColors = new[] { 0xFF2E93, 0x00E5FF, 0xFFEA00, 0x7C4DFF, 0x39FF88, 0xFF6A00, 0xFF2E93, 0x00E5FF, 0xFFEA00 },
                Tagline = "Neon rails after dark", ShopTitle = "NEON SHOP",
                Palette = Cols(0xFF2E93, 0x00E5FF, 0xFFEA00, 0x7C4DFF, 0x39FF88, 0xFF6A00),
                EnergyLabel = "NEON ENERGY", BurstButton = "NEON!", BurstToast = "NEON BURST!",
                PickupAName = "Lanterns", PickupBName = "Onigiri", MissionA = "Collect {0} paper lanterns", MissionB = "Grab {0} onigiri",
                PowerNames = new[] { "COIN MAGNET", "TURBO DASH", "NEON SHIELD", "NIGHT x2" },
                PowerColors = new[] { 0xFF2E93, 0x00E5FF, 0x7C4DFF, 0xFFEA00 },
                TrailNames = new[] { "Neon Pink Trail", "Cyber Blue Trail" }, TrailColors = new[] { 0xFF2E93, 0x00E5FF },
                Milestones = new[] { "Sugoi! Keep running!", "Neon streak!", "Faster than the last train!", "Midnight master!", "Tokyo legend!", "What a run!" },
                GameOvers = new[] { "Missed the last train! Run again!", "Ganbatte! Try once more!", "Great run through the neon!", "The city never sleeps, go again!" },
                Zones = new[]
                {
                    Z(0x120A3A, 0x3B1670, 0xFF4FA3, 0x6A2A8E, 0xFFE6F2, 0x9A8CFF, 0x7A6CC0, 0x7B5BB0, 0.25f, 0.30f, 0.92f),
                    Z(0x050820, 0x10205A, 0x2A7BD0, 0x14306A, 0xE8F4FF, 0x7FA8FF, 0x5C78B8, 0x3A5A9A, -0.2f, 0.45f, 0.86f),
                    Z(0x1A1450, 0x6A2E8C, 0xFF9060, 0xC25A7E, 0xFFD4A0, 0xFFA8B8, 0x8E6AAA, 0xFFB0C0, 0.1f, 0.10f, 0.99f),
                },
                Stars = true, SunIntensity = 1.0f, FogStart = 60f, FogEnd = 175f,
                BloomThreshold = 0.78f, BloomIntensity = 0.95f, BloomScatter = 0.7f, Saturation = 20f, Contrast = 14f, Exposure = 0.05f,
                VignetteColor = new Color(0.04f, 0.0f, 0.15f), VignetteIntensity = 0.3f,
                GraffitiWords = new[] { "TOKYO", "NEON", "NIGHT", "DASH" },
                GraffitiBackgrounds = new[] { 0x1A1040, 0x0B2A4A, 0x2A0F4A, 0x3A0F2E },
                GraffitiFills = new[] {
                    new[] { 0xFF2E93, 0x00E5FF, 0xFFEA00, 0xFFFFFF }, new[] { 0x00E5FF, 0xFF2E93, 0x39FF88, 0xFFFFFF },
                    new[] { 0xFFEA00, 0xFF2E93, 0x7C4DFF, 0x00E5FF }, new[] { 0x39FF88, 0x00E5FF, 0xFF6A00, 0xFFFFFF } },
                GraffitiOutline = 0x08051A,
                TrainPalettes = new[] { new[] { 0x0F4C9A, 0xF4F6FA }, new[] { 0x2A9D4F, 0xE9EEE5 }, new[] { 0xE8571A, 0xEFEDE6 }, new[] { 0xD01C2F, 0xF1F1F1 }, new[] { 0x2A1E5C, 0xC8B8FF } },
                Env = new EnvStyle { Ballast = 0x4A4A55, Trench = 0x33333D, Sleeper = 0x3A3A44, RailBody = 0x6A6E7A, RailHead = 0xB8C0D0,
                    PlatformBody = 0x55586A, PlatformTop = 0x6E7186, PlatformFace = 0x40425A, Strip = 0xFFD400, Mast = 0x4A5068, BackWall = 0x2A2A44, BackWallTrim = 0x00E5FF,
                    BackWallTex = TexId.Concrete, WallGraffiti = true },
                Ambient = AmbientKind.Rain, Ambient2 = AmbientKind.Petals, HasAmbient2 = true, AmbientTint = new Color(0.7f, 0.9f, 1f, 0.55f),
                SplashColor = new Color(0.3f, 0.9f, 1f, 0.9f), BoostColor = new Color(0f, 0.9f, 1f, 0.95f),
                Music = MusicStyle.CityPop,
            };
        }

        // ------------------------------------------------------------------ MIAMI BEACH
        static ThemeDef Miami()
        {
            return new ThemeDef
            {
                Id = ThemeId.MiamiBeach, GameName = "Miami Beach Run", LogoText = "MIAMI RUN",
                LogoColors = new[] { 0xFF4F9A, 0x00D1C1, 0xFFB300, 0xFF6F3C, 0x7E57FF, 0x4FC3F7, 0xFF4F9A, 0x00D1C1, 0xFFB300 },
                Tagline = "Sun. Sand. Speed.", ShopTitle = "BEACH SHOP",
                Palette = Cols(0xFF4F9A, 0x00D1C1, 0xFFB300, 0xFF6F3C, 0x7E57FF, 0x4FC3F7),
                EnergyLabel = "VIBE METER", BurstButton = "VIBE!", BurstToast = "VIBE BURST!",
                PickupAName = "Shells", PickupBName = "Beach balls", MissionA = "Collect {0} seashells", MissionB = "Catch {0} beach balls",
                PowerNames = new[] { "SHELL MAGNET", "SURF BOOST", "SUN SHIELD", "BEACH x2" },
                PowerColors = new[] { 0xFF4F9A, 0x00D1C1, 0xFF6F3C, 0xFFB300 },
                TrailNames = new[] { "Flamingo Pink Trail", "Ocean Blue Trail" }, TrailColors = new[] { 0xFF4F9A, 0x00B8E6 },
                Milestones = new[] { "Catch the wave!", "Sunny streak!", "Beach legend!", "Paradise pace!", "Miami heat!", "What a run!" },
                GameOvers = new[] { "Wiped out! Paddle again!", "Sunscreen and try once more!", "Great run, beach runner!", "Ride the next wave!" },
                Zones = new[]
                {
                    Z(0x4FB4F0, 0xA0E0FF, 0xFFC4D8, 0xFFD8C0, 0xFFE0B0, 0xFFF0D8, 0xC8C0D8, 0xFFFFFF, 0.25f, 0.30f, 0.92f),
                    Z(0x0AA5E8, 0x40D5FF, 0xDFFBFF, 0xBFF2F0, 0xFFFFE0, 0xFFFFFF, 0xB8E0E8, 0xFFFFFF, -0.15f, 0.55f, 0.82f),
                    Z(0x3A1E8C, 0xE0408F, 0xFFA03C, 0xF07060, 0xFFC050, 0xFFB890, 0xB07CB8, 0xFFB0C8, 0.1f, 0.08f, 0.99f),
                },
                SunIntensity = 1.3f, Saturation = 22f, Contrast = 10f, BloomIntensity = 0.6f,
                VignetteColor = new Color(0.3f, 0.05f, 0.25f), VignetteIntensity = 0.16f,
                GraffitiWords = new[] { "MIAMI", "BEACH", "SURF", "SUN" },
                GraffitiBackgrounds = new[] { 0x00B8A9, 0xFF4F9A, 0xFF8A3C, 0x5B6CFF },
                GraffitiFills = new[] {
                    new[] { 0xFFFFFF, 0xFFE082, 0xFF4F9A, 0x00E5FF }, new[] { 0xFFE082, 0xFFFFFF, 0x00D1C1, 0x7E57FF },
                    new[] { 0xFFFFFF, 0x00D1C1, 0xFFE082, 0xFF4F9A }, new[] { 0xFFE082, 0xFF4F9A, 0xFFFFFF, 0x00E5FF } },
                GraffitiOutline = 0x2A0E3D,
                TrainPalettes = new[] { new[] { 0xFF6FA8, 0xFFF3E8 }, new[] { 0x2EC4B6, 0xFFF7EA }, new[] { 0xFFA45C, 0xFFF2DA }, new[] { 0x7E6BFF, 0xF2EEFF }, new[] { 0xFFD166, 0xFFFBEA } },
                Env = new EnvStyle { Ballast = 0xE9DCB8, Trench = 0xCDBE98, Sleeper = 0x8A6A4A, PlatformBody = 0xF1E6CF, PlatformTop = 0xE0B887, PlatformFace = 0xD8A9B8,
                    Strip = 0xFF4F9A, Mast = 0xF4F4F0, BackWall = 0xFFC1D6, BackWallTrim = 0x00D1C1, BallastTex = TexId.Sand, PlatformTopTex = TexId.Wood,
                    BackWallTex = TexId.Concrete, WallGraffiti = true },
                Ambient = AmbientKind.Glints, AmbientTint = new Color(1f, 0.85f, 0.6f, 0.8f),
                SplashColor = new Color(0.3f, 0.9f, 0.95f, 0.9f), BoostColor = new Color(0.2f, 0.85f, 1f, 0.95f),
                Music = MusicStyle.Tropical,
            };
        }
    }
}
