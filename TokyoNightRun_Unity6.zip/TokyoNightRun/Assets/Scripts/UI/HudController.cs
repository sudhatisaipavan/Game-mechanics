using UnityEngine;
using UnityEngine.UI;

namespace TokyoNightRun
{
    /// <summary>In-game HUD: score, coins, distance, colour energy, power-up timers, toasts, on-screen buttons.</summary>
    public class HudController : MonoBehaviour
    {
        GameManager gm;
        Text scoreText, coinText, distText, toastText, countdownText;
        Bar energyBar;
        Button burstBtn;
        Image burstImg, flash;
        Image[] chipBg = new Image[4];
        Text[] chipText = new Text[4];
        Bar[] chipBar = new Bar[4];
        int lastScore = -1, lastCoins = -1, lastDist = -1;
        readonly int[] lastSecs = { -1, -1, -1, -1 };
        float toastTimer;

        public void Init(GameManager manager, RectTransform root)
        {
            gm = manager;
            var V = new System.Func<float, float, Vector2>(UIBuilder.V);

            // score pill (top left) and coin pill (top right) - rounded dark glass with outlined numbers
            UIBuilder.Rounded(root, "ScorePill", new Color(0.12f, 0.04f, 0.28f, 0.62f), V(0.03f, 0.9f), V(0.5f, 0.985f), 36);
            UIBuilder.Label(root, "SCORE", 26, new Color(1f, 1f, 1f, 0.7f), TextAnchor.MiddleLeft, V(0.06f, 0.95f), V(0.3f, 0.982f), FontStyle.Bold, false);
            scoreText = UIBuilder.Label(root, "0", 64, Color.white, TextAnchor.MiddleLeft, V(0.06f, 0.915f), V(0.5f, 0.965f));
            distText = UIBuilder.Label(root, "0 m", 30, new Color(1, 1, 1, 0.8f), TextAnchor.MiddleRight, V(0.3f, 0.945f), V(0.47f, 0.982f));

            UIBuilder.Rounded(root, "CoinPill", new Color(0.12f, 0.04f, 0.28f, 0.62f), V(0.52f, 0.925f), V(0.84f, 0.985f), 36);
            var coinIcon = UIBuilder.Box(root, "CoinIcon", Color.white, V(0.535f, 0.93f), V(0.62f, 0.98f));
            coinIcon.sprite = UISprites.Coin();
            coinIcon.preserveAspect = true;
            coinIcon.raycastTarget = false;
            coinText = UIBuilder.Label(root, "0", 52, UIBuilder.Yellow, TextAnchor.MiddleRight, V(0.62f, 0.925f), V(0.82f, 0.985f));
            UIBuilder.MakeButton(root, "II", UIBuilder.Blue, V(0.86f, 0.925f), V(0.97f, 0.985f), () => gm.Pause(), 44);

            UIBuilder.Label(root, Theme.Current.EnergyLabel, 28, Color.white, TextAnchor.MiddleLeft, V(0.04f, 0.865f), V(0.5f, 0.895f));
            energyBar = UIBuilder.MakeBar(root, new Color(0.1f, 0.03f, 0.22f, 0.7f), UIBuilder.Pink, V(0.04f, 0.838f), V(0.55f, 0.864f));
            burstBtn = UIBuilder.MakeButton(root, Theme.Current.BurstButton, UIBuilder.Purple, V(0.6f, 0.82f), V(0.97f, 0.89f), () => gm.TryColorBurst(), 40);
            burstImg = UIBuilder.ButtonFace(burstBtn);

            for (int i = 0; i < 4; i++) // one chip per power-up, shown only while active
            {
                float y = 0.775f - i * 0.05f;
                chipBg[i] = UIBuilder.Rounded(root, "Chip" + i, ProceduralFactory.PowerUpColor((PowerUpType)i) * 0.95f, V(0.04f, y), V(0.5f, y + 0.043f), 22);
                chipText[i] = UIBuilder.Label(chipBg[i].transform, "", 30, Color.white, TextAnchor.MiddleLeft, V(0.04f, 0.1f), V(0.96f, 1f));
                chipBar[i] = UIBuilder.MakeBar(chipBg[i].transform, new Color(0, 0, 0, 0.35f), Color.white, V(0f, 0f), V(1f, 0.14f));
                chipBg[i].gameObject.SetActive(false);
            }

            toastText = UIBuilder.Label(root, "", 64, Color.white, TextAnchor.MiddleCenter, V(0.05f, 0.58f), V(0.95f, 0.68f));
            countdownText = UIBuilder.Label(root, "", 220, UIBuilder.Yellow, TextAnchor.MiddleCenter, V(0.1f, 0.4f), V(0.9f, 0.62f));
            flash = UIBuilder.Box(root.parent, "Flash", new Color(1, 1, 1, 0), Vector2.zero, Vector2.one);
            flash.raycastTarget = false;

            if (SaveManager.Data.onScreenButtons)
            {
                var pc = gm.Player.Controls;
                UIBuilder.MakeButton(root, "<", new Color(0.15f, 0.05f, 0.35f, 0.7f), V(0.03f, 0.03f), V(0.22f, 0.11f), () => pc.Enqueue(InputCommand.Left), 60);
                UIBuilder.MakeButton(root, ">", new Color(0.15f, 0.05f, 0.35f, 0.7f), V(0.24f, 0.03f), V(0.43f, 0.11f), () => pc.Enqueue(InputCommand.Right), 60);
                UIBuilder.MakeButton(root, "JUMP", new Color(0.15f, 0.05f, 0.35f, 0.7f), V(0.57f, 0.03f), V(0.77f, 0.11f), () => pc.Enqueue(InputCommand.Jump), 36);
                UIBuilder.MakeButton(root, "SLIDE", new Color(0.15f, 0.05f, 0.35f, 0.7f), V(0.79f, 0.03f), V(0.97f, 0.11f), () => pc.Enqueue(InputCommand.Slide), 34);
            }
        }

        public void Toast(string msg) { toastText.text = msg; toastTimer = 2.2f; }
        public void Flash(Color c) { c.a = 0.55f; flash.color = c; }
        public void SetCountdown(string s) { countdownText.text = s ?? ""; }

        void Update()
        {
            if (gm == null || gm.Score == null) return;
            var s = gm.Score.Stats;
            if (s.Score != lastScore) { lastScore = s.Score; scoreText.text = lastScore.ToString(); }
            if (s.Coins != lastCoins) { lastCoins = s.Coins; coinText.text = lastCoins.ToString(); }
            int d = (int)s.Distance;
            if (d != lastDist) { lastDist = d; distText.text = d + " m"; }

            energyBar.Set(s.Energy / GameConfig.EnergyMax);
            bool ready = s.EnergyFull && gm.State == GameState.Playing;
            burstBtn.interactable = ready;
            burstImg.color = ready ? Color.Lerp(UIBuilder.Pink, UIBuilder.Yellow, Mathf.PingPong(Time.unscaledTime * 3f, 1f)) : UIBuilder.Grey;

            for (int i = 0; i < 4; i++)
            {
                var t = (PowerUpType)i;
                bool on = gm.Powerups.Timers.IsActive(t);
                if (chipBg[i].gameObject.activeSelf != on) { chipBg[i].gameObject.SetActive(on); lastSecs[i] = -1; }
                if (!on) continue;
                chipBar[i].Set(gm.Powerups.Timers.Fraction(t));
                int secs = Mathf.CeilToInt(gm.Powerups.Timers.Remaining(t));
                if (secs != lastSecs[i]) { lastSecs[i] = secs; chipText[i].text = ProceduralFactory.PowerUpName(t) + "  " + secs + "s"; }
            }

            if (toastTimer > 0f)
            {
                toastTimer -= Time.unscaledDeltaTime;
                var c = toastText.color; c.a = Mathf.Clamp01(toastTimer / 0.5f); toastText.color = c;
                if (toastTimer <= 0f) toastText.text = "";
            }
            if (flash.color.a > 0f)
            {
                var c = flash.color; c.a = Mathf.MoveTowards(c.a, 0f, Time.unscaledDeltaTime * 1.6f); flash.color = c;
            }
        }
    }
}
