using UnityEngine;
using UnityEngine.UI;

namespace TokyoNightRun
{
    /// <summary>Main menu screen plus navigation between the menu panels.</summary>
    public class MainMenuController : MonoBehaviour
    {
        MenuBootstrap stage;
        GameObject mainPanel, current;
        Text coinsText, bestText;
        CharacterSelectionManager characters;
        MissionsPanel missions;
        ShopPanel shop;
        SettingsPanel settings;

        public void Init(MenuBootstrap s, Transform canvas)
        {
            stage = s;
            var safe = UIBuilder.SafeArea(canvas);
            System.Func<float, float, Vector2> V = UIBuilder.V;

            mainPanel = UIBuilder.Rect("Main", safe, Vector2.zero, Vector2.one).gameObject;
            var m = mainPanel.transform;
            UIBuilder.Rounded(m, "CoinPill", new Color(0.12f, 0.04f, 0.28f, 0.62f), V(0.03f, 0.93f), V(0.45f, 0.99f), 36);
            var icon = UIBuilder.Box(m, "CoinIcon", Color.white, V(0.045f, 0.935f), V(0.12f, 0.985f));
            icon.sprite = UISprites.Coin(); icon.preserveAspect = true; icon.raycastTarget = false;
            coinsText = UIBuilder.Label(m, "", 46, UIBuilder.Yellow, TextAnchor.MiddleLeft, V(0.13f, 0.93f), V(0.44f, 0.99f));
            UIBuilder.Rounded(m, "BestPill", new Color(0.12f, 0.04f, 0.28f, 0.62f), V(0.55f, 0.93f), V(0.97f, 0.99f), 36);
            bestText = UIBuilder.Label(m, "", 40, Color.white, TextAnchor.MiddleCenter, V(0.56f, 0.93f), V(0.96f, 0.99f));

            string logo = Theme.LogoRich();
            var logoText = UIBuilder.Label(m, logo, 170, Color.white, TextAnchor.MiddleCenter, V(0.02f, 0.78f), V(0.98f, 0.93f));
            logoText.transform.localRotation = Quaternion.Euler(0f, 0f, 3f);
            UIBuilder.Label(m, Theme.Current.Tagline, 42, Color.white, TextAnchor.MiddleCenter, V(0.1f, 0.735f), V(0.9f, 0.785f), FontStyle.BoldAndItalic);

            var play = UIBuilder.MakeButton(m, "PLAY", UIBuilder.Green, V(0.18f, 0.26f), V(0.82f, 0.38f), () => SceneLoader.Load(GameConfig.GameScene), 90);
            play.gameObject.AddComponent<UIPulse>();
            UIBuilder.MakeButton(m, "RUNNERS", UIBuilder.Blue, V(0.06f, 0.16f), V(0.48f, 0.24f), () => Open(characters.Root, characters.Refresh), 44);
            UIBuilder.MakeButton(m, "MISSIONS", UIBuilder.Orange, V(0.52f, 0.16f), V(0.94f, 0.24f), () => Open(missions.Root, missions.Refresh), 44);
            UIBuilder.MakeButton(m, "SHOP", UIBuilder.Pink, V(0.06f, 0.06f), V(0.48f, 0.14f), () => Open(shop.Root, shop.Refresh), 44);
            UIBuilder.MakeButton(m, "SETTINGS", UIBuilder.Purple, V(0.52f, 0.06f), V(0.94f, 0.14f), () => Open(settings.Root, settings.Refresh), 44);

            characters = new CharacterSelectionManager(); characters.Build(safe, this, stage);
            missions = new MissionsPanel(); missions.Build(safe, this);
            shop = new ShopPanel(); shop.Build(safe, this);
            settings = new SettingsPanel(); settings.Build(safe, this);

            Show(mainPanel);
            RefreshHeader();
            var d = SaveManager.Data;
            stage.SetPreview(d.selectedCharacter, d.selectedOutfit);
        }

        void Show(GameObject target)
        {
            mainPanel.SetActive(false);
            characters.Root.SetActive(false); missions.Root.SetActive(false);
            shop.Root.SetActive(false); settings.Root.SetActive(false);
            target.SetActive(true);
            current = target;
        }

        void Open(GameObject panel, System.Action refresh)
        {
            if (refresh != null) refresh();
            Show(panel);
        }

        public void RefreshHeader()
        {
            var d = SaveManager.Data;
            coinsText.text = d.coins.ToString();
            bestText.text = "BEST " + d.bestScore;
        }

        /// <summary>Returns to the main menu (also used by the Android back button).</summary>
        public void Back()
        {
            SaveManager.Save();
            Show(mainPanel);
            var d = SaveManager.Data;
            stage.SetPreview(d.selectedCharacter, d.selectedOutfit);
            RefreshHeader();
        }

        void Update()
        {
            if (Input.GetKeyDown(KeyCode.Escape) && current != mainPanel) Back();
        }
    }
}
