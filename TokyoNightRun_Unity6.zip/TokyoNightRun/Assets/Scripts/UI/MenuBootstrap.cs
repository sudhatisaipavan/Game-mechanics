using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

namespace TokyoNightRun
{
    /// <summary>
    /// The only object the MainMenu scene needs: builds the 3D railway-station backdrop, a lit podium with the runner
    /// preview (drag to rotate), and the menu UI. Also supports a two-character "couple" preview.
    /// </summary>
    public class MenuBootstrap : MonoBehaviour
    {
        Transform stageRoot;
        readonly List<RunnerVisual> runners = new List<RunnerVisual>();
        readonly List<float> baseYaw = new List<float>();
        EffectsManager fx;
        float t, userYaw, yawVelocity;
        bool dragging;
        Vector2 lastMouse;

        void Awake()
        {
            GameSettings.Apply();
            MissionManager.EnsureToday();

            var camGo = new GameObject("Main Camera");
            camGo.tag = "MainCamera";
            var cam = camGo.AddComponent<Camera>();
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = Theme.Current.Zones[Theme.Current.MenuZone].Horizon;
            cam.fieldOfView = 40f;
            cam.farClipPlane = 220f;
            cam.allowHDR = true;
            cam.allowMSAA = true;
            camGo.AddComponent<AudioListener>();
            var curve = camGo.AddComponent<CurvedWorld>(); curve.Sag = 0.0006f; curve.SwayBend = false;
            camGo.transform.position = new Vector3(0f, 1.55f, -5.6f);
            camGo.transform.rotation = Quaternion.LookRotation(new Vector3(0f, 1.0f, 0f) - camGo.transform.position);

            var sky = SkyDome.Create(cam);
            PostFx.SetupCamera(cam);

            var lightGo = new GameObject("Sun");
            var sun = lightGo.AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.shadows = LightShadows.None;
            sun.color = Theme.IsHoli ? GameConfig.Hex(0xFFE2BC) : Theme.Current.Zones[Theme.Current.MenuZone].SunLight;
            sun.intensity = 1.1f;
            lightGo.transform.rotation = Quaternion.Euler(35f, 160f, 0f); // lights the runner's face from the camera side
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = Theme.IsHoli ? GameConfig.Hex(0xB58A9A) : Theme.Current.Zones[Theme.Current.MenuZone].Ambient;
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogColor = Theme.Current.Zones[Theme.Current.MenuZone].Horizon;
            RenderSettings.fogStartDistance = 30f;
            RenderSettings.fogEndDistance = 110f;

            var atmosphere = new GameObject("Atmosphere").AddComponent<AtmosphereController>();
            atmosphere.Init(cam, sun, null);
            atmosphere.SetSky(sky);
            atmosphere.ApplyZone(Theme.Current.MenuZone);

            stageRoot = new GameObject("Stage").transform;
            var rng = new System.Random(7);
            for (int i = 0; i < 3; i++)
            {
                var seg = ProceduralEnvironment.BuildSegment(i == 1 ? 1 : 0, rng);
                seg.transform.SetParent(stageRoot, false);
                seg.transform.position = new Vector3(0, 0, -12f + i * GameConfig.SegmentLength);
            }
            BuildPodium();

            var fxGo = new GameObject("Effects");
            fx = fxGo.AddComponent<EffectsManager>();
            fx.Init(stageRoot);
            fx.transform.position = Vector3.zero;

            var canvas = UIBuilder.CreateCanvas("MenuCanvas", 10);
            var menu = canvas.gameObject.AddComponent<MainMenuController>();
            menu.Init(this, canvas.transform);

            AudioManager.PlayMusic();
            SceneLoader.FadeIn();
            StartCoroutine(Celebrate());
        }

        void BuildPodium()
        {
            var b = new MeshBatcher();
            b.Cyl(new Vector3(0, 0.05f, 0), 2.4f, 0.1f, GameConfig.Hex(0x3A2450));
            b.Cyl(new Vector3(0, 0.11f, 0), 2.1f, 0.04f, GameConfig.Hex(0xE91E8C));
            b.Cyl(new Vector3(0, 0.14f, 0), 1.8f, 0.04f, GameConfig.Hex(0xFFC107));
            b.Cyl(new Vector3(0, 0.17f, 0), 1.5f, 0.04f, GameConfig.Hex(0x1E88E5));
            b.Cyl(new Vector3(0, 0.2f, 0), 1.2f, 0.04f, GameConfig.Hex(0xFAF3E6));
            for (int i = 0; i < 12; i++) // glowing marigold lamps around the edge
            {
                float a = i / 12f * Mathf.PI * 2f;
                b.Sph(new Vector3(Mathf.Cos(a) * 1.2f, 0.12f, Mathf.Sin(a) * 1.2f), 0.14f, new Color(1f, 0.7f, 0.1f, 0f));
            }
            b.Build(stageRoot, "Podium");
        }

        void Clear()
        {
            for (int i = 0; i < runners.Count; i++) if (runners[i] != null) ProceduralFactory.DestroyObj(runners[i].gameObject);
            runners.Clear(); baseYaw.Clear();
        }

        void Add(string characterId, string outfitId, float x, float yaw)
        {
            var r = RunnerBuilder.Build(Catalog.FindCharacter(characterId), Catalog.FindOutfit(outfitId));
            r.transform.SetParent(stageRoot, false);
            r.transform.position = new Vector3(x, 0.2f, 0f);
            runners.Add(r); baseYaw.Add(yaw);
        }

        /// <summary>Shows one runner (with the given outfit) on the podium.</summary>
        public void SetPreview(string characterId, string outfitId)
        {
            Clear();
            Add(characterId, outfitId, 0f, 180f);
            userYaw = 0f; yawVelocity = 0f;
        }

        /// <summary>Shows Trisha and Ulvaan side by side wearing the same (couple) outfit.</summary>
        public void SetCouplePreview(string outfitId)
        {
            Clear();
            Add(Catalog.CoupleA, outfitId, -0.5f, 165f);
            Add(Catalog.CoupleB, outfitId, 0.5f, 195f);
            userYaw = 0f; yawVelocity = 0f;
        }

        /// <summary>Plays the victory animation on every previewed runner (when a runner is selected).</summary>
        public void CelebrateSelection()
        {
            for (int i = 0; i < runners.Count; i++) if (runners[i] != null) runners[i].Celebrate(1.8f);
            fx.BigBurst(new Vector3(0f, 2.2f, 0.5f));
        }

        void Update()
        {
            t += Time.deltaTime;
            HandleDrag();
            for (int i = 0; i < runners.Count; i++)
            {
                var r = runners[i];
                if (r == null) continue;
                float sway = dragging || Mathf.Abs(userYaw) > 1f ? 0f : Mathf.Sin(t * 0.8f) * 12f;
                r.transform.rotation = Quaternion.Euler(0f, baseYaw[i] + userYaw + sway, 0f);
                r.Apply(RunnerVisual.Pose.Idle, Time.deltaTime, 0f, 0f);
            }
        }

        /// <summary>Drag horizontally on the 3D view to turn the characters around (mouse or touch).</summary>
        void HandleDrag()
        {
            bool down = Input.GetMouseButton(0);
            Vector2 pos = Input.mousePosition;
            if (down && !dragging && Input.GetMouseButtonDown(0))
            {
                bool overUi = EventSystem.current != null && EventSystem.current.IsPointerOverGameObject();
                float ny = pos.y / Mathf.Max(1f, Screen.height);
                if (!overUi && ny > 0.3f && ny < 0.9f) { dragging = true; lastMouse = pos; }
            }
            if (dragging)
            {
                if (!down) dragging = false;
                else
                {
                    float dx = pos.x - lastMouse.x;
                    lastMouse = pos;
                    yawVelocity = -dx * 0.5f;
                    userYaw += yawVelocity;
                }
            }
            else if (Mathf.Abs(yawVelocity) > 0.01f)
            {
                yawVelocity = Mathf.Lerp(yawVelocity, 0f, Time.deltaTime * 4f); // inertia
                userYaw += yawVelocity;
            }
            // ease back to facing the camera when nobody is touching it
            if (!dragging && Mathf.Abs(yawVelocity) < 0.5f) userYaw = Mathf.LerpAngle(userYaw, 0f, Time.deltaTime * 0.8f);
        }

        IEnumerator Celebrate()
        {
            var wait = new WaitForSeconds(3.5f);
            while (true)
            {
                yield return wait;
                fx.BigBurst(new Vector3(Random.Range(-3f, 3f), Random.Range(1.5f, 4f), Random.Range(0f, 4f)));
            }
        }
    }
}
