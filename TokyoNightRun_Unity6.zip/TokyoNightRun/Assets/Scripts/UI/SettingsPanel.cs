using UnityEngine;
using UnityEngine.UI;

namespace TokyoNightRun
{
    /// <summary>Settings: volumes, vibration, on-screen buttons, graphics quality, reset progress (with confirmation).</summary>
    public class SettingsPanel
    {
        public GameObject Root;
        MainMenuController menu;
        Button vibBtn, btnBtn, qualBtn;
        Slider musicSlider, sfxSlider;
        GameObject confirm;
        Text info;

        public void Build(RectTransform parent, MainMenuController m)
        {
            menu = m;
            System.Func<float, float, Vector2> V = UIBuilder.V;
            var d = SaveManager.Data;
            Root = UIBuilder.Box(parent, "Settings", UIBuilder.Panel, Vector2.zero, Vector2.one).gameObject;
            var r = Root.transform;
            UIBuilder.Label(r, "SETTINGS", 70, UIBuilder.Yellow, TextAnchor.MiddleCenter, V(0.05f, 0.9f), V(0.95f, 0.98f));

            UIBuilder.Label(r, "MUSIC VOLUME", 38, Color.white, TextAnchor.MiddleLeft, V(0.08f, 0.82f), V(0.92f, 0.87f));
            musicSlider = UIBuilder.MakeSlider(r, UIBuilder.Pink, V(0.08f, 0.76f), V(0.92f, 0.82f), d.musicVolume, v =>
            { SaveManager.Data.musicVolume = v; AudioManager.Instance.ApplyVolumes(); });
            UIBuilder.Label(r, "EFFECTS VOLUME", 38, Color.white, TextAnchor.MiddleLeft, V(0.08f, 0.69f), V(0.92f, 0.74f));
            sfxSlider = UIBuilder.MakeSlider(r, UIBuilder.Blue, V(0.08f, 0.63f), V(0.92f, 0.69f), d.sfxVolume, v =>
            { SaveManager.Data.sfxVolume = v; AudioManager.Instance.ApplyVolumes(); });

            vibBtn = UIBuilder.MakeButton(r, "", UIBuilder.Purple, V(0.08f, 0.52f), V(0.92f, 0.6f), () =>
            { SaveManager.Data.vibration = !SaveManager.Data.vibration; if (SaveManager.Data.vibration) AudioManager.Vibrate(); Refresh(); }, 40);
            btnBtn = UIBuilder.MakeButton(r, "", UIBuilder.Purple, V(0.08f, 0.42f), V(0.92f, 0.5f), () =>
            { SaveManager.Data.onScreenButtons = !SaveManager.Data.onScreenButtons; Refresh(); }, 40);
            qualBtn = UIBuilder.MakeButton(r, "", UIBuilder.Orange, V(0.08f, 0.32f), V(0.92f, 0.4f), () =>
            { SaveManager.Data.quality = (SaveManager.Data.quality + 1) % 3; GameSettings.Apply(); Refresh(); }, 40);
            UIBuilder.MakeButton(r, "RESET PROGRESS", new Color(0.7f, 0.1f, 0.1f, 1f), V(0.08f, 0.22f), V(0.92f, 0.3f), () => confirm.SetActive(true), 40);
            info = UIBuilder.Label(r, "", 32, UIBuilder.Orange, TextAnchor.MiddleCenter, V(0.05f, 0.16f), V(0.95f, 0.21f));
            UIBuilder.MakeButton(r, "BACK", UIBuilder.Pink, V(0.3f, 0.04f), V(0.7f, 0.12f), () => menu.Back(), 48);

            confirm = UIBuilder.Box(r, "Confirm", UIBuilder.Dim, Vector2.zero, Vector2.one).gameObject;
            var c = UIBuilder.Card(confirm.transform, "Card", UIBuilder.Panel, V(0.08f, 0.35f), V(0.92f, 0.65f)).transform;
            UIBuilder.Label(c, "Erase ALL coins, unlocks and best scores?", 46, Color.white, TextAnchor.MiddleCenter, V(0.05f, 0.5f), V(0.95f, 0.95f));
            UIBuilder.MakeButton(c, "YES, RESET", new Color(0.7f, 0.1f, 0.1f, 1f), V(0.05f, 0.08f), V(0.48f, 0.42f), OnReset, 40);
            UIBuilder.MakeButton(c, "CANCEL", UIBuilder.Green, V(0.52f, 0.08f), V(0.95f, 0.42f), () => confirm.SetActive(false), 40);
            confirm.SetActive(false);
        }

        public void Refresh()
        {
            var d = SaveManager.Data;
            musicSlider.SetValueWithoutNotify(d.musicVolume);
            sfxSlider.SetValueWithoutNotify(d.sfxVolume);
            UIBuilder.SetButtonText(vibBtn, "VIBRATION: " + (d.vibration ? "ON" : "OFF"));
            UIBuilder.SetButtonText(btnBtn, "ON-SCREEN BUTTONS: " + (d.onScreenButtons ? "ON" : "OFF"));
            UIBuilder.SetButtonText(qualBtn, "GRAPHICS: " + GameSettings.QualityName(d.quality));
            confirm.SetActive(false);
        }

        void OnReset()
        {
            SaveManager.ResetAll();
            MissionManager.EnsureToday();
            GameSettings.Apply();
            Refresh();
            info.text = "Progress reset.";
            menu.RefreshHeader();
        }
    }
}
