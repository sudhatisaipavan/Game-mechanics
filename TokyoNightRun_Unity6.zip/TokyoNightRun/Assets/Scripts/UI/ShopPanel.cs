using UnityEngine;
using UnityEngine.UI;

namespace TokyoNightRun
{
    /// <summary>Shop: unlock characters, outfits and colour trails with coins. Purchases are validated by Progression.</summary>
    public class ShopPanel
    {
        public GameObject Root;
        MainMenuController menu;
        RectTransform content;
        Text coinsText, messageText;

        public void Build(RectTransform parent, MainMenuController m)
        {
            menu = m;
            System.Func<float, float, Vector2> V = UIBuilder.V;
            Root = UIBuilder.Box(parent, "Shop", UIBuilder.Panel, Vector2.zero, Vector2.one).gameObject;
            var r = Root.transform;
            UIBuilder.Label(r, Theme.Current.ShopTitle, 70, UIBuilder.Yellow, TextAnchor.MiddleCenter, V(0.05f, 0.9f), V(0.95f, 0.98f));
            coinsText = UIBuilder.Label(r, "", 44, Color.white, TextAnchor.MiddleCenter, V(0.05f, 0.85f), V(0.95f, 0.9f));
            messageText = UIBuilder.Label(r, "", 34, UIBuilder.Orange, TextAnchor.MiddleCenter, V(0.05f, 0.81f), V(0.95f, 0.85f));
            content = UIBuilder.MakeScroll(r, V(0.03f, 0.14f), V(0.97f, 0.8f));
            UIBuilder.MakeButton(r, "BACK", UIBuilder.Pink, V(0.3f, 0.03f), V(0.7f, 0.11f), () => menu.Back(), 48);
        }

        public void Refresh()
        {
            UIBuilder.ClearChildren(content);
            coinsText.text = "COINS " + SaveManager.Data.coins;
            Header("RUNNERS");
            foreach (var c in Catalog.Characters) Row(c.Id, c.Name, c.Cost);
            Header("JACKET COLOURS & COUPLE SKINS");
            foreach (var o in Catalog.Outfits) Row(o.Id, o.Name, o.Cost);
            Header("COLOUR TRAILS");
            foreach (var t in Catalog.Trails) Row(t.Id, t.Name, t.Cost);
        }

        void Header(string text)
        {
            var l = UIBuilder.Label(content, text, 40, UIBuilder.Yellow, TextAnchor.MiddleLeft, Vector2.zero, Vector2.one);
            l.gameObject.AddComponent<LayoutElement>().preferredHeight = 70;
        }

        void Row(string id, string name, int cost)
        {
            System.Func<float, float, Vector2> V = UIBuilder.V;
            var row = UIBuilder.Box(content, "Row_" + id, new Color(1, 1, 1, 0.08f), Vector2.zero, Vector2.one);
            row.gameObject.AddComponent<LayoutElement>().preferredHeight = 120;
            var od = id.StartsWith("outfit_") ? Catalog.FindOutfit(id) : null;
            if (od != null && !Catalog.OutfitAllowed(od, SaveManager.Data.selectedCharacter)) name += " (Trisha/Ulvaan)";
            UIBuilder.Label(row.transform, name, 42, Color.white, TextAnchor.MiddleLeft, V(0.04f, 0.1f), V(0.58f, 0.9f));
            bool owned = Progression.IsUnlocked(id);

            bool equipped = Progression.IsSelected(id);
            string txt = owned ? (equipped ? "EQUIPPED" : "EQUIP") : "BUY " + cost;
            Color col = owned ? (equipped ? UIBuilder.Grey : UIBuilder.Green) : UIBuilder.Blue;
            var b = UIBuilder.MakeButton(row.transform, txt, col, V(0.6f, 0.15f), V(0.97f, 0.85f), () => OnPress(id), 36);
            b.interactable = !equipped;
        }

        void OnPress(string id)
        {
            messageText.text = "";
            if (id.StartsWith("outfit_") && !Catalog.OutfitAllowed(Catalog.FindOutfit(id), SaveManager.Data.selectedCharacter))
            { messageText.text = "Couple skins need Trisha or Ulvaan selected."; return; }
            if (!Progression.IsUnlocked(id))
            {
                if (!Progression.TryUnlock(id)) { messageText.text = "Not enough coins!"; return; }
                messageText.text = "Unlocked!";
            }
            if (!Progression.Select(id)) { messageText.text = "Couple skins need Trisha or Ulvaan selected."; Refresh(); return; }
            Refresh();
            menu.RefreshHeader();
        }
    }
}
