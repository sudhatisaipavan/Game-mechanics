using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace TokyoNightRun
{
    /// <summary>Keeps UI inside the phone's safe area (notches, rounded corners, gesture bars).</summary>
    public class SafeAreaFitter : MonoBehaviour
    {
        Rect last;
        Vector2Int lastScreen;

        void Update()
        {
            if (Screen.safeArea != last || lastScreen.x != Screen.width || lastScreen.y != Screen.height) Apply();
        }

        void Start() { Apply(); }

        void Apply()
        {
            last = Screen.safeArea;
            lastScreen = new Vector2Int(Screen.width, Screen.height);
            if (Screen.width <= 0 || Screen.height <= 0) return;
            var rt = (RectTransform)transform;
            Vector2 min = last.position, max = last.position + last.size;
            rt.anchorMin = new Vector2(min.x / Screen.width, min.y / Screen.height);
            rt.anchorMax = new Vector2(max.x / Screen.width, max.y / Screen.height);
            rt.offsetMin = rt.offsetMax = Vector2.zero;
        }
    }

    /// <summary>A simple coloured bar whose fill is set from 0 to 1.</summary>
    public class Bar
    {
        public RectTransform Root;
        public Image Background, Fill;
        public void Set(float v) { Fill.rectTransform.anchorMax = new Vector2(Mathf.Clamp01(v), 1f); }
    }

    /// <summary>Helper functions that build Unity UI in code. All layout uses anchors so it fits every screen size.
    /// Buttons, cards and bars use generated rounded sprites (UISprites) for a chunky, glossy mobile-game look.</summary>
    public static class UIBuilder
    {
        static Font font;

        public static Font DefaultFont
        {
            get
            {
                if (font == null)
                {
                    font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); // Unity 2022.2+ and Unity 6
                    if (font == null) font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                }
                return font;
            }
        }

        public static readonly Color Panel = new Color(0.20f, 0.08f, 0.40f, 0.96f);
        public static readonly Color Dim = new Color(0.05f, 0.0f, 0.12f, 0.62f);
        public static readonly Color Ink = new Color(0.10f, 0.04f, 0.22f, 1f);      // text outline / button lip base
        public static readonly Color Pink = GameConfig.Hex(0xFF2E93);
        public static readonly Color Yellow = GameConfig.Hex(0xFFD21F);
        public static readonly Color Blue = GameConfig.Hex(0x1E9BFF);
        public static readonly Color Green = GameConfig.Hex(0x32D74B);
        public static readonly Color Purple = GameConfig.Hex(0x9B3DFF);
        public static readonly Color Orange = GameConfig.Hex(0xFF8A1F);
        public static readonly Color Grey = new Color(0.50f, 0.50f, 0.58f, 1f);

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics() { font = null; }

        public static Vector2 V(float x, float y) { return new Vector2(x, y); }

        public static void EnsureEventSystem()
        {
            if (EventSystem.current != null) return;
            var go = new GameObject("EventSystem");
            go.AddComponent<EventSystem>();
            // Active Input Handling must be "Input Manager (Old)" or "Both" (the Tokyo Night Run setup tool sets this).
            go.AddComponent<StandaloneInputModule>();
        }

        public static Canvas CreateCanvas(string name, int order)
        {
            EnsureEventSystem();
            var go = new GameObject(name);
            var c = go.AddComponent<Canvas>();
            c.renderMode = RenderMode.ScreenSpaceOverlay;
            c.sortingOrder = order;
            var cs = go.AddComponent<CanvasScaler>();
            cs.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            cs.referenceResolution = new Vector2(1080, 1920);
            cs.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            cs.matchWidthOrHeight = 0.5f;
            go.AddComponent<GraphicRaycaster>();
            return c;
        }

        public static RectTransform Rect(string name, Transform parent, Vector2 aMin, Vector2 aMax)
        {
            var go = new GameObject(name, typeof(RectTransform));
            var rt = go.GetComponent<RectTransform>();
            rt.SetParent(parent, false);
            rt.anchorMin = aMin; rt.anchorMax = aMax;
            rt.offsetMin = rt.offsetMax = Vector2.zero;
            return rt;
        }

        public static RectTransform SafeArea(Transform canvas)
        {
            var rt = Rect("SafeArea", canvas, Vector2.zero, Vector2.one);
            rt.gameObject.AddComponent<SafeAreaFitter>();
            return rt;
        }

        /// <summary>Flat rectangle (overlays, thin lines, full-screen panels).</summary>
        public static Image Box(Transform parent, string name, Color color, Vector2 aMin, Vector2 aMax)
        {
            var rt = Rect(name, parent, aMin, aMax);
            var img = rt.gameObject.AddComponent<Image>();
            img.color = color;
            return img;
        }

        /// <summary>Rounded rectangle (9-sliced generated sprite).</summary>
        public static Image Rounded(Transform parent, string name, Color color, Vector2 aMin, Vector2 aMax, int radius = 30)
        {
            var img = Box(parent, name, color, aMin, aMax);
            img.sprite = UISprites.Rounded(radius);
            img.type = Image.Type.Sliced;
            return img;
        }

        /// <summary>Big rounded card with a dark outline, for dialogs and panels.</summary>
        public static Image Card(Transform parent, string name, Color color, Vector2 aMin, Vector2 aMax)
        {
            var img = Rounded(parent, name, color, aMin, aMax, 48);
            var o = img.gameObject.AddComponent<Outline>();
            o.effectColor = new Color(Ink.r, Ink.g, Ink.b, 0.9f);
            o.effectDistance = new Vector2(5, -5);
            return img;
        }

        public static Text Label(Transform parent, string text, int size, Color color, TextAnchor anchor, Vector2 aMin, Vector2 aMax,
            FontStyle style = FontStyle.Bold, bool outline = true)
        {
            var rt = Rect("Label", parent, aMin, aMax);
            var t = rt.gameObject.AddComponent<Text>();
            t.font = DefaultFont;
            t.text = text;
            t.fontSize = size;
            t.color = color;
            t.alignment = anchor;
            t.fontStyle = style;
            t.supportRichText = true;
            t.raycastTarget = false;
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow = VerticalWrapMode.Truncate;
            t.resizeTextForBestFit = true;
            t.resizeTextMinSize = 12;
            t.resizeTextMaxSize = size;
            if (outline)
            {
                // thick dark outline + soft drop shadow = the readable cartoon lettering of mobile runners
                var o = rt.gameObject.AddComponent<Outline>();
                o.effectColor = new Color(Ink.r, Ink.g, Ink.b, 0.95f);
                o.effectDistance = new Vector2(Mathf.Max(2f, size * 0.045f), -Mathf.Max(2f, size * 0.045f));
                var sh = rt.gameObject.AddComponent<Shadow>();
                sh.effectColor = new Color(0f, 0f, 0f, 0.35f);
                sh.effectDistance = new Vector2(0f, -Mathf.Max(3f, size * 0.09f));
            }
            return t;
        }

        static Color Darken(Color c, float k) { return new Color(c.r * k, c.g * k, c.b * k, c.a); }

        /// <summary>Glossy 3D button: dark lip underneath, bright face, white shine on top, bold outlined label.</summary>
        public static Button MakeButton(Transform parent, string text, Color color, Vector2 aMin, Vector2 aMax, Action onClick, int fontSize = 48)
        {
            bool translucent = color.a < 0.9f;
            var lip = Rounded(parent, "Button_" + text, translucent ? new Color(0f, 0f, 0f, color.a) : Darken(color, 0.55f), aMin, aMax, 30);
            var b = lip.gameObject.AddComponent<Button>();
            var face = Rounded(lip.transform, "Face", color, new Vector2(0f, 0.1f), Vector2.one, 30);
            face.raycastTarget = false;
            var shine = Rounded(face.transform, "Shine", Color.white, new Vector2(0.03f, 0.45f), new Vector2(0.97f, 0.97f), 24);
            shine.sprite = UISprites.Gloss(24);
            shine.raycastTarget = false;
            b.targetGraphic = face;
            var colors = b.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1.08f, 1.08f, 1.08f, 1f);
            colors.pressedColor = new Color(0.78f, 0.78f, 0.82f, 1f);
            colors.disabledColor = new Color(0.55f, 0.55f, 0.6f, 0.9f);
            colors.fadeDuration = 0.06f;
            b.colors = colors;
            var outline = lip.gameObject.AddComponent<Outline>();
            outline.effectColor = new Color(Ink.r, Ink.g, Ink.b, 0.85f);
            outline.effectDistance = new Vector2(3, -3);
            var label = Label(lip.transform, text, fontSize, Color.white, TextAnchor.MiddleCenter, new Vector2(0.04f, 0.16f), new Vector2(0.96f, 0.96f));
            label.name = "Text";
            b.onClick.AddListener(() =>
            {
                AudioManager.Play(SfxId.Click);
                if (onClick != null) onClick();
            });
            return b;
        }

        /// <summary>The coloured face image of a button made by MakeButton (use it to recolour the button).</summary>
        public static Image ButtonFace(Button b) { return b != null ? b.targetGraphic as Image : null; }

        public static void SetButtonText(Button b, string text)
        {
            var t = b.transform.Find("Text");
            if (t != null) t.GetComponent<Text>().text = text;
        }

        public static Bar MakeBar(Transform parent, Color bg, Color fill, Vector2 aMin, Vector2 aMax)
        {
            var bar = new Bar();
            bar.Background = Rounded(parent, "Bar", bg, aMin, aMax, 16);
            bar.Root = bar.Background.rectTransform;
            bar.Fill = Rounded(bar.Root, "Fill", fill, new Vector2(0, 0), new Vector2(1, 1), 16);
            bar.Set(0f);
            return bar;
        }

        public static Slider MakeSlider(Transform parent, Color fill, Vector2 aMin, Vector2 aMax, float value, Action<float> onChanged)
        {
            var root = Rect("Slider", parent, aMin, aMax);
            Rounded(root, "Background", new Color(0, 0, 0, 0.5f), new Vector2(0, 0.3f), new Vector2(1, 0.7f), 16);
            var fillArea = Rect("Fill Area", root, new Vector2(0, 0.3f), new Vector2(1, 0.7f));
            var fillImg = Rounded(fillArea, "Fill", fill, Vector2.zero, Vector2.one, 16);
            var handleArea = Rect("Handle Slide Area", root, Vector2.zero, Vector2.one);
            var handle = Rounded(handleArea, "Handle", Color.white, new Vector2(0, 0), new Vector2(0, 1), 24);
            handle.rectTransform.sizeDelta = new Vector2(52, 0);
            var ho = handle.gameObject.AddComponent<Outline>();
            ho.effectColor = new Color(Ink.r, Ink.g, Ink.b, 0.9f);
            ho.effectDistance = new Vector2(3, -3);
            var s = root.gameObject.AddComponent<Slider>();
            s.fillRect = fillImg.rectTransform;
            s.handleRect = handle.rectTransform;
            s.targetGraphic = handle;
            s.direction = Slider.Direction.LeftToRight;
            s.minValue = 0f; s.maxValue = 1f;
            s.value = value;
            s.onValueChanged.AddListener(v => { if (onChanged != null) onChanged(v); });
            return s;
        }

        /// <summary>Vertical scrolling list. Add children to 'content'; they are stacked automatically.</summary>
        public static RectTransform MakeScroll(Transform parent, Vector2 aMin, Vector2 aMax)
        {
            var bg = Rounded(parent, "Scroll", new Color(0, 0, 0, 0.25f), aMin, aMax, 30);
            var sr = bg.gameObject.AddComponent<ScrollRect>();
            var vp = Rect("Viewport", bg.transform, Vector2.zero, Vector2.one);
            vp.gameObject.AddComponent<RectMask2D>();
            var vpImg = vp.gameObject.AddComponent<Image>();
            vpImg.color = new Color(0, 0, 0, 0.01f);
            var content = Rect("Content", vp, new Vector2(0, 1), new Vector2(1, 1));
            content.pivot = new Vector2(0.5f, 1f);
            var vlg = content.gameObject.AddComponent<VerticalLayoutGroup>();
            vlg.spacing = 14; vlg.padding = new RectOffset(14, 14, 14, 14);
            vlg.childControlWidth = true; vlg.childControlHeight = true;
            vlg.childForceExpandWidth = true; vlg.childForceExpandHeight = false;
            var fit = content.gameObject.AddComponent<ContentSizeFitter>();
            fit.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            sr.viewport = vp; sr.content = content;
            sr.horizontal = false; sr.vertical = true;
            sr.movementType = ScrollRect.MovementType.Clamped;
            sr.scrollSensitivity = 30f;
            return content;
        }

        public static void ClearChildren(Transform t)
        {
            for (int i = t.childCount - 1; i >= 0; i--) UnityEngine.Object.Destroy(t.GetChild(i).gameObject);
        }
    }
}
