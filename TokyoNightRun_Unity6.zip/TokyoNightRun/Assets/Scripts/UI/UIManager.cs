using UnityEngine;
using UnityEngine.UI;

namespace TokyoNightRun
{
    /// <summary>Builds the in-game UI (HUD, pause menu, game-over screen) and exposes simple calls to the game.</summary>
    public class UIManager : MonoBehaviour
    {
        GameManager gm;
        HudController hud;
        GameObject pausePanel, gameOverPanel;
        Text goScore, goCoins, goGulal, goBest, goMessage, goNewBest;

        public void Init(GameManager manager)
        {
            gm = manager;
            var canvas = UIBuilder.CreateCanvas("GameCanvas", 10);
            canvas.transform.SetParent(transform, false);
            var safe = UIBuilder.SafeArea(canvas.transform);

            hud = canvas.gameObject.AddComponent<HudController>();
            hud.Init(gm, safe);
            BuildPause(canvas.transform);
            BuildGameOver(canvas.transform);
        }

        public void Toast(string s) { if (hud != null) hud.Toast(s); }
        public void Flash(Color c) { if (hud != null) hud.Flash(c); }
        public void SetCountdown(string s) { if (hud != null) hud.SetCountdown(s); }
        public void ShowPause(bool show) { if (pausePanel != null) pausePanel.SetActive(show); }

        void BuildPause(Transform canvas)
        {
            System.Func<float, float, Vector2> V = UIBuilder.V;
            pausePanel = UIBuilder.Box(canvas, "PausePanel", UIBuilder.Dim, Vector2.zero, Vector2.one).gameObject;
            var p = UIBuilder.Card(pausePanel.transform, "Card", UIBuilder.Panel, V(0.1f, 0.3f), V(0.9f, 0.7f)).transform;
            UIBuilder.Label(p, "PAUSED", 90, UIBuilder.Yellow, TextAnchor.MiddleCenter, V(0.05f, 0.8f), V(0.95f, 0.97f));
            UIBuilder.MakeButton(p, "RESUME", UIBuilder.Green, V(0.1f, 0.56f), V(0.9f, 0.76f), () => gm.Resume());
            UIBuilder.MakeButton(p, "RESTART", UIBuilder.Blue, V(0.1f, 0.32f), V(0.9f, 0.52f), () => gm.Restart());
            UIBuilder.MakeButton(p, "MAIN MENU", UIBuilder.Pink, V(0.1f, 0.08f), V(0.9f, 0.28f), () => gm.GoToMenu());
            pausePanel.SetActive(false);
        }

        void BuildGameOver(Transform canvas)
        {
            System.Func<float, float, Vector2> V = UIBuilder.V;
            gameOverPanel = UIBuilder.Box(canvas, "GameOverPanel", UIBuilder.Dim, Vector2.zero, Vector2.one).gameObject;
            var p = UIBuilder.Card(gameOverPanel.transform, "Card", UIBuilder.Panel, V(0.06f, 0.2f), V(0.94f, 0.8f)).transform;
            UIBuilder.Label(p, "RUN OVER", 90, UIBuilder.Pink, TextAnchor.MiddleCenter, V(0.05f, 0.86f), V(0.95f, 0.98f));
            goNewBest = UIBuilder.Label(p, "NEW BEST!", 50, UIBuilder.Yellow, TextAnchor.MiddleCenter, V(0.05f, 0.79f), V(0.95f, 0.86f));
            goScore = UIBuilder.Label(p, "0", 120, Color.white, TextAnchor.MiddleCenter, V(0.05f, 0.64f), V(0.95f, 0.79f));
            goCoins = UIBuilder.Label(p, "", 46, UIBuilder.Yellow, TextAnchor.MiddleCenter, V(0.05f, 0.55f), V(0.95f, 0.64f));
            goGulal = UIBuilder.Label(p, "", 40, Color.white, TextAnchor.MiddleCenter, V(0.05f, 0.47f), V(0.95f, 0.55f));
            goBest = UIBuilder.Label(p, "", 44, Color.white, TextAnchor.MiddleCenter, V(0.05f, 0.38f), V(0.95f, 0.47f));
            goMessage = UIBuilder.Label(p, "", 40, Theme.Pal(3), TextAnchor.MiddleCenter, V(0.06f, 0.26f), V(0.94f, 0.38f));
            UIBuilder.MakeButton(p, "RESTART", UIBuilder.Green, V(0.05f, 0.04f), V(0.49f, 0.22f), () => gm.Restart());
            UIBuilder.MakeButton(p, "MAIN MENU", UIBuilder.Pink, V(0.51f, 0.04f), V(0.95f, 0.22f), () => gm.GoToMenu());
            gameOverPanel.SetActive(false);
        }

        public void ShowGameOver(RunStats s, bool newBest, string message)
        {
            if (pausePanel != null) pausePanel.SetActive(false);
            goScore.text = s.Score.ToString();
            goCoins.text = "Coins collected: " + s.Coins;
            goGulal.text = Theme.Current.PickupAName + ": " + s.Gulal + "   Distance: " + (int)s.Distance + " m";
            goBest.text = "Best score: " + SaveManager.Data.bestScore;
            goMessage.text = message;
            goNewBest.gameObject.SetActive(newBest);
            gameOverPanel.SetActive(true);
        }
    }
}
