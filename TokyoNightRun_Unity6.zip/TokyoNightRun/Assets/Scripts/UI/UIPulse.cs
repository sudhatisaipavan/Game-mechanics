using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>Gently pulses a UI element's scale (used on the PLAY button to draw the eye). Works while the game is paused.</summary>
    public class UIPulse : MonoBehaviour
    {
        public float Amount = 0.05f;
        public float Speed = 3.2f;

        void Update()
        {
            float s = 1f + Mathf.Sin(Time.unscaledTime * Speed) * Amount;
            transform.localScale = new Vector3(s, s, 1f);
        }

        void OnDisable() { transform.localScale = Vector3.one; }
    }
}
