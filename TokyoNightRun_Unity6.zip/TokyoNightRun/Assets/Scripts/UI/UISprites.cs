using System.Collections.Generic;
using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Sprites generated in code (no image files): anti-aliased rounded rectangles for 9-slice buttons and cards,
    /// a glossy highlight, circles and a shiny gold coin icon. This gives the UI the chunky, rounded mobile-game look.
    /// </summary>
    public static class UISprites
    {
        static readonly Dictionary<int, Sprite> rounded = new Dictionary<int, Sprite>();
        static readonly Dictionary<int, Sprite> gloss = new Dictionary<int, Sprite>();
        static Sprite circle, coin, star;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics() { rounded.Clear(); gloss.Clear(); circle = coin = star = null; }

        static Texture2D NewTex(int w, int h)
        {
            var t = new Texture2D(w, h, TextureFormat.RGBA32, false);
            t.wrapMode = TextureWrapMode.Clamp;
            t.filterMode = FilterMode.Bilinear;
            return t;
        }

        // signed distance to a rounded box centred at c with half-size h and corner radius r
        static float RoundBoxSdf(float px, float py, float cx, float cy, float hx, float hy, float r)
        {
            float qx = Mathf.Abs(px - cx) - (hx - r), qy = Mathf.Abs(py - cy) - (hy - r);
            float ox = Mathf.Max(qx, 0f), oy = Mathf.Max(qy, 0f);
            return Mathf.Sqrt(ox * ox + oy * oy) + Mathf.Min(Mathf.Max(qx, qy), 0f) - r;
        }

        /// <summary>White rounded rectangle with the given corner radius (use with Image.Type.Sliced, tint with Image.color).</summary>
        public static Sprite Rounded(int radius)
        {
            Sprite s;
            if (rounded.TryGetValue(radius, out s) && s != null) return s;
            int n = radius * 2 + 4;
            var tex = NewTex(n, n);
            var px = new Color32[n * n];
            float c = (n - 1) * 0.5f;
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float d = RoundBoxSdf(x, y, c, c, n * 0.5f - 0.5f, n * 0.5f - 0.5f, radius);
                    float a = Mathf.Clamp01(0.5f - d);
                    px[y * n + x] = new Color(1f, 1f, 1f, a);
                }
            tex.SetPixels32(px);
            tex.Apply();
            float b = radius + 2;
            s = Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, new Vector4(b, b, b, b));
            s.name = "Rounded" + radius;
            rounded[radius] = s;
            return s;
        }

        /// <summary>White-to-transparent highlight shaped like the top half of a rounded rectangle (glossy button shine).</summary>
        public static Sprite Gloss(int radius)
        {
            Sprite s;
            if (gloss.TryGetValue(radius, out s) && s != null) return s;
            int n = radius * 2 + 4;
            var tex = NewTex(n, n);
            var px = new Color32[n * n];
            float c = (n - 1) * 0.5f;
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float d = RoundBoxSdf(x, y, c, c, n * 0.5f - 0.5f, n * 0.5f - 0.5f, radius);
                    float shape = Mathf.Clamp01(0.5f - d);
                    float v = y / (float)(n - 1); // 1 = top
                    float a = shape * Mathf.Clamp01((v - 0.45f) / 0.55f) * 0.5f;
                    px[y * n + x] = new Color(1f, 1f, 1f, a);
                }
            tex.SetPixels32(px);
            tex.Apply();
            float b = radius + 2;
            s = Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, new Vector4(b, b, b, b));
            s.name = "Gloss" + radius;
            gloss[radius] = s;
            return s;
        }

        public static Sprite Circle()
        {
            if (circle != null) return circle;
            const int n = 96;
            var tex = NewTex(n, n);
            var px = new Color32[n * n];
            float c = (n - 1) * 0.5f;
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float d = Mathf.Sqrt((x - c) * (x - c) + (y - c) * (y - c)) - (n * 0.5f - 1f);
                    px[y * n + x] = new Color(1f, 1f, 1f, Mathf.Clamp01(0.5f - d));
                }
            tex.SetPixels32(px);
            tex.Apply();
            circle = Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), 100f);
            circle.name = "Circle";
            return circle;
        }

        /// <summary>Shiny gold coin: dark rim, gradient face, inner ring and a diagonal shine.</summary>
        public static Sprite Coin()
        {
            if (coin != null) return coin;
            const int n = 96;
            var tex = NewTex(n, n);
            var px = new Color32[n * n];
            float c = (n - 1) * 0.5f, R = n * 0.5f - 1f;
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float dx = x - c, dy = y - c;
                    float r = Mathf.Sqrt(dx * dx + dy * dy);
                    float edge = Mathf.Clamp01(0.5f - (r - R));
                    Color col;
                    if (r > R - 7f) col = GameConfig.Hex(0xC76B00);                       // rim
                    else if (r > R - 11f) col = GameConfig.Hex(0xFFE27A);                // bright bevel
                    else
                    {
                        float t = Mathf.Clamp01((dy / R) * 0.5f + 0.5f);                 // top lighter
                        col = Color.Lerp(GameConfig.Hex(0xFFA800), GameConfig.Hex(0xFFD93B), t);
                        float ring = Mathf.Abs(r - R * 0.58f);
                        if (ring < 2.2f) col = Color.Lerp(col, GameConfig.Hex(0xE08A00), 0.7f);
                        // diagonal shine
                        float diag = Mathf.Abs((dx + dy) * 0.7071f - R * 0.1f);
                        if (diag < 4f && r < R - 14f) col = Color.Lerp(col, Color.white, 0.55f * (1f - diag / 4f));
                    }
                    col.a = edge;
                    px[y * n + x] = col;
                }
            tex.SetPixels32(px);
            tex.Apply();
            coin = Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), 100f);
            coin.name = "CoinIcon";
            return coin;
        }

        /// <summary>Five-point star (used for NEW BEST and decorations).</summary>
        public static Sprite Star()
        {
            if (star != null) return star;
            const int n = 96;
            var tex = NewTex(n, n);
            var px = new Color32[n * n];
            float c = (n - 1) * 0.5f;
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float dx = (x - c) / c, dy = (y - c) / c;
                    float r = Mathf.Sqrt(dx * dx + dy * dy);
                    float ang = Mathf.Atan2(dx, dy);
                    float k = Mathf.Cos(Mathf.Repeat(ang, Mathf.PI * 2f / 5f) - Mathf.PI / 5f);
                    float edgeR = 0.42f / Mathf.Max(0.35f, k + 0.12f) ;
                    float d = (r - edgeR) * c;
                    px[y * n + x] = new Color(1f, 1f, 1f, Mathf.Clamp01(0.5f - d));
                }
            tex.SetPixels32(px);
            tex.Apply();
            star = Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), 100f);
            star.name = "Star";
            return star;
        }
    }
}
