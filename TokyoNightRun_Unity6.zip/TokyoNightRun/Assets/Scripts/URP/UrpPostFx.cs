using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace TokyoNightRun
{
    /// <summary>
    /// Universal Render Pipeline glue (Unity 6.x): HDR camera, bloom for glowing coins / lamps / powder, a vivid
    /// colour grade (the "Subway Surfers" saturated look), a soft vignette and the quality presets.
    /// Compiled only when com.unity.render-pipelines.universal is installed (see TokyoNightRun.URP.asmdef).
    /// </summary>
    public static class UrpPostFx
    {
        static VolumeProfile profile;
        static int quality = 1;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void Register()
        {
            profile = null;
            PostFx.CameraSetup = SetupCamera;
            PostFx.QualitySetup = ApplyQuality;
        }

        static void SetupCamera(Camera cam)
        {
            var data = cam.GetUniversalAdditionalCameraData();
            if (data == null) return;
            data.renderPostProcessing = quality > 0;
            data.renderShadows = false;                     // the world is bent by a vertex shader; blob shadows are used instead
            data.requiresDepthOption = CameraOverrideOption.Off;
            data.requiresColorOption = CameraOverrideOption.Off;
            data.antialiasing = AntialiasingMode.None;      // MSAA from the pipeline asset is used instead
            cam.allowHDR = quality > 0;
            cam.allowMSAA = true;

            if (GameObject.Find("TokyoNightRun PostFx Volume") != null) return;
            var go = new GameObject("TokyoNightRun PostFx Volume");
            var vol = go.AddComponent<Volume>();
            vol.isGlobal = true;
            vol.priority = 10f;
            vol.weight = 1f;
            vol.sharedProfile = GetProfile();
        }

        static VolumeProfile GetProfile()
        {
            if (profile != null) return profile;
            profile = ScriptableObject.CreateInstance<VolumeProfile>();
            profile.name = "TokyoNightRun Look";

            var bloom = profile.Add<Bloom>(true);
            var th = Theme.Current;
            bloom.threshold.Override(th.BloomThreshold);
            bloom.intensity.Override(th.BloomIntensity);
            bloom.scatter.Override(th.BloomScatter);
            bloom.tint.Override(new Color(1f, 0.95f, 0.9f));
            bloom.highQualityFiltering.Override(quality >= 2);

            var grade = profile.Add<ColorAdjustments>(true);
            grade.postExposure.Override(th.Exposure);
            grade.contrast.Override(th.Contrast);
            grade.saturation.Override(th.Saturation);

            var vig = profile.Add<Vignette>(true);
            vig.intensity.Override(th.VignetteIntensity);
            vig.smoothness.Override(0.45f);
            vig.color.Override(th.VignetteColor);
            return profile;
        }

        static void ApplyQuality(int q)
        {
            quality = Mathf.Clamp(q, 0, 2);
            var asset = UniversalRenderPipeline.asset;
            if (asset != null)
            {
                asset.msaaSampleCount = quality == 0 ? 1 : quality == 1 ? 2 : 4;
                asset.renderScale = quality == 0 ? 0.85f : 1f;
            }
            if (profile != null)
            {
                Bloom bloom;
                if (profile.TryGet(out bloom)) bloom.highQualityFiltering.Override(quality >= 2);
            }
            foreach (var cam in Camera.allCameras)
            {
                var data = cam.GetUniversalAdditionalCameraData();
                if (data != null) data.renderPostProcessing = quality > 0;
                cam.allowHDR = quality > 0;
            }
        }
    }
}
