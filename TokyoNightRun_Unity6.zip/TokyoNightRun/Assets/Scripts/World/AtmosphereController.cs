using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Changes sky, fog and light colour as the player progresses: bright Holi morning, saturated noon, magenta-orange sunset.
    /// Drives the gradient SkyDome, the fog (which fades into the horizon colour), the ambient light and the sun.
    /// </summary>
    public class AtmosphereController : MonoBehaviour
    {
        static SkyZone[] Zones { get { return Theme.Current.Zones; } }

        Camera cam;
        Light sun;
        GameManager gm;
        SkyDome sky;

        public static int ZoneAt(float distance) { return ((int)(distance / GameConfig.ZoneLength)) % 3; }

        public void Init(Camera camera, Light light, GameManager manager)
        {
            cam = camera; sun = light; gm = manager;
            ApplyBlend(0, 1, 0f);
        }

        /// <summary>Optional: the sky dome that should follow the same colours (used in game and in the menu).</summary>
        public void SetSky(SkyDome dome) { sky = dome; }

        void Update()
        {
            if (gm == null || gm.Score == null) return;
            float zf = gm.Score.Stats.Distance / GameConfig.ZoneLength;
            int a = ((int)zf) % 3;
            float frac = zf - Mathf.Floor(zf);
            float t = Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(0.8f, 1f, frac)); // blend during the last 20% of a zone
            ApplyBlend(a, (a + 1) % 3, t);
        }

        /// <summary>Applies a single zone (menu scene).</summary>
        public void ApplyZone(int zone) { ApplyBlend(zone % 3, zone % 3, 0f); }

        void ApplyBlend(int a, int b, float t)
        {
            SkyZone za = Zones[a], zb = Zones[b];
            Color horizon = Color.Lerp(za.Horizon, zb.Horizon, t);
            if (cam != null) cam.backgroundColor = horizon;
            RenderSettings.fogColor = horizon;
            RenderSettings.ambientLight = Color.Lerp(za.Ambient, zb.Ambient, t);
            if (sun != null) sun.color = Color.Lerp(za.SunLight, zb.SunLight, t);
            if (sky != null)
                sky.SetColors(Color.Lerp(za.Top, zb.Top, t), Color.Lerp(za.Mid, zb.Mid, t), horizon, Color.Lerp(za.Bottom, zb.Bottom, t),
                    Color.Lerp(za.Sun, zb.Sun, t), Vector3.Lerp(za.SunDir, zb.SunDir, t).normalized, Color.Lerp(za.Cloud, zb.Cloud, t));
        }
    }
}
