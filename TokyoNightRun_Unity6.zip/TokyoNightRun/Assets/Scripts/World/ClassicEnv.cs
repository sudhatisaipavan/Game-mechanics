using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>Classic City: brick apartments, glass downtown towers, and an industrial rail yard, all covered in street art.</summary>
    public static class ClassicEnv
    {
        static Color C(int rgb) { return GameConfig.Hex(rgb); }
        static readonly int[] Brick = { 0xB5654A, 0xA55A44, 0xC27A58, 0x9C5B4B, 0xBF7B63 };
        static readonly int[] Glass = { 0x7FA7C9, 0x6C93B8, 0x8FB4D4, 0x5F86AA };
        static readonly int[] Concrete = { 0xB8B4AC, 0xA9A8A4, 0xC4BFB5 };

        public static void Overhead(MeshBatcher b, float z, int m, System.Random rng)
        {
            // hanging city banner and a pair of road-sign style boards on the gantry
            if (m == 0)
            {
                b.Box(new Vector3(0, 7.25f, z), new Vector3(3.2f, 0.9f, 0.06f), C(0x1565C0));
                b.Box(new Vector3(0, 7.25f, z - 0.04f), new Vector3(2.8f, 0.55f, 0.04f), Color.white);
                for (int k = 0; k < 5; k++) b.Box(new Vector3(-1.1f + k * 0.55f, 7.25f, z - 0.07f), new Vector3(0.3f, 0.34f, 0.03f), Theme.Pal(k));
            }
            else
                b.Garland(new Vector3(-4.35f, 6.2f, z), new Vector3(4.35f, 6.2f, z), 0.9f, 14, 0.14f, ThemedEnvironment.Glow(0xFFE9A8, 0.1f), ThemedEnvironment.Glow(0xFFC400, 0.1f));
        }

        public static void Build(MeshBatcher b, int variant, float L, System.Random rng)
        {
            for (int s = -1; s <= 1; s += 2)
            {
                if (variant == 0) { Canopy(b, s, L, rng); Furniture(b, s, rng); Apartments(b, s, L, rng); }
                else if (variant == 1) { Downtown(b, s, L, rng); }
                else { Industrial(b, s, L, rng); }
                ThemedEnvironment.Skyline(b, s, L, rng, variant == 1 ? Glass : variant == 0 ? Brick : Concrete, variant == 1 ? TexId.Window : TexId.Facade, 4f, variant == 1 ? 28f : 16f, variant == 1 ? 46f : 30f);
            }
            if (variant == 0) Footbridge(b, 22f);
        }

        static void Canopy(MeshBatcher b, int s, float L, System.Random rng)
        {
            float x0 = s * ThemedEnvironment.PlatformInnerX, x1 = s * ThemedEnvironment.PlatformOuterX;
            float cx = (x0 + x1) * 0.5f, w = Mathf.Abs(x1 - x0) + 0.8f;
            b.Box(new Vector3(cx, 4.7f, L * 0.5f), new Vector3(w, 0.22f, L), C(0xCFD6DE), new Vector3(0, 0, -s * 4f), TexId.Metal, 3f);
            b.Box(new Vector3(cx - s * (w * 0.5f - 0.1f), 4.5f, L * 0.5f), new Vector3(0.22f, 0.5f, L), C(0x2B3A55));
            for (int i = 0; i < 10; i++) b.Box(new Vector3(cx - s * (w * 0.5f + 0.02f), 4.5f, 1.5f + i * 3f), new Vector3(0.1f, 0.42f, 2.8f), Theme.Pal(i));
            for (int i = 0; i < 4; i++)
            {
                float z = 3.75f + i * 7.5f;
                b.Box(new Vector3(s * (ThemedEnvironment.PlatformInnerX + 1.0f), 2.9f, z), new Vector3(0.28f, 3.9f, 0.28f), C(0x4A5568), default(Vector3), TexId.Metal, 2f);
                b.Sph(new Vector3(s * (ThemedEnvironment.PlatformInnerX + 1.0f), 3.9f, z + 0.3f), 0.22f, ThemedEnvironment.Glow(0xFFF1B8));
            }
        }

        static void Furniture(MeshBatcher b, int s, System.Random rng)
        {
            for (int i = 0; i < 2; i++)
            {
                float z = 7f + i * 15f, x = s * 8.2f;
                b.Box(new Vector3(x, 1.45f, z), new Vector3(0.6f, 0.08f, 2.0f), C(0x8D5A2B), default(Vector3), TexId.Wood, 1f);
                b.Box(new Vector3(x + s * 0.28f, 1.85f, z), new Vector3(0.08f, 0.6f, 2.0f), C(0x8D5A2B), default(Vector3), TexId.Wood, 1f);
                for (int e = -1; e <= 1; e += 2) b.Box(new Vector3(x, 1.22f, z + e * 0.85f), new Vector3(0.5f, 0.44f, 0.08f), ThemedEnvironment.Dark);
            }
            // newsstand kiosk
            b.Box(new Vector3(s * 7.6f, 2.0f, 13.5f), new Vector3(1.6f, 2.0f, 2.2f), C(0x2E7D32), default(Vector3), TexId.Metal, 1.5f);
            b.Box(new Vector3(s * 6.7f, 2.2f, 13.5f), new Vector3(0.1f, 0.9f, 1.8f), Color.white, default(Vector3), TexId.Window, 1f);
            b.Box(new Vector3(s * 7.4f, 3.25f, 13.5f), new Vector3(2.0f, 0.12f, 2.6f), Theme.Pal(s + 3), default(Vector3), TexId.Canvas, 1f);
            // trash can and vending machine
            b.Cyl(new Vector3(s * 5.2f, 1.45f, 4f), 0.5f, 0.9f, C(0x455A64));
            b.Box(new Vector3(s * 8.7f, 2.0f, 4.5f), new Vector3(0.9f, 2.0f, 1.0f), C(0xD32F2F));
            b.Box(new Vector3(s * 8.22f, 2.2f, 4.5f), new Vector3(0.04f, 1.2f, 0.7f), ThemedEnvironment.Glow(0xFFF3C4, 0.1f));
        }

        static void Apartments(MeshBatcher b, int s, float L, System.Random rng)
        {
            float z = 0f; int guard = 0;
            while (z < L - 2f && guard++ < 6)
            {
                float depth = Mathf.Min(L - z, 8f + (float)rng.NextDouble() * 6f);
                int floors = rng.Next(4, 8); float h = floors * 3.2f;
                Color wall = C(Brick[rng.Next(Brick.Length)]);
                float cz = z + depth * 0.5f, bx = s * (ThemedEnvironment.PlatformOuterX + 3.8f), width = 6.5f;
                b.Box(new Vector3(bx, h * 0.5f, cz), new Vector3(width, h, depth - 0.15f), wall, default(Vector3), TexId.Facade, 4f);
                b.Box(new Vector3(bx, h + 0.25f, cz), new Vector3(width + 0.3f, 0.5f, depth), C(0x6D4C41));
                float faceX = bx - s * (width * 0.5f);
                // fire escape: landings + diagonal stairs
                for (int f = 1; f < floors; f++)
                {
                    float y = f * 3.2f + 0.6f;
                    b.Box(new Vector3(faceX - s * 0.5f, y, cz), new Vector3(0.9f, 0.08f, depth * 0.5f), C(0x2B2F36));
                    b.Box(new Vector3(faceX - s * 0.95f, y + 0.45f, cz), new Vector3(0.04f, 0.9f, depth * 0.5f), C(0x2B2F36));
                    b.Box(new Vector3(faceX - s * 0.5f, y + 1.6f, cz + depth * 0.2f), new Vector3(0.05f, 3.3f, 0.05f), C(0x2B2F36), new Vector3(30 * s, 0, 0));
                }
                // ground-floor shop awning
                b.Box(new Vector3(faceX - s * 0.05f, 1.4f, cz), new Vector3(0.12f, 2.6f, depth - 0.6f), C(0x3E2723));
                Color aw = Theme.RandomPal(rng);
                for (int i = 0; i < 4; i++)
                    b.Box(new Vector3(faceX - s * 0.55f, 2.7f, cz - depth * 0.35f + i * depth * 0.23f), new Vector3(1.2f, 0.08f, depth * 0.23f), i % 2 == 0 ? Color.white : aw, new Vector3(0, 0, s * 12f));
                // rooftop water tower on stilts
                if (rng.NextDouble() < 0.75)
                {
                    for (int k = 0; k < 4; k++) b.Box(new Vector3(bx + (k % 2 - 0.5f) * 1.4f, h + 1.2f, cz + (k / 2 - 0.5f) * 1.4f), new Vector3(0.12f, 1.8f, 0.12f), C(0x4E342E));
                    b.Cyl(new Vector3(bx, h + 3.0f, cz), 2.2f, 2.2f, C(0x8D6E63));
                    b.Cyl(new Vector3(bx, h + 4.2f, cz), 2.3f, 0.3f, C(0x5D4037));
                }
                // graffiti on the building face
                b.Decal(new Vector3(faceX - s * 0.02f, 3.0f + (float)rng.NextDouble() * 2f, cz), new Vector2(Mathf.Min(5f, depth - 1f), 2.4f), -s, Color.white, (TexId)((int)TexId.Graffiti0 + rng.Next(4)));
                z += depth;
            }
        }

        static void Downtown(MeshBatcher b, int s, float L, System.Random rng)
        {
            float z = 0f; int guard = 0;
            while (z < L - 2f && guard++ < 4)
            {
                float depth = Mathf.Min(L - z, 9f + (float)rng.NextDouble() * 5f);
                float h = 20f + (float)rng.NextDouble() * 20f;
                float cz = z + depth * 0.5f, bx = s * (ThemedEnvironment.PlatformOuterX + 4.2f), width = 7f;
                Color glass = C(Glass[rng.Next(Glass.Length)]);
                b.Box(new Vector3(bx, h * 0.5f, cz), new Vector3(width, h, depth - 0.4f), glass, default(Vector3), TexId.Window, 3f);
                for (int f = 1; f < 6; f++) b.Box(new Vector3(bx - s * (width * 0.5f + 0.02f), f * (h / 6f), cz), new Vector3(0.06f, 0.14f, depth - 0.4f), C(0xE8EEF4));
                b.Box(new Vector3(bx, h + 0.3f, cz), new Vector3(width * 0.6f, 0.6f, depth * 0.6f), C(0x607D8B));
                b.Box(new Vector3(bx, h + 2.2f, cz), new Vector3(0.12f, 4f, 0.12f), C(0xB0BEC5));
                b.Sph(new Vector3(bx, h + 4.3f, cz), 0.3f, ThemedEnvironment.Glow(0xFF3D3D));
                // lit ground-floor storefront with big billboard ad
                float faceX = bx - s * (width * 0.5f);
                b.Box(new Vector3(faceX - s * 0.1f, 1.6f, cz), new Vector3(0.2f, 3.0f, depth - 1f), C(0x263238));
                b.Box(new Vector3(faceX - s * 0.22f, 1.5f, cz), new Vector3(0.06f, 2.0f, depth - 2f), ThemedEnvironment.Glow(0xFFF1C1, 0.2f));
                b.Decal(new Vector3(faceX - s * 0.03f, 8f + (float)rng.NextDouble() * 5f, cz), new Vector2(Mathf.Min(7f, depth), 3.4f), -s, Color.white, (TexId)((int)TexId.Graffiti0 + rng.Next(4)));
                z += depth;
            }
            // street trees, lamps, bus shelter and traffic light on the platform
            for (int i = 0; i < 3; i++) ThemedEnvironment.RoundTree(b, new Vector3(s * 8.4f, 1.0f, 4f + i * 10f), 3.6f, C(0x3FA34D));
            ThemedEnvironment.Lamp(b, new Vector3(s * 5.0f, 1.0f, 9f), 4.2f, C(0x37474F), ThemedEnvironment.Glow(0xFFF1B8));
            ThemedEnvironment.Lamp(b, new Vector3(s * 5.0f, 1.0f, 24f), 4.2f, C(0x37474F), ThemedEnvironment.Glow(0xFFF1B8));
            b.Box(new Vector3(s * 7.4f, 3.2f, 15f), new Vector3(1.8f, 0.1f, 3.6f), C(0x1976D2));
            b.Box(new Vector3(s * 8.2f, 2.1f, 15f), new Vector3(0.05f, 2.1f, 3.4f), Color.white, default(Vector3), TexId.Window, 1f);
            for (int e = -1; e <= 1; e += 2) b.Box(new Vector3(s * 6.6f, 2.1f, 15f + e * 1.7f), new Vector3(0.08f, 2.2f, 0.08f), C(0x37474F));
        }

        static void Industrial(MeshBatcher b, int s, float L, System.Random rng)
        {
            // warehouses with sawtooth roofs
            float bx = s * (ThemedEnvironment.PlatformOuterX + 4.5f);
            for (int i = 0; i < 2; i++)
            {
                float cz = 7f + i * 15f, h = 7f + (float)rng.NextDouble() * 3f;
                b.Box(new Vector3(bx, h * 0.5f, cz), new Vector3(8f, h, 13f), C(Brick[rng.Next(Brick.Length)]), default(Vector3), TexId.Brick, 3f);
                b.Prim(PrimKind.Wedge, new Vector3(bx, h + 0.8f, cz), new Vector3(8.2f, 1.6f, 13.2f), C(0x607D8B));
                b.Box(new Vector3(bx - s * 4.02f, 2.2f, cz), new Vector3(0.06f, 3.4f, 4f), C(0x455A64));      // roller door
                b.Box(new Vector3(bx - s * 4.06f, 4.4f, cz), new Vector3(0.05f, 0.5f, 5f), ThemedEnvironment.Glow(0xFFC400, 0.15f));
                b.Decal(new Vector3(bx - s * 4.03f, 5.2f, cz + 3.5f), new Vector2(4.2f, 2.1f), -s, Color.white, (TexId)((int)TexId.Graffiti0 + rng.Next(4)));
            }
            // striped chimney + shipping containers
            float cx = s * (ThemedEnvironment.PlatformOuterX + 12f);
            for (int k = 0; k < 6; k++) b.Cyl(new Vector3(cx, 3f + k * 4.2f, 22f), 2.6f - k * 0.1f, 4.2f, k % 2 == 0 ? C(0xE53935) : Color.white);
            b.Cyl(new Vector3(cx, 27.5f, 22f), 2.8f, 0.4f, C(0x37474F));
            for (int i = 0; i < 3; i++)
            {
                Color cc = Theme.Pal(i * 2 + (s > 0 ? 1 : 0));
                b.Box(new Vector3(s * 8.0f, 1.0f + 1.3f, 5f + i * 7f), new Vector3(2.4f, 2.6f, 6f), cc, default(Vector3), TexId.Metal, 2f);
                if (i == 1) b.Box(new Vector3(s * 8.0f, 1.0f + 3.9f, 8.5f), new Vector3(2.4f, 2.6f, 6f), Theme.Pal(i + 3), default(Vector3), TexId.Metal, 2f);
            }
            // light poles and barrels
            ThemedEnvironment.Lamp(b, new Vector3(s * 5.0f, 1.0f, 12f), 5f, C(0x546E7A), ThemedEnvironment.Glow(0xFFE9A8));
            for (int i = 0; i < 4; i++) b.Cyl(new Vector3(s * (5.6f + i % 2 * 0.7f), 1.45f, 19f + i * 1.1f), 0.6f, 0.9f, i % 2 == 0 ? C(0x1565C0) : C(0xEF6C00));
        }

        static void Footbridge(MeshBatcher b, float z)
        {
            b.Box(new Vector3(0, 7.4f, z), new Vector3(19.5f, 0.3f, 2.4f), C(0x78909C), default(Vector3), TexId.Metal, 3f);
            for (int e = -1; e <= 1; e += 2) b.Box(new Vector3(0, 8.4f, z + e * 1.15f), new Vector3(19.5f, 0.1f, 0.1f), C(0xFFC400));
            for (int i = 0; i < 14; i++) for (int e = -1; e <= 1; e += 2) b.Box(new Vector3(-9.2f + i * 1.4f, 7.9f, z + e * 1.15f), new Vector3(0.06f, 1.0f, 0.06f), C(0x90A4AE));
            for (int s = -1; s <= 1; s += 2) b.Box(new Vector3(s * 5.2f, 3.7f, z), new Vector3(0.5f, 7.4f, 0.5f), C(0x607D8B), default(Vector3), TexId.Metal, 2f);
        }
    }
}
