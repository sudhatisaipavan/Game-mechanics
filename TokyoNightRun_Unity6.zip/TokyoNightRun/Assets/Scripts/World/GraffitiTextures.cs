using System.Collections.Generic;
using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Procedural street-art panels (bubble letters with outline, gloss and paint splatter) drawn into small textures.
    /// Used on train sides and platform walls to give the Subway-Surfers "graffiti train" look without any image files.
    /// Letters are stroke polylines; each pixel measures its distance to the strokes, which gives fat rounded bubble type.
    /// </summary>
    public static class GraffitiTextures
    {
        const int W = 192, H = 96;
        
        // Each letter = list of polylines in a 0..1 x 0..1 box (y up).
        static readonly Dictionary<char, float[][]> Font = new Dictionary<char, float[][]>
        {
            { 'H', new[] { new[] { 0f, 0f, 0f, 1f }, new[] { 1f, 0f, 1f, 1f }, new[] { 0f, .5f, 1f, .5f } } },
            { 'O', new[] { new[] { .5f, 0f, .12f, .15f, 0f, .5f, .12f, .85f, .5f, 1f, .88f, .85f, 1f, .5f, .88f, .15f, .5f, 0f } } },
            { 'L', new[] { new[] { 0f, 1f, 0f, 0f, 1f, 0f } } },
            { 'I', new[] { new[] { .5f, 0f, .5f, 1f } } },
            { 'R', new[] { new[] { 0f, 0f, 0f, 1f, .7f, 1f, 1f, .85f, 1f, .65f, .7f, .5f, 0f, .5f }, new[] { .5f, .5f, 1f, 0f } } },
            { 'A', new[] { new[] { 0f, 0f, .5f, 1f, 1f, 0f }, new[] { .2f, .38f, .8f, .38f } } },
            { 'N', new[] { new[] { 0f, 0f, 0f, 1f, 1f, 0f, 1f, 1f } } },
            { 'G', new[] { new[] { 1f, .85f, .7f, 1f, .3f, 1f, 0f, .8f, 0f, .2f, .3f, 0f, .7f, 0f, 1f, .2f, 1f, .45f, .55f, .45f } } },
            { 'U', new[] { new[] { 0f, 1f, 0f, .2f, .25f, 0f, .75f, 0f, 1f, .2f, 1f, 1f } } },
            { 'C', new[] { new[] { 1f, .85f, .7f, 1f, .3f, 1f, 0f, .8f, 0f, .2f, .3f, 0f, .7f, 0f, 1f, .15f } } },
            { 'T', new[] { new[] { 0f, 1f, 1f, 1f }, new[] { .5f, 1f, .5f, 0f } } },
            { 'Y', new[] { new[] { 0f, 1f, .5f, .5f, 1f, 1f }, new[] { .5f, .5f, .5f, 0f } } },
            { 'D', new[] { new[] { 0f, 0f, 0f, 1f, .55f, 1f, 1f, .8f, 1f, .2f, .55f, 0f, 0f, 0f } } },
            { 'W', new[] { new[] { 0f, 1f, .25f, 0f, .5f, .7f, .75f, 0f, 1f, 1f } } },
            { 'E', new[] { new[] { 1f, 1f, 0f, 1f, 0f, 0f, 1f, 0f }, new[] { 0f, .5f, .8f, .5f } } },
            { 'J', new[] { new[] { 1f, 1f, 1f, .2f, .75f, 0f, .25f, 0f, 0f, .2f } } },
            { 'K', new[] { new[] { 0f, 0f, 0f, 1f }, new[] { 1f, 1f, 0f, .45f }, new[] { .3f, .62f, 1f, 0f } } },
            { 'M', new[] { new[] { 0f, 0f, 0f, 1f, .5f, .45f, 1f, 1f, 1f, 0f } } },
            { 'B', new[] { new[] { 0f, 0f, 0f, 1f, .65f, 1f, .95f, .85f, .95f, .68f, .65f, .52f, 0f, .52f }, new[] { .65f, .52f, 1f, .4f, 1f, .15f, .65f, 0f, 0f, 0f } } },
            { 'F', new[] { new[] { 1f, 1f, 0f, 1f, 0f, 0f }, new[] { 0f, .5f, .75f, .5f } } },
            { 'P', new[] { new[] { 0f, 0f, 0f, 1f, .7f, 1f, 1f, .85f, 1f, .65f, .7f, .5f, 0f, .5f } } },
            { 'V', new[] { new[] { 0f, 1f, .5f, 0f, 1f, 1f } } },
            { 'S', new[] { new[] { 1f, .85f, .75f, 1f, .25f, 1f, 0f, .8f, .25f, .55f, .75f, .45f, 1f, .2f, .75f, 0f, .25f, 0f, 0f, .15f } } },
        };

        struct Seg { public float x0, y0, x1, y1; public int letter; }

        public static Texture2D Make(int variant)
        {
            var th = Theme.Current;
            variant = Mathf.Clamp(variant, 0, th.GraffitiWords.Length - 1);
            string word = th.GraffitiWords[variant];
            var px = new Color32[W * H];
            var rng = new System.Random(1234 + variant * 97);

            Color bg = GameConfig.Hex(th.GraffitiBackgrounds[variant]);
            Color bg2 = Color.Lerp(bg, Color.white, 0.35f);
            // background: diagonal soft stripes + vertical gradient
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++)
                {
                    float stripe = Mathf.Repeat((x + y) / 22f, 1f) < 0.5f ? 0f : 0.12f;
                    float g = y / (float)H;
                    Color c = Color.Lerp(bg, bg2, g * 0.6f + stripe);
                    px[y * W + x] = c;
                }
            // paint splatters
            for (int i = 0; i < 14; i++)
            {
                Color sc = th.Palette[rng.Next(th.Palette.Length)];
                float cx = (float)rng.NextDouble() * W, cy = (float)rng.NextDouble() * H, r = 3f + (float)rng.NextDouble() * 7f;
                Disc(px, cx, cy, r, sc);
            }

            // build stroke segments, letters laid out left-to-right
            var segs = new List<Seg>();
            int n = word.Length;
            float margin = 14f;
            float cell = (W - margin * 2f) / n;
            float letterW = cell * 0.62f, letterH = H * 0.5f;
            float baseY = H * 0.24f;
            var boxes = new Vector4[n]; // x min, y min, x max, y max in pixels (with padding for outline)
            for (int li = 0; li < n; li++)
            {
                float[][] strokes;
                if (!Font.TryGetValue(word[li], out strokes)) continue;
                float ox = margin + li * cell + (cell - letterW) * 0.5f;
                float wob = Mathf.Sin(li * 1.7f + variant) * 4f; // bouncy baseline
                for (int s = 0; s < strokes.Length; s++)
                {
                    var pts = strokes[s];
                    for (int k = 0; k + 3 < pts.Length; k += 2)
                        segs.Add(new Seg
                        {
                            x0 = ox + pts[k] * letterW, y0 = baseY + wob + pts[k + 1] * letterH,
                            x1 = ox + pts[k + 2] * letterW, y1 = baseY + wob + pts[k + 3] * letterH, letter = li
                        });
                }
                boxes[li] = new Vector4(ox - 18f, baseY + wob - 18f, ox + letterW + 18f, baseY + wob + letterH + 18f);
            }

            const float R = 7.5f, O = 3.2f; // stroke half-width, outline thickness
            var fills = th.GraffitiFills[variant];
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++)
                {
                    float best = 1e9f; int bestLetter = -1;
                    for (int s = 0; s < segs.Count; s++)
                    {
                        var sg = segs[s];
                        var bx = boxes[sg.letter];
                        if (x < bx.x || x > bx.z || y < bx.y || y > bx.w) continue;
                        float d = DistToSeg(x, y, sg.x0, sg.y0, sg.x1, sg.y1);
                        if (d < best) { best = d; bestLetter = sg.letter; }
                    }
                    if (bestLetter < 0) continue;
                    // drop shadow (offset 3px right/down)
                    if (best > R + O && best < R + O + 5f)
                    {
                        Color cur = px[y * W + x];
                        px[y * W + x] = Color.Lerp(cur, Color.black, 0.18f);
                    }
                    if (best < R + O)
                    {
                        Color outline = GameConfig.Hex(th.GraffitiOutline);
                        px[y * W + x] = outline;
                    }
                    if (best < R)
                    {
                        Color f = GameConfig.Hex(fills[bestLetter % fills.Length]);
                        float t = best / R;                              // 0 centre .. 1 edge
                        float vy = y / (float)H;
                        Color c = Color.Lerp(Color.Lerp(f, Color.white, 0.45f), f * 0.82f, Mathf.Clamp01(t * t * 0.9f + (0.5f - vy) * 0.25f));
                        if (t < 0.28f && y > H * 0.3f) c = Color.Lerp(c, Color.white, 0.5f); // glossy highlight line
                        c.a = 1f;
                        px[y * W + x] = c;
                    }
                }

            // sparkles / stars
            for (int i = 0; i < 6; i++)
            {
                float cx = (float)rng.NextDouble() * W, cy = (float)rng.NextDouble() * H;
                Disc(px, cx, cy, 1.6f, Color.white);
            }

            var tex = new Texture2D(W, H, TextureFormat.RGBA32, true);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            tex.SetPixels32(px);
            tex.Apply(true, true);
            return tex;
        }

        static void Disc(Color32[] px, float cx, float cy, float r, Color c)
        {
            int x0 = Mathf.Max(0, (int)(cx - r)), x1 = Mathf.Min(W - 1, (int)(cx + r));
            int y0 = Mathf.Max(0, (int)(cy - r)), y1 = Mathf.Min(H - 1, (int)(cy + r));
            for (int y = y0; y <= y1; y++)
                for (int x = x0; x <= x1; x++)
                {
                    float dx = x - cx, dy = y - cy;
                    if (dx * dx + dy * dy <= r * r) px[y * W + x] = c;
                }
        }

        static float DistToSeg(float px, float py, float ax, float ay, float bx, float by)
        {
            float vx = bx - ax, vy = by - ay;
            float len2 = vx * vx + vy * vy;
            float t = len2 > 0.0001f ? Mathf.Clamp01(((px - ax) * vx + (py - ay) * vy) / len2) : 0f;
            float cx = ax + vx * t - px, cy = ay + vy * t - py;
            return Mathf.Sqrt(cx * cx + cy * cy);
        }
    }
}
