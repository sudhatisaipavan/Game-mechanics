using System.Collections.Generic;
using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Creates and caches one Material per colour so the game needs no material files.
    /// Every material uses one of the TokyoNightRun shaders (Assets/Shaders), which render in the Universal Render Pipeline
    /// (Unity 6) and fall back to the Built-in pipeline. If a TokyoNightRun shader cannot be found a standard shader is used instead.
    /// The editor tool adds the shaders to "Always Included Shaders" so they are not stripped from builds.
    /// </summary>
    public static class MaterialLibrary
    {
        public const string VertexShaderName = "TokyoNightRun/VertexLit";
        public const string CharacterShaderName = "TokyoNightRun/Character";
        public const string UnlitShaderName = "TokyoNightRun/Unlit";
        public const string ParticleShaderName = "TokyoNightRun/Particle";
        public const string SkyShaderName = "TokyoNightRun/Sky";

        const float SrcAlpha = 5f, OneMinusSrcAlpha = 10f, One = 1f;

        static readonly Dictionary<int, Material> lit = new Dictionary<int, Material>();
        static readonly Dictionary<int, Material> glow = new Dictionary<int, Material>();
        static readonly Dictionary<int, Material> alpha = new Dictionary<int, Material>();
        static readonly Dictionary<int, Material> vert = new Dictionary<int, Material>();
        static readonly Dictionary<string, Material> custom = new Dictionary<string, Material>();
        static Shader vertShader, diffuseShader, litShader, glowShader, particleShader, skyShader;
        static bool vertChecked;
        static Material particleMat, sparkleMat, cloudMat, shadowMat, skyMat;
        static Texture2D softTex, starTex, cloudTex;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        public static void Clear()
        {
            lit.Clear(); glow.Clear(); alpha.Clear(); vert.Clear(); custom.Clear();
            vertShader = diffuseShader = litShader = glowShader = particleShader = skyShader = null;
            vertChecked = false;
            particleMat = sparkleMat = cloudMat = shadowMat = skyMat = null;
            softTex = starTex = cloudTex = null;
        }

        static int Key(Color c)
        {
            Color32 k = c;
            return (k.r << 24) | (k.g << 16) | (k.b << 8) | k.a;
        }

        static Shader Find(params string[] names)
        {
            for (int i = 0; i < names.Length; i++)
            {
                var s = Shader.Find(names[i]);
                if (s != null) return s;
            }
            return null;
        }

        /// <summary>True when the custom TokyoNightRun/VertexLit shader is available (Assets/Shaders). Otherwise batching falls back to flat colours.</summary>
        public static bool HasVertexShader
        {
            get
            {
                if (!vertChecked) { vertShader = Shader.Find(VertexShaderName); vertChecked = true; }
                return vertShader != null;
            }
        }

        /// <summary>Vertex-coloured, optionally textured material for batched world geometry. Only call when HasVertexShader.</summary>
        public static Material Vertex(TexId tex)
        {
            int k = (int)tex;
            Material m;
            if (vert.TryGetValue(k, out m) && m != null) return m;
            m = new Material(vertShader);
            m.name = "Vertex_" + tex;
            var t = TextureFactory.Get(tex);
            if (t != null) m.mainTexture = t;
            vert[k] = m;
            return m;
        }

        /// <summary>Character material with a texture and tint, cached by key (used for the runner skins).</summary>
        public static Material Textured(string key, Color tint, Texture2D tex)
        {
            Material m;
            if (custom.TryGetValue(key, out m) && m != null) return m;
            if (diffuseShader == null)
                diffuseShader = Find(CharacterShaderName, "Universal Render Pipeline/Simple Lit", "Universal Render Pipeline/Lit",
                    "Legacy Shaders/Diffuse", "Mobile/Diffuse", "Standard", "Unlit/Color", "Sprites/Default");
            m = new Material(diffuseShader);
            m.color = tint;
            if (tex != null) m.mainTexture = tex;
            m.name = "Tex_" + key;
            custom[key] = m;
            return m;
        }

        /// <summary>Normal lit material (cartoon lighting).</summary>
        public static Material Lit(Color c)
        {
            int k = Key(c);
            Material m;
            if (lit.TryGetValue(k, out m) && m != null) return m;
            if (litShader == null)
                litShader = Find(VertexShaderName, "Universal Render Pipeline/Simple Lit", "Legacy Shaders/Diffuse", "Mobile/Diffuse", "Standard", "Unlit/Color", "Sprites/Default");
            m = new Material(litShader);
            m.color = c;
            m.name = "Lit_" + k;
            lit[k] = m;
            return m;
        }

        /// <summary>Bright unlit material for coins, lamps and pickups so they "pop" (the colour is boosted and picked up by bloom).</summary>
        public static Material Glow(Color c)
        {
            int k = Key(c);
            Material m;
            if (glow.TryGetValue(k, out m) && m != null) return m;
            if (glowShader == null) glowShader = Find(UnlitShaderName, "Universal Render Pipeline/Unlit", "Unlit/Color", "Sprites/Default");
            m = new Material(glowShader);
            m.color = c;
            m.name = "Glow_" + k;
            glow[k] = m;
            return m;
        }

        /// <summary>Transparent unlit material (shield bubble).</summary>
        public static Material Alpha(Color c)
        {
            int k = Key(c);
            Material m;
            if (alpha.TryGetValue(k, out m) && m != null) return m;
            m = NewParticleMaterial("Alpha_" + k, null, false);
            m.color = c;
            alpha[k] = m;
            return m;
        }

        /// <summary>Soft dark blob used as a cheap ground shadow.</summary>
        public static Material Shadow()
        {
            if (shadowMat != null) return shadowMat;
            EnsureTextures();
            shadowMat = NewParticleMaterial("BlobShadow", softTex, false);
            shadowMat.color = new Color(0.08f, 0.02f, 0.16f, 0.55f);
            return shadowMat;
        }

        /// <summary>Soft round particle material (generated texture, no files needed). Alpha blended.</summary>
        public static Material Particle()
        {
            if (particleMat != null) return particleMat;
            EnsureTextures();
            particleMat = NewParticleMaterial("Particle_Soft", softTex, false);
            return particleMat;
        }

        /// <summary>Glowing four-point star material (additive) for coin sparkles and bursts.</summary>
        public static Material Sparkle()
        {
            if (sparkleMat != null) return sparkleMat;
            EnsureTextures();
            sparkleMat = NewParticleMaterial("Particle_Sparkle", starTex, true);
            return sparkleMat;
        }

        /// <summary>Soft white cloud puff (alpha blended).</summary>
        public static Material Cloud()
        {
            if (cloudMat != null) return cloudMat;
            EnsureTextures();
            cloudMat = NewParticleMaterial("Cloud", cloudTex, false);
            return cloudMat;
        }

        /// <summary>Gradient sky dome material (null-safe: returns a flat unlit material if the sky shader is missing).</summary>
        public static Material Sky()
        {
            if (skyMat != null) return skyMat;
            if (skyShader == null) skyShader = Find(SkyShaderName, "Unlit/Color", "Sprites/Default");
            skyMat = new Material(skyShader);
            skyMat.name = "Sky";
            return skyMat;
        }

        public static bool HasSkyShader { get { return Shader.Find(SkyShaderName) != null; } }

        static Material NewParticleMaterial(string name, Texture2D tex, bool additive)
        {
            if (particleShader == null) particleShader = Find(ParticleShaderName, "Universal Render Pipeline/Particles/Unlit", "Sprites/Default", "Unlit/Color");
            var m = new Material(particleShader);
            m.name = name;
            if (tex != null) m.mainTexture = tex;
            if (m.HasProperty("_SrcBlend")) m.SetFloat("_SrcBlend", SrcAlpha);
            if (m.HasProperty("_DstBlend")) m.SetFloat("_DstBlend", additive ? One : OneMinusSrcAlpha);
            return m;
        }

        // ------------------------------------------------------------- generated textures
        static void EnsureTextures()
        {
            if (softTex == null)
            {
                const int n = 32;
                softTex = new Texture2D(n, n, TextureFormat.RGBA32, false);
                softTex.wrapMode = TextureWrapMode.Clamp;
                var px = new Color[n * n];
                for (int y = 0; y < n; y++)
                    for (int x = 0; x < n; x++)
                    {
                        float dx = (x - (n - 1) * 0.5f) / (n * 0.5f);
                        float dy = (y - (n - 1) * 0.5f) / (n * 0.5f);
                        float a = Mathf.Clamp01(1f - Mathf.Sqrt(dx * dx + dy * dy));
                        a = a * a * (3f - 2f * a);
                        px[y * n + x] = new Color(1f, 1f, 1f, a);
                    }
                softTex.SetPixels(px);
                softTex.Apply();
            }
            if (starTex == null)
            {
                const int n = 64;
                starTex = new Texture2D(n, n, TextureFormat.RGBA32, false);
                starTex.wrapMode = TextureWrapMode.Clamp;
                var px = new Color[n * n];
                for (int y = 0; y < n; y++)
                    for (int x = 0; x < n; x++)
                    {
                        float dx = (x - (n - 1) * 0.5f) / (n * 0.5f);
                        float dy = (y - (n - 1) * 0.5f) / (n * 0.5f);
                        float r = Mathf.Sqrt(dx * dx + dy * dy);
                        float core = Mathf.Clamp01(1f - r * 1.6f); core *= core;
                        float cross = Mathf.Exp(-Mathf.Abs(dx) * 18f) * Mathf.Exp(-Mathf.Abs(dy) * 2.4f)
                                    + Mathf.Exp(-Mathf.Abs(dy) * 18f) * Mathf.Exp(-Mathf.Abs(dx) * 2.4f);
                        float a = Mathf.Clamp01(core * 0.9f + cross * 0.8f);
                        px[y * n + x] = new Color(1f, 1f, 1f, a);
                    }
                starTex.SetPixels(px);
                starTex.Apply();
            }
            if (cloudTex == null)
            {
                const int w = 128, h = 64;
                cloudTex = new Texture2D(w, h, TextureFormat.RGBA32, false);
                cloudTex.wrapMode = TextureWrapMode.Clamp;
                cloudTex.filterMode = FilterMode.Bilinear;
                var px = new Color[w * h];
                for (int y = 0; y < h; y++)
                    for (int x = 0; x < w; x++)
                    {
                        float u = x / (float)(w - 1) * 2f - 1f;
                        float v = y / (float)(h - 1) * 2f - 1f;
                        // three overlapping puffs with a flat bottom -> classic cartoon cloud
                        float d = Puff(u, v, -0.45f, -0.05f, 0.42f) + Puff(u, v, 0.05f, 0.18f, 0.55f) + Puff(u, v, 0.52f, -0.08f, 0.4f);
                        float a = Mathf.Clamp01(d);
                        a = a * a * (3f - 2f * a);
                        if (v < -0.55f) a *= Mathf.Clamp01((v + 0.9f) / 0.35f); // soft flat base
                        float shade = Mathf.Lerp(0.82f, 1f, Mathf.Clamp01((v + 0.6f) * 0.9f)); // slightly blue-grey underside
                        px[y * w + x] = new Color(shade, shade, Mathf.Min(1f, shade + 0.04f), a);
                    }
                cloudTex.SetPixels(px);
                cloudTex.Apply();
            }
        }

        static float Puff(float u, float v, float cx, float cy, float r)
        {
            float dx = (u - cx) / r, dy = (v - cy) / (r * 1.5f);
            return Mathf.Clamp01(1.6f - Mathf.Sqrt(dx * dx + dy * dy) * 1.6f);
        }
    }
}
