using System.Collections.Generic;
using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Collects boxes, cylinders, spheres and wedges (with colours) and bakes them into a handful of combined meshes.
    /// A whole 30 m street segment, a train or an obstacle becomes 1-4 draw calls instead of hundreds.
    /// Colour alpha &lt; 1 marks a surface as emissive (glows, ignores lighting). Alpha 0 = fully emissive.
    /// With the custom shader the colour is a vertex colour; without it, geometry is grouped per flat colour.
    /// </summary>
    public class MeshBatcher
    {
        class Batch
        {
            public Material Mat;
            public readonly List<Vector3> V = new List<Vector3>();
            public readonly List<Vector3> N = new List<Vector3>();
            public readonly List<Vector2> UV = new List<Vector2>();
            public readonly List<Color32> C = new List<Color32>();
            public readonly List<int> T = new List<int>();
        }

        readonly Dictionary<long, Batch> batches = new Dictionary<long, Batch>();
        public int VertexCount { get; private set; }

        Batch Get(Color color, TexId tex)
        {
            long key;
            Material mat;
            if (MaterialLibrary.HasVertexShader)
            {
                key = (long)tex;
                mat = null; // created lazily in Build
            }
            else
            {
                Color32 k = color;
                key = 1000L + (((long)k.r << 24) | ((long)k.g << 16) | ((long)k.b << 8) | k.a);
                mat = color.a < 0.5f ? MaterialLibrary.Glow(color) : MaterialLibrary.Lit(color);
            }
            Batch b;
            if (!batches.TryGetValue(key, out b))
            {
                b = new Batch { Mat = mat };
                if (mat == null) b.Mat = MaterialLibrary.Vertex(tex);
                batches[key] = b;
            }
            return b;
        }

        static Color32 Vc(Color c)
        {
            // In fallback (flat material) mode the vertex colour is irrelevant, but keep it white-ish and harmless.
            return c;
        }

        /// <summary>Axis-aligned (then rotated) box. UVs are in metres divided by 'tile' so textures keep a constant scale.</summary>
        public void Box(Vector3 centre, Vector3 size, Color color, Vector3 euler = default(Vector3), TexId tex = TexId.None, float tile = 4f)
        {
            var b = Get(color, tex);
            Quaternion q = Quaternion.Euler(euler);
            Vector3 h = size * 0.5f;
            Color32 col = Vc(color);
            float sx = size.x / tile, sy = size.y / tile, sz = size.z / tile;
            // face: normal, u-axis, v-axis, half-extents along them, uv extents
            AddFace(b, centre, q, Vector3.right, Vector3.forward, Vector3.up, h.x, h.z, h.y, sz, sy, col);
            AddFace(b, centre, q, Vector3.left, Vector3.back, Vector3.up, h.x, h.z, h.y, sz, sy, col);
            AddFace(b, centre, q, Vector3.up, Vector3.right, Vector3.forward, h.y, h.x, h.z, sx, sz, col);
            AddFace(b, centre, q, Vector3.down, Vector3.right, Vector3.back, h.y, h.x, h.z, sx, sz, col);
            AddFace(b, centre, q, Vector3.forward, Vector3.left, Vector3.up, h.z, h.x, h.y, sx, sy, col);
            AddFace(b, centre, q, Vector3.back, Vector3.right, Vector3.up, h.z, h.x, h.y, sx, sy, col);
            VertexCount += 24;
        }

        // Adds one face of a box. 'n' = face normal (local), 'uA'/'vA' = in-face axes, hn/hu/hv = half sizes.
        // The in-face axes are chosen so that cross(uA, vA) points along -n... verified by the winding check below.
        static void AddFace(Batch b, Vector3 c, Quaternion q, Vector3 n, Vector3 uA, Vector3 vA, float hn, float hu, float hv,
            float uvU, float uvV, Color32 col)
        {
            Vector3 centre = n * hn;
            Vector3 p0 = centre - uA * hu - vA * hv;
            Vector3 p1 = centre - uA * hu + vA * hv;
            Vector3 p2 = centre + uA * hu - vA * hv;
            Vector3 p3 = centre + uA * hu + vA * hv;
            // Ensure the triangle (p0,p1,p2) faces along n: cross(p1-p0, p2-p0) . n must be > 0.
            bool flip = Vector3.Dot(Vector3.Cross(p1 - p0, p2 - p0), n) < 0f;
            int i0 = b.V.Count;
            Vector3 wn = q * n;
            b.V.Add(c + q * p0); b.V.Add(c + q * p1); b.V.Add(c + q * p2); b.V.Add(c + q * p3);
            for (int k = 0; k < 4; k++) { b.N.Add(wn); b.C.Add(col); }
            b.UV.Add(new Vector2(0, 0)); b.UV.Add(new Vector2(0, uvV)); b.UV.Add(new Vector2(uvU, 0)); b.UV.Add(new Vector2(uvU, uvV));
            if (!flip)
            {
                b.T.Add(i0); b.T.Add(i0 + 1); b.T.Add(i0 + 2);
                b.T.Add(i0 + 1); b.T.Add(i0 + 3); b.T.Add(i0 + 2);
            }
            else
            {
                b.T.Add(i0); b.T.Add(i0 + 2); b.T.Add(i0 + 1);
                b.T.Add(i0 + 1); b.T.Add(i0 + 2); b.T.Add(i0 + 3);
            }
        }

        /// <summary>
        /// A flat textured quad facing +X (side = 1) or -X (side = -1), UV 0..1 across the whole quad, so a painted
        /// graffiti texture reads left-to-right when seen from the outside. 'size' = (length along Z, height along Y).
        /// Does nothing when the custom vertex shader is missing (flat-colour fallback).
        /// </summary>
        public void Decal(Vector3 centre, Vector2 size, int side, Color tint, TexId tex)
        {
            if (!MaterialLibrary.HasVertexShader || tex == TexId.None) return;
            var b = Get(tint, tex);
            float hz = size.x * 0.5f, hy = size.y * 0.5f;
            float zl = side > 0 ? -hz : hz, zr = side > 0 ? hz : -hz; // left / right edge as seen by the viewer
            Vector3 n = new Vector3(side, 0f, 0f);
            int i0 = b.V.Count;
            b.V.Add(centre + new Vector3(0, -hy, zl)); // bottom-left
            b.V.Add(centre + new Vector3(0, hy, zl));  // top-left
            b.V.Add(centre + new Vector3(0, hy, zr));  // top-right
            b.V.Add(centre + new Vector3(0, -hy, zr)); // bottom-right
            Color32 col = tint;
            for (int k = 0; k < 4; k++) { b.N.Add(n); b.C.Add(col); }
            b.UV.Add(new Vector2(0, 0)); b.UV.Add(new Vector2(0, 1)); b.UV.Add(new Vector2(1, 1)); b.UV.Add(new Vector2(1, 0));
            b.T.Add(i0); b.T.Add(i0 + 1); b.T.Add(i0 + 2);
            b.T.Add(i0); b.T.Add(i0 + 2); b.T.Add(i0 + 3);
            VertexCount += 4;
        }

        /// <summary>Cylinder / sphere / wedge. 'size' is the full size (cylinder: x,z = diameter, y = height).</summary>
        public void Prim(PrimKind kind, Vector3 centre, Vector3 size, Color color, Vector3 euler = default(Vector3), TexId tex = TexId.None)
        {
            if (kind == PrimKind.Box) { Box(centre, size, color, euler, tex); return; }
            var d = PrimMesh.Get(kind);
            var b = Get(color, tex);
            Quaternion q = Quaternion.Euler(euler);
            Color32 col = Vc(color);
            int i0 = b.V.Count;
            for (int i = 0; i < d.V.Length; i++)
            {
                Vector3 p = Vector3.Scale(d.V[i], size);
                b.V.Add(centre + q * p);
                // non-uniform scale: use inverse-scale for normals
                Vector3 nn = new Vector3(d.N[i].x / Mathf.Max(0.0001f, size.x), d.N[i].y / Mathf.Max(0.0001f, size.y), d.N[i].z / Mathf.Max(0.0001f, size.z));
                b.N.Add((q * nn).normalized);
                b.UV.Add(d.UV[i]);
                b.C.Add(col);
            }
            for (int i = 0; i < d.T.Length; i++) b.T.Add(i0 + d.T[i]);
            VertexCount += d.V.Length;
        }

        public void Cyl(Vector3 centre, float diameter, float height, Color color, Vector3 euler = default(Vector3))
        { Prim(PrimKind.Cylinder, centre, new Vector3(diameter, height, diameter), color, euler); }

        public void Sph(Vector3 centre, Vector3 size, Color color)
        { Prim(PrimKind.Sphere, centre, size, color); }

        public void Sph(Vector3 centre, float diameter, Color color)
        { Prim(PrimKind.Sphere, centre, Vector3.one * diameter, color); }

        /// <summary>A wheel: cylinder lying across X.</summary>
        public void Wheel(Vector3 centre, float radius, float width, Color color)
        { Prim(PrimKind.Cylinder, centre, new Vector3(radius * 2f, width, radius * 2f), color, new Vector3(0, 0, 90)); }

        /// <summary>A sagging string of beads (marigold garlands, bunting strings).</summary>
        public void Garland(Vector3 a, Vector3 b, float sag, int beads, float size, Color c1, Color c2)
        {
            for (int i = 0; i <= beads; i++)
            {
                float t = i / (float)beads;
                Vector3 p = Vector3.Lerp(a, b, t);
                p.y -= Mathf.Sin(t * Mathf.PI) * sag;
                Sph(p, size, (i % 2 == 0) ? c1 : c2);
            }
        }

        /// <summary>Turns everything collected into real GameObjects (one MeshRenderer per material) under 'parent'. No colliders.</summary>
        public List<GameObject> Build(Transform parent, string namePrefix = "Mesh")
        {
            var result = new List<GameObject>();
            int idx = 0;
            foreach (var kv in batches)
            {
                var b = kv.Value;
                if (b.V.Count == 0) continue;
                var mesh = new Mesh();
                mesh.name = namePrefix + "_" + idx;
                if (b.V.Count > 65000) mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
                mesh.SetVertices(b.V);
                mesh.SetNormals(b.N);
                mesh.SetUVs(0, b.UV);
                mesh.SetColors(b.C);
                mesh.SetTriangles(b.T, 0);
                mesh.RecalculateBounds();
                var go = new GameObject(namePrefix + "_" + idx++);
                go.transform.SetParent(parent, false);
                go.AddComponent<MeshFilter>().sharedMesh = mesh;
                var r = go.AddComponent<MeshRenderer>();
                r.sharedMaterial = b.Mat;
                r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
                r.receiveShadows = false;
                result.Add(go);
            }
            batches.Clear();
            VertexCount = 0;
            return result;
        }
    }
}
