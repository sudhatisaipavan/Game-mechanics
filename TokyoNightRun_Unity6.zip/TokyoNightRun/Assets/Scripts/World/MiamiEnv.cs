using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>Miami Beach: pastel art-deco hotels, a beach with umbrellas and lifeguard tower, and a sunset boulevard with a Ferris wheel.</summary>
    public static class MiamiEnv
    {
        static Color C(int rgb) { return GameConfig.Hex(rgb); }
        static Color G(int rgb, float a = 0f) { return ThemedEnvironment.Glow(rgb, a); }
        static readonly int[] Pastel = { 0xFFB3CF, 0x9FE8DC, 0xFFE29A, 0xFFC2A1, 0xC9B6FF, 0xA6E3FF };

        // ---------------------------------------------------------------- props
        public static void Palm(MeshBatcher b, Vector3 p, float h, float lean, System.Random rng)
        {
            Color trunk = C(0x9C7A55);
            int segs = 5; Vector3 top = p;
            for (int i = 0; i < segs; i++)
            {
                float k = (i + 0.5f) / segs;
                Vector3 c = p + new Vector3(lean * k * k * h * 0.4f, h * k, 0);
                b.Cyl(c, Mathf.Lerp(0.42f, 0.28f, k), h / segs + 0.05f, i % 2 == 0 ? trunk : trunk * 0.9f, new Vector3(0, 0, -lean * k * 12f));
                top = c + new Vector3(0, h / segs * 0.5f, 0);
            }
            for (int i = 0; i < 7; i++)
            {
                float yaw = i * 360f / 7f;
                float a = yaw * Mathf.Deg2Rad;
                Vector3 dir = new Vector3(Mathf.Sin(a), 0f, Mathf.Cos(a));
                b.Box(top + dir * 1.0f + new Vector3(0, -0.15f, 0), new Vector3(0.55f, 0.07f, 2.3f), i % 2 == 0 ? C(0x2E9E4F) : C(0x3DBB63), new Vector3(28, yaw, 0));
            }
            for (int i = 0; i < 3; i++) b.Sph(top + new Vector3((i - 1) * 0.22f, -0.3f, 0.1f), 0.28f, C(0x6D4C41)); // coconuts
        }

        static void Umbrella(MeshBatcher b, Vector3 p, Color col)
        {
            b.Cyl(p + new Vector3(0, 1.1f, 0), 0.06f, 2.2f, C(0xEFEBE9));
            b.Prim(PrimKind.Cylinder, p + new Vector3(0, 2.25f, 0), new Vector3(2.2f, 0.12f, 2.2f), col);
            b.Prim(PrimKind.Cylinder, p + new Vector3(0, 2.35f, 0), new Vector3(1.0f, 0.12f, 1.0f), Color.white);
            b.Sph(p + new Vector3(0, 2.42f, 0), 0.14f, col);
        }

        static void Flamingo(MeshBatcher b, Vector3 p, float k)
        {
            Color pink = G(0xFF6FA8, 0.7f);
            b.Cyl(p + new Vector3(0, 0.6f * k, 0), 0.07f * k, 1.2f * k, C(0xFF8FB8));
            b.Sph(p + new Vector3(0, 1.45f * k, 0), new Vector3(0.7f, 0.6f, 0.9f) * k, pink);
            b.Box(p + new Vector3(0, 1.95f * k, -0.2f * k), new Vector3(0.12f, 0.9f, 0.12f) * k, pink, new Vector3(-20, 0, 0));
            b.Sph(p + new Vector3(0, 2.4f * k, -0.38f * k), 0.28f * k, pink);
            b.Box(p + new Vector3(0, 2.38f * k, -0.62f * k), new Vector3(0.1f, 0.1f, 0.3f) * k, C(0x212121));
        }

        static void Deco(MeshBatcher b, int s, float x, float cz, float w, float d, float h, int rgb, System.Random rng)
        {
            Color wall = C(rgb);
            b.Box(new Vector3(s * x, h * 0.5f, cz), new Vector3(w, h, d), wall, default(Vector3), TexId.Facade, 4f);
            b.Box(new Vector3(s * x, h + 0.3f, cz), new Vector3(w + 0.5f, 0.6f, d + 0.5f), Color.white);
            b.Box(new Vector3(s * x, h + 1.2f, cz), new Vector3(w * 0.6f, 1.2f, d * 0.6f), wall * 1.05f);
            b.Cyl(new Vector3(s * x, h + 2.3f, cz), 0.2f, 1.6f, C(0xEFEFEF));
            float faceX = s * x - s * (w * 0.5f);
            int bands = Mathf.Max(2, (int)(h / 4f));
            for (int i = 1; i <= bands; i++) // eyebrow ledges with neon edge
            {
                float y = i * h / (bands + 1);
                b.Box(new Vector3(faceX - s * 0.25f, y, cz), new Vector3(0.6f, 0.1f, d - 0.5f), Color.white);
                b.Box(new Vector3(faceX - s * 0.56f, y, cz), new Vector3(0.05f, 0.07f, d - 0.5f), G(i % 2 == 0 ? 0x00E5FF : 0xFF4F9A));
            }
            b.Box(new Vector3(faceX - s * 0.04f, 1.6f, cz), new Vector3(0.1f, 2.6f, d - 1f), C(0x37474F));
            b.Box(new Vector3(faceX - s * 0.12f, 1.6f, cz), new Vector3(0.06f, 2.0f, d - 1.6f), G(0xFFF3C4, 0.15f));
            b.Box(new Vector3(faceX - s * 0.3f, h * 0.8f, cz), new Vector3(0.3f, 1.8f, 1.1f), G(i0(rgb), 0.05f)); // vertical hotel sign
        }
        static int i0(int rgb) { return (rgb & 0xFF) > 0xB0 ? 0xFF4F9A : 0x00E5FF; }

        static void FerrisWheel(MeshBatcher b, float x, float cy, float cz, float r)
        {
            int n = 20;
            for (int i = 0; i < n; i++)
            {
                float a = i * 360f / n, ar = a * Mathf.Deg2Rad;
                float seg = 2f * Mathf.PI * r / n * 1.05f;
                b.Box(new Vector3(x, cy + Mathf.Sin(ar) * r, cz + Mathf.Cos(ar) * r), new Vector3(0.25f, 0.25f, seg), G(0xFFFFFF, 0.2f), new Vector3(-(a + 90f), 0, 0));
                if (i % 2 == 0)
                {
                    b.Box(new Vector3(x, cy + Mathf.Sin(ar) * r * 0.5f, cz + Mathf.Cos(ar) * r * 0.5f), new Vector3(0.12f, 0.12f, r), C(0xCFD8DC), new Vector3(-a, 0, 0));
                    b.Sph(new Vector3(x, cy + Mathf.Sin(ar) * (r - 0.8f), cz + Mathf.Cos(ar) * (r - 0.8f)), 1.3f, i % 4 == 0 ? G(0xFF4F9A, 0.4f) : G(0x00E5FF, 0.4f));
                }
            }
            b.Box(new Vector3(x, cy, cz), new Vector3(0.6f, 0.6f, 0.6f), C(0x607D8B));
            b.Box(new Vector3(x, cy * 0.5f, cz - r * 0.4f), new Vector3(0.4f, cy, 0.4f), C(0xB0BEC5), new Vector3(-12, 0, 0));
            b.Box(new Vector3(x, cy * 0.5f, cz + r * 0.4f), new Vector3(0.4f, cy, 0.4f), C(0xB0BEC5), new Vector3(12, 0, 0));
        }

        // ---------------------------------------------------------------- overhead
        public static void Overhead(MeshBatcher b, float z, int m, System.Random rng)
        {
            b.Garland(new Vector3(-4.35f, 6.3f, z), new Vector3(4.35f, 6.3f, z), 1.0f, 20, 0.17f, G(0xFFE29A, 0.05f), G(0xFF9AC4, 0.05f));
            for (int s = -1; s <= 1; s += 2)
            {
                b.Box(new Vector3(s * 4.2f, 6.9f, z), new Vector3(0.12f, 0.1f, 0.12f), C(0x6D4C41));
                for (int i = 0; i < 5; i++) b.Box(new Vector3(s * 4.2f + Mathf.Sin(i * 1.3f) * 0.6f, 6.95f, z + Mathf.Cos(i * 1.3f) * 0.6f), new Vector3(0.4f, 0.06f, 1.4f), C(0x2E9E4F), new Vector3(20, i * 72f, 0));
            }
        }

        // ---------------------------------------------------------------- variants
        public static void Build(MeshBatcher b, int variant, float L, System.Random rng)
        {
            for (int s = -1; s <= 1; s += 2)
            {
                if (variant == 0) Hotels(b, s, L, rng);
                else if (variant == 1) Beach(b, s, L, rng);
                else Boulevard(b, s, L, rng);
                if (variant != 1) ThemedEnvironment.Skyline(b, s, L, rng, Pastel, TexId.Facade, 4f, 18f, 34f);
            }
            if (variant == 2) FerrisWheel(b, -26f, 15f, 14f, 11f);
        }

        static void Hotels(MeshBatcher b, int s, float L, System.Random rng)
        {
            float z = 0f; int guard = 0;
            while (z < L - 2f && guard++ < 4)
            {
                float d = Mathf.Min(L - z, 8f + (float)rng.NextDouble() * 5f);
                Deco(b, s, ThemedEnvironment.PlatformOuterX + 3.8f, z + d * 0.5f, 6.5f, d - 0.2f, 9f + (float)rng.NextDouble() * 9f, Pastel[rng.Next(Pastel.Length)], rng);
                z += d;
            }
            for (int i = 0; i < 3; i++) Palm(b, new Vector3(s * 8.5f, 1.0f, 4f + i * 10f), 5.2f + (float)rng.NextDouble() * 1.5f, s * 0.6f, rng);
            Flamingo(b, new Vector3(s * 6.6f, 1.0f, 15f), 1f);
            // surfboard rack and bench
            for (int i = 0; i < 5; i++) b.Box(new Vector3(s * 5.6f, 1.0f + 1.0f, 22f + i * 0.4f), new Vector3(0.14f, 2.0f, 0.34f), Theme.Pal(i), new Vector3(0, 0, s * 8f));
            b.Box(new Vector3(s * 5.6f, 1.0f + 0.2f, 23f), new Vector3(0.5f, 0.1f, 2.6f), C(0x8D5A2B), default(Vector3), TexId.Wood, 1f);
        }

        static void Beach(MeshBatcher b, int s, float L, System.Random rng)
        {
            // sand dunes, ocean and sky-blue horizon strip
            b.Box(new Vector3(s * 17f, 0.45f, L * 0.5f), new Vector3(15f, 0.9f, L), C(0xF2DFAE), default(Vector3), TexId.Sand, 3f);
            b.Box(new Vector3(s * 31f, 0.1f, L * 0.5f), new Vector3(16f, 0.2f, L), C(0x14C7D8));
            b.Box(new Vector3(s * 25f, 0.15f, L * 0.5f), new Vector3(2.0f, 0.12f, L), Color.white, default(Vector3), TexId.None);
            for (int i = 0; i < 6; i++) b.Box(new Vector3(s * (26f + (float)rng.NextDouble() * 8f), 0.22f, 2f + i * 5f), new Vector3(2.6f, 0.06f, 0.5f), G(0xFFFFFF, 0.5f));
            for (int i = 0; i < 3; i++)
            {
                float z = 4f + i * 10f;
                Umbrella(b, new Vector3(s * (13.5f + (i % 2) * 2f), 0.9f, z), Theme.Pal(i * 2 + (s > 0 ? 1 : 0)));
                b.Box(new Vector3(s * (13.5f + (i % 2) * 2f), 1.05f, z + 1.1f), new Vector3(1.6f, 0.1f, 0.5f), Theme.Pal(i + 3), new Vector3(0, 12, 0));
            }
            // lifeguard tower
            float lx = s * 12.0f;
            for (int k = 0; k < 4; k++) b.Box(new Vector3(lx + (k % 2 - 0.5f) * 1.4f, 1.0f + 1.1f, 22f + (k / 2 - 0.5f) * 1.4f), new Vector3(0.12f, 2.2f, 0.12f), C(0xFFFFFF));
            b.Box(new Vector3(lx, 1.0f + 2.3f, 22f), new Vector3(1.9f, 0.14f, 1.9f), C(0xFFFFFF));
            b.Box(new Vector3(lx, 1.0f + 3.1f, 22f), new Vector3(1.5f, 1.4f, 1.5f), C(0xFF5252));
            b.Prim(PrimKind.Wedge, new Vector3(lx, 1.0f + 4.15f, 22f), new Vector3(2.2f, 0.9f, 2.2f), C(0xFFFFFF));
            b.Box(new Vector3(lx - s * 0.78f, 1.0f + 3.2f, 22f), new Vector3(0.05f, 0.6f, 1.0f), G(0x00E5FF, 0.3f));
            // volleyball net
            for (int e = -1; e <= 1; e += 2) b.Box(new Vector3(s * 14.5f, 2.2f, 12f + e * 2f), new Vector3(0.1f, 2.4f, 0.1f), C(0xEFEBE9));
            b.Box(new Vector3(s * 14.5f, 2.9f, 12f), new Vector3(0.05f, 0.9f, 4f), Color.white, default(Vector3), TexId.Window, 1f);
            for (int i = 0; i < 3; i++) Palm(b, new Vector3(s * (9.0f + i * 0.4f), 1.0f, 5f + i * 10f), 5.8f, s * 0.8f, rng);
            // low beach-bar with thatched roof
            b.Box(new Vector3(s * 8.0f, 1.0f + 0.7f, 26f), new Vector3(2.0f, 1.4f, 3.6f), C(0xE0B887), default(Vector3), TexId.Wood, 1.5f);
            b.Prim(PrimKind.Wedge, new Vector3(s * 8.0f, 1.0f + 2.1f, 26f), new Vector3(3.2f, 1.1f, 4.4f), C(0xC9A66B));
            b.Garland(new Vector3(s * 7.0f, 1.0f + 1.8f, 24.2f), new Vector3(s * 7.0f, 1.0f + 1.8f, 27.8f), 0.3f, 10, 0.12f, G(0xFFE29A), G(0xFF9AC4));
        }

        static void Boulevard(MeshBatcher b, int s, float L, System.Random rng)
        {
            float z = 0f; int guard = 0;
            while (z < L - 2f && guard++ < 3)
            {
                float d = Mathf.Min(L - z, 9f + (float)rng.NextDouble() * 4f);
                Deco(b, s, ThemedEnvironment.PlatformOuterX + 4.0f, z + d * 0.5f, 6.5f, d - 0.2f, 12f + (float)rng.NextDouble() * 10f, Pastel[(rng.Next(Pastel.Length) + (s > 0 ? 2 : 0)) % Pastel.Length], rng);
                z += d;
            }
            for (int i = 0; i < 4; i++) Palm(b, new Vector3(s * (8.2f + (i % 2) * 0.8f), 1.0f, 3f + i * 7.5f), 7f + (float)rng.NextDouble() * 2f, s * 0.7f, rng);
            Flamingo(b, new Vector3(s * 6.4f, 1.0f, 9f), 1.1f); Flamingo(b, new Vector3(s * 6.9f, 1.0f, 10.2f), 0.8f);
            // retro neon sign (the drive-in)
            b.Box(new Vector3(s * 7.6f, 3.0f, 20f), new Vector3(0.2f, 4f, 0.2f), C(0xECEFF1));
            b.Box(new Vector3(s * 7.4f, 5.2f, 20f), new Vector3(0.3f, 1.6f, 3.4f), C(0x1A1A2E));
            b.Box(new Vector3(s * 7.22f, 5.2f, 20f), new Vector3(0.06f, 1.3f, 3.1f), G(0xFF4F9A, 0.05f));
            b.Decal(new Vector3(s * 7.19f, 5.2f, 20f), new Vector2(3.0f, 1.25f), -s, new Color(1, 1, 1, 0.25f), TexId.Graffiti0);
            // sunset-striped retro sun on the back wall
            for (int i = 0; i < 6; i++)
                b.Box(new Vector3(s * (ThemedEnvironment.PlatformOuterX - 0.05f), 2.0f + i * 0.4f, 15f), new Vector3(0.05f, 0.28f - i * 0.025f, 5.6f - i * 0.5f), G(i % 2 == 0 ? 0xFF7A45 : 0xFFB300, 0.1f));
        }
    }
}
