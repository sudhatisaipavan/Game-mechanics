using UnityEngine;

namespace TokyoNightRun
{
    public enum PrimKind { Box, Cylinder, Sphere, Wedge }

    /// <summary>
    /// Unit shapes generated in code (so we never depend on Unity's built-in primitive meshes being readable on Android).
    /// Cylinder: radius 0.5, height 1, axis Y. Sphere: radius 0.5. Wedge: triangular prism, base 1 wide at y=-0.5,
    /// apex at y=+0.5, 1 long along Z. Winding follows Unity's convention (front faces are clockwise).
    /// </summary>
    public static class PrimMesh
    {
        public class Data { public Vector3[] V; public Vector3[] N; public Vector2[] UV; public int[] T; }

        static Data cyl, sph, wedge;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics() { cyl = sph = wedge = null; }

        public static Data Get(PrimKind k)
        {
            switch (k)
            {
                case PrimKind.Cylinder: return cyl ?? (cyl = BuildCylinder(16));
                case PrimKind.Sphere: return sph ?? (sph = BuildSphere(14, 9));
                case PrimKind.Wedge: return wedge ?? (wedge = BuildWedge());
                default: return null;
            }
        }

        static Data BuildCylinder(int segs)
        {
            var v = new System.Collections.Generic.List<Vector3>();
            var n = new System.Collections.Generic.List<Vector3>();
            var uv = new System.Collections.Generic.List<Vector2>();
            var t = new System.Collections.Generic.List<int>();
            for (int j = 0; j <= segs; j++)
            {
                float a = j / (float)segs * Mathf.PI * 2f;
                float c = Mathf.Cos(a), s = Mathf.Sin(a);
                v.Add(new Vector3(c * 0.5f, -0.5f, s * 0.5f)); n.Add(new Vector3(c, 0, s)); uv.Add(new Vector2(j / (float)segs, 0));
                v.Add(new Vector3(c * 0.5f, 0.5f, s * 0.5f)); n.Add(new Vector3(c, 0, s)); uv.Add(new Vector2(j / (float)segs, 1));
            }
            for (int j = 0; j < segs; j++)
            {
                int p = j * 2, q = p + 1, r = p + 2, s = p + 3; // p=bottom j, q=top j, r=bottom j+1, s=top j+1
                t.Add(p); t.Add(q); t.Add(r);
                t.Add(q); t.Add(s); t.Add(r);
            }
            for (int cap = 0; cap < 2; cap++)
            {
                float y = cap == 0 ? -0.5f : 0.5f;
                int centre = v.Count;
                v.Add(new Vector3(0, y, 0)); n.Add(new Vector3(0, cap == 0 ? -1 : 1, 0)); uv.Add(new Vector2(0.5f, 0.5f));
                int first = v.Count;
                for (int j = 0; j <= segs; j++)
                {
                    float a = j / (float)segs * Mathf.PI * 2f;
                    v.Add(new Vector3(Mathf.Cos(a) * 0.5f, y, Mathf.Sin(a) * 0.5f));
                    n.Add(new Vector3(0, cap == 0 ? -1 : 1, 0));
                    uv.Add(new Vector2(Mathf.Cos(a) * 0.5f + 0.5f, Mathf.Sin(a) * 0.5f + 0.5f));
                }
                for (int j = 0; j < segs; j++)
                {
                    if (cap == 0) { t.Add(centre); t.Add(first + j); t.Add(first + j + 1); }
                    else { t.Add(centre); t.Add(first + j + 1); t.Add(first + j); }
                }
            }
            return new Data { V = v.ToArray(), N = n.ToArray(), UV = uv.ToArray(), T = t.ToArray() };
        }

        static Data BuildSphere(int lon, int lat)
        {
            var v = new System.Collections.Generic.List<Vector3>();
            var n = new System.Collections.Generic.List<Vector3>();
            var uv = new System.Collections.Generic.List<Vector2>();
            var t = new System.Collections.Generic.List<int>();
            for (int i = 0; i <= lat; i++)
            {
                float phi = Mathf.Lerp(-Mathf.PI * 0.5f, Mathf.PI * 0.5f, i / (float)lat);
                float y = Mathf.Sin(phi), r = Mathf.Cos(phi);
                for (int j = 0; j <= lon; j++)
                {
                    float a = j / (float)lon * Mathf.PI * 2f;
                    var d = new Vector3(Mathf.Cos(a) * r, y, Mathf.Sin(a) * r);
                    v.Add(d * 0.5f); n.Add(d); uv.Add(new Vector2(j / (float)lon, i / (float)lat));
                }
            }
            int stride = lon + 1;
            for (int i = 0; i < lat; i++)
                for (int j = 0; j < lon; j++)
                {
                    int p = i * stride + j, q = p + stride, r = p + 1, s = q + 1;
                    t.Add(p); t.Add(q); t.Add(r);
                    t.Add(q); t.Add(s); t.Add(r);
                }
            return new Data { V = v.ToArray(), N = n.ToArray(), UV = uv.ToArray(), T = t.ToArray() };
        }

        static Data BuildWedge()
        {
            var v = new System.Collections.Generic.List<Vector3>();
            var n = new System.Collections.Generic.List<Vector3>();
            var uv = new System.Collections.Generic.List<Vector2>();
            var t = new System.Collections.Generic.List<int>();
            Vector3 bl = new Vector3(-0.5f, -0.5f, 0), br = new Vector3(0.5f, -0.5f, 0), ap = new Vector3(0, 0.5f, 0);
            Vector3 zb = new Vector3(0, 0, -0.5f), zf = new Vector3(0, 0, 0.5f);
            // quad helper: corners given so that cross(b-a, c-a) points outward
            System.Action<Vector3, Vector3, Vector3, Vector3, Vector3> quad = (a, b, c, d, nn) =>
            {
                int i0 = v.Count;
                v.Add(a); v.Add(b); v.Add(c); v.Add(d);
                for (int k = 0; k < 4; k++) n.Add(nn);
                uv.Add(new Vector2(0, 0)); uv.Add(new Vector2(0, 1)); uv.Add(new Vector2(1, 0)); uv.Add(new Vector2(1, 1));
                t.Add(i0); t.Add(i0 + 1); t.Add(i0 + 2);
                t.Add(i0 + 1); t.Add(i0 + 3); t.Add(i0 + 2);
            };
            // bottom (normal -y): a=bl+zb, b=bl+zf, c=br+zb  -> cross((0,0,1),(1,0,0)) = (0*0-1*0, 1*1-0*0, 0)=(0,1,0) wrong side, so swap
            quad(bl + zb, br + zb, bl + zf, br + zf, Vector3.down);
            // left slope (normal up-left)
            Vector3 nl = new Vector3(-1f, 1f, 0).normalized, nr = new Vector3(1f, 1f, 0).normalized;
            quad(bl + zb, bl + zf, ap + zb, ap + zf, nl);
            quad(br + zb, ap + zb, br + zf, ap + zf, nr);
            // end triangles
            int e = v.Count;
            v.Add(bl + zb); v.Add(ap + zb); v.Add(br + zb); for (int k = 0; k < 3; k++) n.Add(Vector3.back);
            uv.Add(new Vector2(0, 0)); uv.Add(new Vector2(0.5f, 1)); uv.Add(new Vector2(1, 0));
            t.Add(e); t.Add(e + 1); t.Add(e + 2);
            int f = v.Count;
            v.Add(bl + zf); v.Add(br + zf); v.Add(ap + zf); for (int k = 0; k < 3; k++) n.Add(Vector3.forward);
            uv.Add(new Vector2(0, 0)); uv.Add(new Vector2(1, 0)); uv.Add(new Vector2(0.5f, 1));
            t.Add(f); t.Add(f + 1); t.Add(f + 2);
            return new Data { V = v.ToArray(), N = n.ToArray(), UV = uv.ToArray(), T = t.ToArray() };
        }
    }
}
