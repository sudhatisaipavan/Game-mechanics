using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Builds one 30 m railway segment (batched into a few meshes). Local z runs 0..30, x = 0 is the centre track.
    /// Three tracks (rails, sleepers, ballast), raised platforms on both sides, overhead masts, wires and Holi bunting,
    /// station canopies, stalls, Indian urban buildings and skyline behind.
    /// Variant 0 = main station with canopies, 1 = bazaar junction with stalls and parked trains, 2 = temple / festival ground.
    /// Everything here is decoration only: there are NO colliders, so nothing can cause a game over.
    /// </summary>
    public static class ProceduralEnvironment
    {
        static readonly int[] Pastels = { 0xF8BBD0, 0xFFF59D, 0x80DEEA, 0xFFCC80, 0xCE93D8, 0xA5D6A7, 0xFFAB91, 0xFFE0B2 };
        static readonly int[] Stronger = { 0xE57399, 0xE9C46A, 0x4DB6C6, 0xF29E4C, 0x9C6ADE, 0x6BB36B, 0xE8795A };

        static Color C(int rgb) { return GameConfig.Hex(rgb); }
        static Color Holi(System.Random r) { return GameConfig.HoliColors[r.Next(GameConfig.HoliColors.Length)]; }
        static Color HoliAt(int i) { return GameConfig.HoliColors[((i % 6) + 6) % 6]; }
        static readonly Color Marigold = GameConfig.Hex(0xFF9800);
        static readonly Color Marigold2 = GameConfig.Hex(0xFFC107);
        static readonly Color Steel = new Color(0.45f, 0.47f, 0.5f, 1f);
        static readonly Color Dark = new Color(0.16f, 0.16f, 0.18f, 1f);
        static readonly Color Lamp = new Color(1f, 0.93f, 0.7f, 0f);

        public const float PlatformInnerX = 3.9f;   // platform edge nearest the tracks
        public const float PlatformOuterX = 9.4f;
        public const float PlatformTop = 1.0f;

        public static GameObject BuildSegment(int variant, System.Random rng)
        {
            if (!Theme.IsHoli) return ThemedEnvironment.BuildSegment(variant, rng);
            var root = new GameObject("Segment_Variant" + variant);
            var b = new MeshBatcher();
            float L = GameConfig.SegmentLength;

            Tracks(b, L, variant, rng);
            Platforms(b, L, variant, rng);
            Overhead(b, L, rng);
            Splashes(b, L, rng);

            for (int s = -1; s <= 1; s += 2)
            {
                if (variant == 0) { Canopy(b, s, L, rng); Benches(b, s, rng); Signboards(b, s, L, rng); Buildings(b, s, L, rng, 12, 22); }
                else if (variant == 1)
                {
                    Stall(b, s, 6f, rng); Stall(b, s, 22f, rng); Chai(b, s, 14f, rng);
                    ParkedTrain(b, s, L, rng);
                    Buildings(b, s, L, rng, 8, 14);
                }
                else
                {
                    Temple(b, s, 15f, rng);
                    for (int i = 0; i < 3; i++) Rangoli(b, new Vector3(s * 6.6f, PlatformTop + 0.02f, 5f + i * 10f), 1.5f, rng);
                    Buildings(b, s, L, rng, 6, 10);
                }
                Skyline(b, s, L, rng);
            }

            if (variant == 0) Footbridge(b, 22f, rng);
            if (variant == 2) Torana(b, 22f);
            if (variant == 1) BannerSpan(b, 20f, rng);

            b.Build(root.transform, "Env");
            return root;
        }

        // ---------------------------------------------------------------- tracks
        static void Tracks(MeshBatcher b, float L, int variant, System.Random rng)
        {
            // ballast bed (top at y=0) and a darker trench shoulder
            b.Box(new Vector3(0, -0.15f, L * 0.5f), new Vector3(7.8f, 0.3f, L), C(0x8C857C), default(Vector3), TexId.Ballast, 2.5f);
            for (int s = -1; s <= 1; s += 2)
                b.Box(new Vector3(s * 3.95f, -0.45f, L * 0.5f), new Vector3(0.5f, 0.9f, L), C(0x6F6A64), default(Vector3), TexId.Concrete, 2.5f); // trench wall
            for (int lane = -1; lane <= 1; lane++)
            {
                float cx = lane * GameConfig.LaneWidth;
                for (float z = 0.4f; z < L; z += 0.75f) // sleepers
                    b.Box(new Vector3(cx, 0.04f, z), new Vector3(1.9f, 0.09f, 0.26f), C(0x7A6350), default(Vector3), TexId.Wood, 1.5f);
                for (int r = -1; r <= 1; r += 2)
                {
                    float rx = cx + r * GameConfig.RailHalfGauge;
                    b.Box(new Vector3(rx, 0.15f, L * 0.5f), new Vector3(0.1f, 0.13f, L), C(0x8E9298), default(Vector3), TexId.Metal, 3f);
                    b.Box(new Vector3(rx, 0.225f, L * 0.5f), new Vector3(0.06f, 0.03f, L), C(0xC9CDD2)); // polished rail head
                }
            }
            // a few colourful gulal-stained patches on the ballast
            for (int i = 0; i < 5; i++)
            {
                float r = 0.6f + (float)rng.NextDouble() * 1.2f;
                b.Prim(PrimKind.Cylinder, new Vector3(Mathf.Lerp(-3.4f, 3.4f, (float)rng.NextDouble()), 0.012f + i * 0.001f, (float)rng.NextDouble() * L),
                    new Vector3(r * 2f, 0.004f, r * 2f), Holi(rng) * 0.9f);
            }
        }

        // ---------------------------------------------------------------- platforms
        static void Platforms(MeshBatcher b, float L, int variant, System.Random rng)
        {
            float w = PlatformOuterX - PlatformInnerX;
            for (int s = -1; s <= 1; s += 2)
            {
                float cx = s * (PlatformInnerX + w * 0.5f);
                b.Box(new Vector3(cx, PlatformTop * 0.5f - 0.1f, L * 0.5f), new Vector3(w, PlatformTop + 0.2f, L), C(0xBDB6AE), default(Vector3), TexId.Concrete, 3f);
                b.Box(new Vector3(cx, PlatformTop + 0.01f, L * 0.5f), new Vector3(w - 0.1f, 0.04f, L), C(variant == 2 ? 0xE9D7C0 : 0xD8D2CA), default(Vector3), TexId.Tile, 3.2f);
                // vertical face towards the tracks: concrete with a Holi mural band
                float fx = s * (PlatformInnerX + 0.03f);
                b.Box(new Vector3(fx, 0.55f, L * 0.5f), new Vector3(0.08f, 0.9f, L), C(0xA39D95), default(Vector3), TexId.Concrete, 3f);
                for (int i = 0; i < 10; i++)
                    b.Box(new Vector3(fx - s * 0.05f, 0.62f, 1.5f + i * 3f), new Vector3(0.04f, 0.4f, 2.9f), HoliAt(i + (variant * 2)));
                // yellow safety strip with dashes
                b.Box(new Vector3(s * (PlatformInnerX + 0.45f), PlatformTop + 0.04f, L * 0.5f), new Vector3(0.14f, 0.02f, L), C(0xFFD400));
                for (int i = 0; i < 20; i++)
                    b.Box(new Vector3(s * (PlatformInnerX + 0.7f), PlatformTop + 0.035f, 0.8f + i * 1.5f), new Vector3(0.3f, 0.02f, 0.5f), C(0xFFD400));
                // back wall / fence with painted Holi handprints
                b.Box(new Vector3(s * (PlatformOuterX + 0.15f), 2.2f, L * 0.5f), new Vector3(0.3f, 3.4f, L), C(Pastels[(variant + (s > 0 ? 1 : 0)) % Pastels.Length]), default(Vector3), TexId.Brick, 3f);
                b.Box(new Vector3(s * (PlatformOuterX + 0.15f), 4.0f, L * 0.5f), new Vector3(0.4f, 0.2f, L), HoliAt(variant + 2 * (s + 1)));
                // large graffiti murals on the back wall
                for (int gz = 0; gz < 2; gz++)
                    b.Decal(new Vector3(s * (PlatformOuterX - 0.012f), 2.35f, 7.5f + gz * 15f), new Vector2(6.4f, 3.2f), -s, Color.white,
                        (TexId)((int)TexId.Graffiti0 + rng.Next(4)));
                for (int i = 0; i < 5; i++)
                {
                    Color pc = Holi(rng);
                    float z = 3f + i * 5.5f + (float)rng.NextDouble() * 2f, y = 1.8f + (float)rng.NextDouble() * 1.4f;
                    float x = s * (PlatformOuterX - 0.02f);
                    b.Prim(PrimKind.Sphere, new Vector3(x, y, z), new Vector3(0.03f, 0.5f, 0.45f), pc);
                    for (int f = 0; f < 4; f++) b.Prim(PrimKind.Sphere, new Vector3(x, y + 0.34f, z - 0.17f + f * 0.11f), new Vector3(0.03f, 0.28f, 0.1f), pc);
                }
            }
        }

        static void Splashes(MeshBatcher b, float L, System.Random rng)
        {
            for (int s = -1; s <= 1; s += 2)
                for (int i = 0; i < 4; i++)
                {
                    float r = 0.5f + (float)rng.NextDouble() * 1.0f;
                    b.Prim(PrimKind.Cylinder, new Vector3(s * Mathf.Lerp(4.6f, 8.8f, (float)rng.NextDouble()), PlatformTop + 0.03f + i * 0.001f, (float)rng.NextDouble() * L),
                        new Vector3(r * 2f, 0.004f, r * 2f), Holi(rng) * 0.95f);
                }
        }

        // ---------------------------------------------------------------- overhead line, masts, bunting
        static void Overhead(MeshBatcher b, float L, System.Random rng)
        {
            // contact wires above each track
            for (int lane = -1; lane <= 1; lane++)
            {
                b.Box(new Vector3(lane * GameConfig.LaneWidth, 5.4f, L * 0.5f), new Vector3(0.03f, 0.03f, L), Dark);
                b.Box(new Vector3(lane * GameConfig.LaneWidth, 5.75f, L * 0.5f), new Vector3(0.025f, 0.025f, L), Steel);
            }
            for (int m = 0; m < 2; m++)
            {
                float z = 2f + m * 15f;
                for (int s = -1; s <= 1; s += 2)
                {
                    b.Box(new Vector3(s * 4.35f, 3.4f, z), new Vector3(0.22f, 6.8f, 0.22f), C(0x7C8590), default(Vector3), TexId.Metal, 2f);
                    b.Box(new Vector3(s * 4.35f, 0.2f, z), new Vector3(0.5f, 0.4f, 0.5f), C(0x9A9A98), default(Vector3), TexId.Concrete, 1f);
                }
                b.Box(new Vector3(0, 6.55f, z), new Vector3(9.0f, 0.18f, 0.18f), C(0x7C8590), default(Vector3), TexId.Metal, 2f); // gantry
                for (int lane = -1; lane <= 1; lane++)
                {
                    float x = lane * GameConfig.LaneWidth;
                    b.Box(new Vector3(x, 6.0f, z), new Vector3(0.04f, 1.1f, 0.04f), Steel);                 // dropper
                    b.Box(new Vector3(x, 5.6f, z), new Vector3(0.5f, 0.05f, 0.05f), Steel);
                    b.Sph(new Vector3(x, 6.35f, z - 0.15f), new Vector3(0.18f, 0.28f, 0.18f), (lane + m) % 2 == 0 ? new Color(0.2f, 1f, 0.35f, 0f) : new Color(1f, 0.2f, 0.15f, 0f)); // signal heads
                }
                // marigold garlands and flag bunting strung between the masts
                b.Garland(new Vector3(-4.35f, 6.2f, z), new Vector3(4.35f, 6.2f, z), 1.1f, 20, 0.2f, Marigold, Marigold2);
                for (int i = 1; i < 13; i++)
                {
                    float k = i / 13f;
                    float x = Mathf.Lerp(-4.35f, 4.35f, k);
                    float y = 6.2f - Mathf.Sin(k * Mathf.PI) * 1.1f - 0.28f;
                    b.Box(new Vector3(x, y, z), new Vector3(0.38f, 0.38f, 0.02f), HoliAt(i + m), new Vector3(0, 0, 45));
                }
            }
        }

        // ---------------------------------------------------------------- station furniture
        static void Canopy(MeshBatcher b, int s, float L, System.Random rng)
        {
            float x0 = s * PlatformInnerX, x1 = s * PlatformOuterX;
            float cx = (x0 + x1) * 0.5f, w = Mathf.Abs(x1 - x0) + 0.8f;
            // sloping roof from front edge (lower) to back (higher), as a thin slab rotated slightly
            b.Box(new Vector3(cx, 4.7f, L * 0.5f), new Vector3(w, 0.22f, L), C(0xD9DDE2), new Vector3(0, 0, -s * 4f), TexId.Metal, 3f);
            b.Box(new Vector3(cx - s * (w * 0.5f - 0.1f), 4.5f, L * 0.5f), new Vector3(0.22f, 0.5f, L), C(0xE8E8E0)); // fascia
            for (int i = 0; i < 10; i++) // colourful fascia panels
                b.Box(new Vector3(cx - s * (w * 0.5f + 0.02f), 4.5f, 1.5f + i * 3f), new Vector3(0.1f, 0.42f, 2.8f), HoliAt(i));
            for (int i = 0; i < 4; i++) // columns every 7.5 m with Holi garlands
            {
                float z = 3.75f + i * 7.5f;
                b.Box(new Vector3(s * (PlatformInnerX + 1.0f), 2.9f, z), new Vector3(0.28f, 3.9f, 0.28f), C(0x5A6573), default(Vector3), TexId.Metal, 2f);
                b.Box(new Vector3(s * (PlatformInnerX + 1.0f), 1.15f, z), new Vector3(0.42f, 0.3f, 0.42f), HoliAt(i + 1));
                b.Garland(new Vector3(s * (PlatformInnerX + 1.0f), 4.2f, z - 3.5f), new Vector3(s * (PlatformInnerX + 1.0f), 4.2f, z + 3.5f), 0.5f, 12, 0.14f, Marigold, Marigold2);
                b.Sph(new Vector3(s * (PlatformInnerX + 1.0f), 3.9f, z + 0.3f), 0.22f, Lamp);
            }
        }

        static void Benches(MeshBatcher b, int s, System.Random rng)
        {
            for (int i = 0; i < 2; i++)
            {
                float z = 7f + i * 15f, x = s * 8.2f;
                b.Box(new Vector3(x, PlatformTop + 0.45f, z), new Vector3(0.6f, 0.08f, 2.0f), C(0x8D5A2B), default(Vector3), TexId.Wood, 1f);
                b.Box(new Vector3(x + s * 0.28f, PlatformTop + 0.85f, z), new Vector3(0.08f, 0.6f, 2.0f), C(0x8D5A2B), default(Vector3), TexId.Wood, 1f);
                for (int e = -1; e <= 1; e += 2) b.Box(new Vector3(x, PlatformTop + 0.22f, z + e * 0.85f), new Vector3(0.5f, 0.44f, 0.08f), Dark);
            }
        }

        static void Signboards(MeshBatcher b, int s, float L, System.Random rng)
        {
            for (int i = 0; i < 2; i++)
            {
                float z = 11f + i * 14f, x = s * (PlatformInnerX + 1.0f);
                b.Box(new Vector3(x, 3.6f, z), new Vector3(0.1f, 0.7f, 2.4f), C(0x1B3A8A));
                b.Box(new Vector3(x - s * 0.06f, 3.6f, z), new Vector3(0.05f, 0.5f, 2.1f), Color.white);
                for (int k = 0; k < 4; k++) b.Box(new Vector3(x - s * 0.1f, 3.6f, z - 0.8f + k * 0.55f), new Vector3(0.03f, 0.3f, 0.3f), HoliAt(k + i));
            }
        }

        static void Stall(MeshBatcher b, int s, float z, System.Random rng)
        {
            float x = s * 8.3f;
            Color a = Holi(rng);
            b.Box(new Vector3(x, PlatformTop + 0.55f, z), new Vector3(1.4f, 1.1f, 2.4f), C(0x6D4C41), default(Vector3), TexId.Wood, 1.5f);
            b.Box(new Vector3(x, PlatformTop + 2.4f, z), new Vector3(1.8f, 0.08f, 2.8f), a, default(Vector3), TexId.Canvas, 1f);
            for (int sz = -1; sz <= 1; sz += 2) b.Box(new Vector3(x - s * 0.7f, PlatformTop + 1.25f, z + sz * 1.25f), new Vector3(0.07f, 2.5f, 0.07f), Color.white);
            for (int i = 0; i < 5; i++)
                b.Sph(new Vector3(x, PlatformTop + 1.2f, z - 1.0f + i * 0.5f), new Vector3(0.45f, 0.32f, 0.45f), HoliAt(i + (int)z));
            for (int i = 0; i < 3; i++)
                b.Cyl(new Vector3(x - s * 0.5f, PlatformTop + 1.9f, z - 0.8f + i * 0.8f), 0.1f, 0.4f, HoliAt(i * 2 + 1), new Vector3(0, 0, s * 40f));
            b.Garland(new Vector3(x, PlatformTop + 2.3f, z - 1.4f), new Vector3(x, PlatformTop + 2.3f, z + 1.4f), 0.2f, 8, 0.12f, Marigold, Marigold2);
        }

        static void Chai(MeshBatcher b, int s, float z, System.Random rng)
        {
            float x = s * 8.4f;
            b.Box(new Vector3(x, PlatformTop + 0.6f, z), new Vector3(1.2f, 1.2f, 1.6f), C(0xC0392B), default(Vector3), TexId.Canvas, 1f);
            b.Box(new Vector3(x, PlatformTop + 2.2f, z), new Vector3(1.6f, 0.1f, 2.0f), C(0x2E7D32), default(Vector3), TexId.Canvas, 1f);
            b.Cyl(new Vector3(x, PlatformTop + 1.4f, z), 0.5f, 0.4f, Steel);
            for (int sz = -1; sz <= 1; sz += 2) b.Box(new Vector3(x - s * 0.55f, PlatformTop + 1.1f, z + sz * 0.9f), new Vector3(0.06f, 2.2f, 0.06f), Color.white);
        }

        static void ParkedTrain(MeshBatcher b, int s, float L, System.Random rng)
        {
            // a decorative train on the far track beyond the platform, running the full segment length so it looks continuous
            float x = s * 14.5f;
            Color body = C(rng.Next(2) == 0 ? 0x2B5BA8 : 0x8C2F39);
            b.Box(new Vector3(x, 1.8f, L * 0.5f), new Vector3(2.6f, 2.6f, L + 0.02f), body, default(Vector3), TexId.Metal, 2f);
            b.Box(new Vector3(x, 2.3f, L * 0.5f), new Vector3(2.64f, 0.8f, L - 0.6f), Color.white, default(Vector3), TexId.Window, 1.6f);
            b.Box(new Vector3(x, 1.2f, L * 0.5f), new Vector3(2.62f, 0.14f, L + 0.02f), HoliAt(rng.Next(6)));
            b.Prim(PrimKind.Cylinder, new Vector3(x, 3.2f, L * 0.5f), new Vector3(2.5f, L, 0.7f), body * 0.9f, new Vector3(90, 0, 0));
            b.Box(new Vector3(x, 0.6f, L * 0.5f), new Vector3(2.2f, 0.5f, L), Dark);
        }

        static void Buildings(MeshBatcher b, int s, float L, System.Random rng, int minH, int maxH)
        {
            float z = 0f;
            int guard = 0;
            while (z < L - 2f && guard++ < 6)
            {
                float depth = Mathf.Min(L - z, 8f + (float)rng.NextDouble() * 6f);
                int floors = rng.Next(Mathf.Max(2, minH / 3), Mathf.Max(3, maxH / 3) + 1);
                float h = floors * 3.2f;
                Color wall = C(Pastels[rng.Next(Pastels.Length)]);
                Color accent = Holi(rng);
                float cz = z + depth * 0.5f;
                float bx = s * (PlatformOuterX + 3.8f);
                float width = 6.5f;
                b.Box(new Vector3(bx, h * 0.5f, cz), new Vector3(width, h, depth - 0.15f), wall, default(Vector3), TexId.Facade, 4f);
                b.Box(new Vector3(bx, h + 0.25f, cz), new Vector3(width + 0.3f, 0.5f, depth), accent);          // parapet
                // shop band with striped awning at the ground floor
                float faceX = bx - s * (width * 0.5f);
                b.Box(new Vector3(faceX - s * 0.05f, 1.4f, cz), new Vector3(0.12f, 2.6f, depth - 0.6f), C(0x4E342E));
                for (int i = 0; i < 4; i++)
                    b.Box(new Vector3(faceX - s * 0.55f, 2.7f, cz - depth * 0.35f + i * depth * 0.23f), new Vector3(1.2f, 0.08f, depth * 0.23f), i % 2 == 0 ? Color.white : accent, new Vector3(0, 0, s * 12f));
                // balconies, AC boxes
                for (int f = 1; f < floors; f++)
                {
                    float y = f * 3.2f + 1.2f;
                    if (rng.NextDouble() < 0.7)
                    {
                        b.Box(new Vector3(faceX - s * 0.45f, y - 0.8f, cz), new Vector3(0.9f, 0.12f, depth * 0.45f), C(0xE0E0E0));
                        b.Box(new Vector3(faceX - s * 0.88f, y - 0.35f, cz), new Vector3(0.05f, 0.75f, depth * 0.45f), accent);
                    }
                    if (rng.NextDouble() < 0.5)
                        b.Box(new Vector3(faceX - s * 0.2f, y + 0.3f, cz + depth * 0.3f), new Vector3(0.4f, 0.4f, 0.6f), C(0xEEEEEE));
                }
                // rooftop water tank, dish, flag
                if (rng.NextDouble() < 0.7)
                {
                    b.Cyl(new Vector3(bx + s * 1.0f, h + 1.2f, cz), 1.5f, 1.4f, C(0x263238));
                    b.Box(new Vector3(bx + s * 1.0f, h + 0.7f, cz), new Vector3(1.4f, 0.4f, 1.4f), Steel);
                }
                b.Box(new Vector3(bx - s * 2f, h + 1.4f, cz + 1f), new Vector3(0.05f, 2f, 0.05f), Color.white);
                b.Box(new Vector3(bx - s * 2f, h + 2.1f, cz + 1.4f), new Vector3(0.03f, 0.6f, 0.8f), Holi(rng));
                // painted Holi colour splashes on the wall
                for (int i = 0; i < 3; i++)
                    b.Prim(PrimKind.Sphere, new Vector3(faceX - s * 0.02f, 4f + (float)rng.NextDouble() * Mathf.Max(1f, h - 6f), z + 1f + (float)rng.NextDouble() * (depth - 2f)),
                        new Vector3(0.04f, 0.8f, 0.9f), Holi(rng));
                // garland hung between the building and the platform fence
                b.Garland(new Vector3(faceX, 5.5f, cz - 2f), new Vector3(s * (PlatformOuterX + 0.3f), 4.6f, cz + 2f), 0.5f, 10, 0.16f, Marigold, Marigold2);
                z += depth;
            }
        }

        static void Skyline(MeshBatcher b, int s, float L, System.Random rng)
        {
            for (int i = 0; i < 3; i++)
            {
                float h = 18f + (float)rng.NextDouble() * 20f;
                Color c = Color.Lerp(C(Pastels[rng.Next(Pastels.Length)]), C(0xB8A9C9), 0.5f);
                b.Box(new Vector3(s * (PlatformOuterX + 15f + (float)rng.NextDouble() * 6f), h * 0.5f, 4f + i * 10f), new Vector3(7f, h, 8.5f), c, default(Vector3), TexId.Facade, 4f);
            }
        }

        static void Footbridge(MeshBatcher b, float z, System.Random rng)
        {
            b.Box(new Vector3(0, 7.4f, z), new Vector3(19.5f, 0.3f, 2.4f), C(0x9AA3AD), default(Vector3), TexId.Metal, 3f);
            b.Box(new Vector3(0, 8.4f, z - 1.15f), new Vector3(19.5f, 0.1f, 0.1f), C(0xE91E8C));
            b.Box(new Vector3(0, 8.4f, z + 1.15f), new Vector3(19.5f, 0.1f, 0.1f), C(0xE91E8C));
            for (int i = 0; i < 14; i++)
            {
                b.Box(new Vector3(-9.2f + i * 1.4f, 7.9f, z - 1.15f), new Vector3(0.06f, 1.0f, 0.06f), Steel);
                b.Box(new Vector3(-9.2f + i * 1.4f, 7.9f, z + 1.15f), new Vector3(0.06f, 1.0f, 0.06f), Steel);
            }
            for (int s = -1; s <= 1; s += 2)
            {
                b.Box(new Vector3(s * 5.2f, 3.7f, z), new Vector3(0.5f, 7.4f, 0.5f), C(0x7C8590), default(Vector3), TexId.Metal, 2f);
                b.Box(new Vector3(s * 5.2f, 4.5f, z), new Vector3(1.0f, 0.2f, 1.0f), HoliAt(s + 2));
            }
            // big hanging Holi banner under the bridge deck (above head height)
            for (int i = 0; i < 6; i++)
                b.Box(new Vector3(-4.5f + i * 1.8f, 6.7f, z - 1.25f), new Vector3(1.7f, 0.6f, 0.05f), HoliAt(i));
        }

        static void BannerSpan(MeshBatcher b, float z, System.Random rng)
        {
            for (int s = -1; s <= 1; s += 2) b.Box(new Vector3(s * 4.6f, 3.8f, z), new Vector3(0.25f, 7.6f, 0.25f), C(0x5D4037));
            b.Box(new Vector3(0, 7.2f, z), new Vector3(9.4f, 0.4f, 0.3f), C(0xE91E8C));
            for (int i = 0; i < 9; i++)
                b.Box(new Vector3(-4.0f + i, 6.5f, z), new Vector3(0.9f, 1.2f, 0.04f), HoliAt(i), default(Vector3), TexId.Canvas, 1f);
            b.Garland(new Vector3(-4.5f, 7.0f, z), new Vector3(4.5f, 7.0f, z), 0.9f, 22, 0.2f, Marigold, Marigold2);
        }

        static void Torana(MeshBatcher b, float z)
        {
            for (int s = -1; s <= 1; s += 2)
            {
                b.Cyl(new Vector3(s * 4.7f, 3.4f, z), 0.7f, 6.8f, C(0xFFCC80));
                b.Sph(new Vector3(s * 4.7f, 7.0f, z), 0.9f, new Color(1f, 0.84f, 0.33f, 0.1f));
            }
            b.Box(new Vector3(0, 6.6f, z), new Vector3(10.2f, 0.6f, 0.7f), C(0xE91E8C));
            b.Box(new Vector3(0, 7.2f, z), new Vector3(8.0f, 0.5f, 0.6f), C(0xFFC107));
            b.Garland(new Vector3(-4.7f, 6.2f, z), new Vector3(4.7f, 6.2f, z), 1.3f, 24, 0.22f, Marigold, Marigold2);
        }

        static void Temple(MeshBatcher b, int s, float z, System.Random rng)
        {
            float x = s * 14.5f;
            b.Box(new Vector3(x, 0.6f, z), new Vector3(8f, 1.2f, 13f), C(0xEFEBE9), default(Vector3), TexId.Concrete, 3f);
            float y = 1.2f;
            float[] w = { 5.6f, 4.8f, 4.0f, 3.2f, 2.4f };
            float[] h = { 2.6f, 2.2f, 1.9f, 1.6f, 1.4f };
            for (int i = 0; i < w.Length; i++)
            {
                b.Box(new Vector3(x, y + h[i] * 0.5f, z), new Vector3(w[i], h[i], w[i] * 1.2f), i % 2 == 0 ? C(0xFFCC80) : C(0xFFAB91), default(Vector3), TexId.Brick, 2f);
                b.Box(new Vector3(x - s * (w[i] * 0.5f + 0.03f), y + h[i] * 0.5f, z), new Vector3(0.12f, h[i] * 0.6f, w[i] * 0.55f), C(0xFFD54F));
                y += h[i];
            }
            b.Prim(PrimKind.Wedge, new Vector3(x, y + 0.6f, z), new Vector3(2.6f, 1.2f, 3.2f), C(0xFFB74D));
            b.Sph(new Vector3(x, y + 1.5f, z), 0.9f, new Color(1f, 0.84f, 0.33f, 0.1f)); // golden kalash
            b.Box(new Vector3(x, y + 2.3f, z), new Vector3(0.05f, 1.2f, 0.05f), Color.white);
            b.Box(new Vector3(x, y + 2.6f, z + 0.4f), new Vector3(0.03f, 0.5f, 0.8f), C(0xFF6F00)); // saffron flag
            for (int i = 0; i < 4; i++) // front pillars with diya lamps
            {
                float pz = z - 4.5f + i * 3f;
                b.Cyl(new Vector3(s * 10.4f, 1.9f, pz), 0.5f, 1.8f, C(0xFFE0B2));
                b.Sph(new Vector3(s * 10.4f, 2.95f, pz), 0.35f, new Color(1f, 0.92f, 0.23f, 0f));
            }
            b.Garland(new Vector3(s * 10.4f, 2.6f, z - 4.5f), new Vector3(s * 10.4f, 2.6f, z + 4.5f), 0.4f, 12, 0.18f, Marigold, Marigold2);
        }

        static void Rangoli(MeshBatcher b, Vector3 c, float radius, System.Random rng)
        {
            Color a = Holi(rng), b2 = Holi(rng);
            b.Prim(PrimKind.Cylinder, c, new Vector3(radius * 2f, 0.004f, radius * 2f), C(0xFFF8E1));
            b.Prim(PrimKind.Cylinder, c + Vector3.up * 0.002f, new Vector3(radius * 1.6f, 0.004f, radius * 1.6f), a);
            b.Prim(PrimKind.Cylinder, c + Vector3.up * 0.004f, new Vector3(radius * 1.1f, 0.004f, radius * 1.1f), Color.white);
            b.Prim(PrimKind.Cylinder, c + Vector3.up * 0.006f, new Vector3(radius * 0.8f, 0.004f, radius * 0.8f), b2);
            for (int i = 0; i < 8; i++)
            {
                float ang = i * Mathf.PI / 4f;
                b.Prim(PrimKind.Cylinder, c + new Vector3(Mathf.Cos(ang), 0.008f, Mathf.Sin(ang)) * radius * 0.5f, new Vector3(radius * 0.3f, 0.004f, radius * 0.3f), C(0xFFD400));
            }
        }
    }
}
