using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace TokyoNightRun
{
    /// <summary>
    /// Builds obstacles, trains and collectibles. Every model is assembled from primitives through MeshBatcher,
    /// so each one costs only 1-3 draw calls. All pivots are at ground level.
    /// Decorations have NO colliders; only obstacles and collectibles do (trigger colliders).
    /// </summary>
    public static class ProceduralFactory
    {
        static readonly Dictionary<PrimitiveType, Mesh> meshes = new Dictionary<PrimitiveType, Mesh>();

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics() { meshes.Clear(); }

        // ---------- generic helpers (kept for editor/test code and small one-off objects) ----------
        public static void DestroyObj(Object o)
        {
            if (o == null) return;
            if (Application.isPlaying) Object.Destroy(o); else Object.DestroyImmediate(o);
        }

        public static Mesh GetMesh(PrimitiveType t)
        {
            Mesh m;
            if (meshes.TryGetValue(t, out m) && m != null) return m;
            var tmp = GameObject.CreatePrimitive(t);
            tmp.SetActive(false);
            m = tmp.GetComponent<MeshFilter>().sharedMesh;
            DestroyObj(tmp);
            meshes[t] = m;
            return m;
        }

        public static GameObject Prim(Transform parent, PrimitiveType t, Vector3 pos, Vector3 scale, Color color,
            string name = null, Vector3 euler = default(Vector3), bool glow = false)
        {
            var go = new GameObject(name ?? t.ToString());
            var tr = go.transform;
            tr.SetParent(parent, false);
            tr.localPosition = pos;
            tr.localEulerAngles = euler;
            tr.localScale = scale;
            go.AddComponent<MeshFilter>().sharedMesh = GetMesh(t);
            var r = go.AddComponent<MeshRenderer>();
            r.sharedMaterial = glow ? MaterialLibrary.Glow(color) : MaterialLibrary.Lit(color);
            r.shadowCastingMode = ShadowCastingMode.Off;
            r.receiveShadows = false;
            return go;
        }

        static GameObject Root(string name) { return new GameObject(name); }
        static Color C(int rgb) { return GameConfig.Hex(rgb); }
        static Color HoliCol(int i) { return Theme.Pal(i); }
        static readonly Color Marigold = GameConfig.Hex(0xFF9800);
        static readonly Color Marigold2 = GameConfig.Hex(0xFFC107);
        static readonly Color Dark = new Color(0.14f, 0.14f, 0.16f, 1f);

        static Obstacle Finish(GameObject root, ObstacleType type, ObstacleKind kind, Vector3 center, Vector3 size, float move = 0f)
        {
            var col = root.AddComponent<BoxCollider>();
            col.isTrigger = true;
            col.center = center;
            col.size = size;
            if (move > 0f)
            {
                var rb = root.AddComponent<Rigidbody>(); // moving trigger colliders need a kinematic body to be detected reliably
                rb.isKinematic = true;
                rb.useGravity = false;
            }
            var o = root.AddComponent<Obstacle>();
            o.Configure(type, kind, move);
            return o;
        }

        // ---------- obstacles ----------
        public static GameObject BuildObstacle(ObstacleType type, System.Random rng)
        {
            Color accent = Theme.RandomPal(rng);
            var root = Root("Obstacle_" + type);
            var b = new MeshBatcher();
            bool isTrain = type == ObstacleType.TrainStatic || type == ObstacleType.TrainMoving || type == ObstacleType.TrainCargo;
            if (!Theme.IsHoli && !isTrain)
            {
                // other themes: new visuals, identical colliders so every theme plays the same
                ThemeProps.Obstacle(type, b, accent, rng);
                b.Build(root.transform, type.ToString());
                switch (type)
                {
                    case ObstacleType.Cart: Finish(root, type, ObstacleKind.Solid, new Vector3(0, 1.0f, 0), new Vector3(1.8f, 2.0f, 2.4f)); break;
                    case ObstacleType.Barricade: Finish(root, type, ObstacleKind.Low, new Vector3(0, 0.4f, 0), new Vector3(2.0f, 0.8f, 1.0f)); break;
                    case ObstacleType.Trolley: Finish(root, type, ObstacleKind.Low, new Vector3(0, 0.5f, 0), new Vector3(1.1f, 1.0f, 1.8f)); break;
                    case ObstacleType.Puddle: Finish(root, type, ObstacleKind.Slow, new Vector3(0, 0.15f, 0), new Vector3(1.6f, 0.3f, 1.6f)); break;
                    case ObstacleType.Banner: Finish(root, type, ObstacleKind.High, new Vector3(0, 1.9f, 0), new Vector3(2.0f, 1.1f, 1.0f)); break;
                    default: Finish(root, type, ObstacleKind.Solid, new Vector3(0, 1.0f, 0), new Vector3(1.4f, 2.0f, 1.4f)); break;
                }
                return root;
            }
            switch (type)
            {
                case ObstacleType.TrainStatic: // parked coach, shows its end door to the player (Solid)
                {
                    float L = GameConfig.TrainLength;
                    TrainFactory.BuildCoach(b, L, false, rng);
                    b.Build(root.transform, "Train");
                    Finish(root, type, ObstacleKind.Solid, new Vector3(0, GameConfig.TrainHeight * 0.5f, 0), new Vector3(2.0f, GameConfig.TrainHeight, L));
                    break;
                }
                case ObstacleType.TrainMoving: // locomotive/EMU driving towards the player (Solid)
                {
                    float L = GameConfig.TrainLength;
                    TrainFactory.BuildCoach(b, L, true, rng);
                    b.Build(root.transform, "Train");
                    Finish(root, type, ObstacleKind.Solid, new Vector3(0, GameConfig.TrainHeight * 0.5f, 0), new Vector3(2.0f, GameConfig.TrainHeight, L), GameConfig.MovingTrainSpeed);
                    break;
                }
                case ObstacleType.TrainCargo: // open freight wagon with festival goods (Solid, 2.9m)
                {
                    float L = GameConfig.CargoLength;
                    TrainFactory.BuildCargo(b, L, rng);
                    b.Build(root.transform, "Wagon");
                    Finish(root, type, ObstacleKind.Solid, new Vector3(0, 1.5f, 0), new Vector3(2.0f, 3.0f, L));
                    break;
                }
                case ObstacleType.Cart: // porter's luggage cart with trunks and a Holi canopy (Solid, 2.0m)
                    b.Box(new Vector3(0, 0.62f, 0), new Vector3(1.5f, 0.3f, 2.2f), C(0x8D5A2B), default(Vector3), TexId.Wood, 1.5f);
                    for (int sx = -1; sx <= 1; sx += 2) for (int sz = -1; sz <= 1; sz += 2) b.Wheel(new Vector3(0.8f * sx, 0.3f, 0.7f * sz), 0.3f, 0.12f, Dark);
                    b.Box(new Vector3(-0.3f, 1.15f, 0.2f), new Vector3(0.8f, 0.7f, 0.9f), C(0x3E5C76), default(Vector3), TexId.Canvas, 1f);
                    b.Box(new Vector3(0.35f, 1.0f, -0.4f), new Vector3(0.7f, 0.55f, 0.8f), C(0xB5651D), default(Vector3), TexId.Wood, 1f);
                    b.Box(new Vector3(0, 1.8f, 0), new Vector3(1.8f, 0.1f, 2.5f), accent, default(Vector3), TexId.Canvas, 1f);
                    for (int sx = -1; sx <= 1; sx += 2) for (int sz = -1; sz <= 1; sz += 2) b.Box(new Vector3(0.8f * sx, 1.25f, 1.0f * sz), new Vector3(0.08f, 1.15f, 0.08f), Color.white);
                    b.Garland(new Vector3(-0.9f, 1.72f, -1.25f), new Vector3(0.9f, 1.72f, -1.25f), 0.18f, 8, 0.12f, Marigold, Marigold2);
                    b.Build(root.transform, "Cart");
                    Finish(root, type, ObstacleKind.Solid, new Vector3(0, 1.0f, 0), new Vector3(1.8f, 2.0f, 2.4f));
                    break;

                case ObstacleType.Barricade: // striped rail-yard barrier: jump over (Low, 0.8m)
                    b.Box(new Vector3(-0.8f, 0.4f, 0), new Vector3(0.1f, 0.8f, 0.1f), Dark);
                    b.Box(new Vector3(0.8f, 0.4f, 0), new Vector3(0.1f, 0.8f, 0.1f), Dark);
                    for (int i = 0; i < 6; i++)
                        b.Box(new Vector3(-0.8f + i * 0.32f, 0.62f, 0), new Vector3(0.32f, 0.2f, 0.12f), i % 2 == 0 ? C(0xFF6F00) : Color.white);
                    b.Box(new Vector3(0, 0.36f, 0), new Vector3(1.9f, 0.2f, 0.12f), Color.white);
                    b.Sph(new Vector3(0.8f, 0.9f, 0), 0.16f, new Color(1f, 0.2f, 0.1f, 0f)); // warning lamp
                    b.Build(root.transform, "Barrier");
                    Finish(root, type, ObstacleKind.Low, new Vector3(0, 0.4f, 0), new Vector3(2.0f, 0.8f, 1.0f));
                    break;

                case ObstacleType.Trolley: // handcart of gulal sacks (Low, 0.9m)
                    b.Box(new Vector3(0, 0.45f, 0), new Vector3(1.0f, 0.18f, 1.6f), C(0x8D5A2B), default(Vector3), TexId.Wood, 1f);
                    b.Wheel(new Vector3(0.55f, 0.25f, 0.5f), 0.25f, 0.1f, Dark);
                    b.Wheel(new Vector3(-0.55f, 0.25f, 0.5f), 0.25f, 0.1f, Dark);
                    b.Box(new Vector3(0, 0.95f, -0.9f), new Vector3(0.9f, 0.06f, 0.06f), Steel());
                    for (int i = 0; i < 3; i++) b.Sph(new Vector3(-0.28f + i * 0.28f, 0.75f, 0.1f), new Vector3(0.42f, 0.4f, 0.55f), HoliCol(i * 2 + rng.Next(2)));
                    b.Sph(new Vector3(0, 1.05f, 0.1f), new Vector3(0.45f, 0.36f, 0.5f), accent);
                    b.Build(root.transform, "Trolley");
                    Finish(root, type, ObstacleKind.Low, new Vector3(0, 0.5f, 0), new Vector3(1.1f, 1.0f, 1.8f));
                    break;

                case ObstacleType.Puddle: // coloured water puddle (Slow, jump to avoid)
                    b.Cyl(new Vector3(0, 0.02f, 0), 1.8f, 0.02f, accent * 0.9f);
                    b.Cyl(new Vector3(0, 0.035f, 0), 1.1f, 0.02f, Color.Lerp(accent, Color.white, 0.5f));
                    b.Build(root.transform, "Puddle");
                    Finish(root, type, ObstacleKind.Slow, new Vector3(0, 0.15f, 0), new Vector3(1.6f, 0.3f, 1.6f));
                    break;

                case ObstacleType.Banner: // Holi banner hung low from a signal gantry (High, slide under)
                    b.Box(new Vector3(-1.0f, 1.4f, 0), new Vector3(0.1f, 2.8f, 0.1f), Steel());
                    b.Box(new Vector3(1.0f, 1.4f, 0), new Vector3(0.1f, 2.8f, 0.1f), Steel());
                    b.Box(new Vector3(0, 2.4f, 0), new Vector3(2.1f, 0.1f, 0.1f), Steel());
                    b.Box(new Vector3(0, 1.9f, 0), new Vector3(1.9f, 0.9f, 0.05f), accent, default(Vector3), TexId.Canvas, 1f);
                    b.Box(new Vector3(0, 1.9f, -0.03f), new Vector3(1.3f, 0.45f, 0.05f), C(0xFFD400));
                    b.Sph(new Vector3(0, 1.9f, -0.07f), 0.3f, Color.white);
                    for (int i = 0; i < 5; i++) b.Box(new Vector3(-0.8f + i * 0.4f, 1.4f, 0), new Vector3(0.2f, 0.2f, 0.04f), HoliCol(i), new Vector3(0, 0, 45));
                    b.Sph(new Vector3(0.0f, 2.62f, 0), 0.2f, new Color(0.2f, 1f, 0.35f, 0f)); // signal lamp
                    b.Build(root.transform, "Banner");
                    Finish(root, type, ObstacleKind.High, new Vector3(0, 1.9f, 0), new Vector3(2.0f, 1.1f, 1.0f));
                    break;

                default: // SupplyStack: stacked crates and gulal sacks (Solid, 2.0m)
                    b.Box(new Vector3(0, 0.33f, 0), new Vector3(1.3f, 0.65f, 1.3f), C(0xA1887F), default(Vector3), TexId.Wood, 1f);
                    b.Box(new Vector3(0.05f, 0.98f, 0), new Vector3(1.2f, 0.65f, 1.2f), C(0x8D6E63), default(Vector3), TexId.Wood, 1f);
                    b.Box(new Vector3(-0.05f, 1.63f, 0), new Vector3(1.1f, 0.65f, 1.1f), C(0xA1887F), default(Vector3), TexId.Wood, 1f);
                    for (int i = 0; i < 3; i++) b.Sph(new Vector3(-0.3f + i * 0.3f, 2.1f, 0), 0.38f, HoliCol(i * 2));
                    b.Box(new Vector3(0, 0.98f, -0.62f), new Vector3(0.6f, 0.3f, 0.03f), Color.white);
                    b.Build(root.transform, "Crates");
                    Finish(root, type, ObstacleKind.Solid, new Vector3(0, 1.0f, 0), new Vector3(1.4f, 2.0f, 1.4f));
                    break;
            }
            return root;
        }

        static Color Steel() { return new Color(0.5f, 0.52f, 0.56f, 1f); }

        // ---------- collectibles ----------
        static Collectible FinishPickup(GameObject root, CollectibleType type, float radius, float height)
        {
            var col = root.AddComponent<SphereCollider>();
            col.isTrigger = true;
            col.radius = radius;
            col.center = new Vector3(0, height, 0);
            var c = root.AddComponent<Collectible>();
            c.Type = type;
            return c;
        }

        /// <summary>Embossed gold coin: rim, face, raised centre star. Faces +/-Z so it reads well as it spins.</summary>
        public static void CoinMesh(MeshBatcher b, Vector3 centre, float scale)
        {
            Color rim = new Color(1f, 0.70f, 0.05f, 0.35f), face = new Color(1f, 0.85f, 0.25f, 0.25f), star = new Color(1f, 0.95f, 0.6f, 0.1f);
            b.Prim(PrimKind.Cylinder, centre, new Vector3(0.62f, 0.07f, 0.62f) * scale, rim, new Vector3(90, 0, 0));
            b.Prim(PrimKind.Cylinder, centre + new Vector3(0, 0, -0.005f) * scale, new Vector3(0.5f, 0.085f, 0.5f) * scale, face, new Vector3(90, 0, 0));
            b.Box(centre + new Vector3(0, 0, -0.05f) * scale, new Vector3(0.16f, 0.3f, 0.03f) * scale, star);
            b.Box(centre + new Vector3(0, 0, -0.05f) * scale, new Vector3(0.3f, 0.16f, 0.03f) * scale, star);
            b.Box(centre + new Vector3(0, 0, -0.05f) * scale, new Vector3(0.2f, 0.2f, 0.03f) * scale, star, new Vector3(0, 0, 45));
        }

        public static GameObject BuildCoin()
        {
            var root = Root("Coin");
            var b = new MeshBatcher();
            CoinMesh(b, new Vector3(0, 0.6f, 0), 1f);
            b.Build(root.transform, "CoinMesh");
            var c = FinishPickup(root, CollectibleType.Coin, 0.55f, 0.6f);
            c.SpinSpeed = 220f;
            return root;
        }

        public static GameObject BuildGulal(Color color)
        {
            var root = Root("Gulal");
            var b = new MeshBatcher();
            if (!Theme.IsHoli) ThemeProps.PickupA(b, color);
            else
            {
                b.Box(new Vector3(0, 0.6f, 0), new Vector3(0.38f, 0.5f, 0.16f), color);
                b.Box(new Vector3(0, 0.88f, 0), new Vector3(0.4f, 0.06f, 0.18f), Color.white);
                b.Sph(new Vector3(0, 1.0f, 0), 0.34f, new Color(color.r, color.g, color.b, 0.2f));
                b.Sph(new Vector3(0, 0.6f, -0.09f), new Vector3(0.22f, 0.22f, 0.02f), Color.white);
            }
            b.Build(root.transform, "Gulal");
            var c = FinishPickup(root, CollectibleType.Gulal, 0.6f, 0.65f);
            c.PowderColor = color;
            c.SpinSpeed = 120f;
            return root;
        }

        public static GameObject BuildBalloon(Color color)
        {
            var root = Root("WaterBalloon");
            var b = new MeshBatcher();
            if (!Theme.IsHoli) ThemeProps.PickupB(b, color);
            else
            {
                b.Sph(new Vector3(0, 0.65f, 0), new Vector3(0.45f, 0.52f, 0.45f), color);
                b.Sph(new Vector3(0, 0.35f, 0), 0.1f, color);
                b.Sph(new Vector3(-0.08f, 0.78f, -0.12f), 0.1f, new Color(1f, 1f, 1f, 0.3f)); // shine
            }
            b.Build(root.transform, "Balloon");
            var c = FinishPickup(root, CollectibleType.WaterBalloon, 0.55f, 0.65f);
            c.PowderColor = color;
            c.SpinSpeed = 90f;
            return root;
        }

        public static GameObject BuildToken()
        {
            var root = Root("FestivalToken");
            var b = new MeshBatcher();
            if (!Theme.IsHoli) ThemeProps.Token(b);
            else
            {
                b.Box(new Vector3(0, 0.8f, 0), Vector3.one * 0.5f, new Color(0.67f, 0.28f, 0.74f, 0.2f), new Vector3(45, 0, 45));
                b.Sph(new Vector3(0, 0.8f, 0), 0.25f, new Color(1f, 0.84f, 0.33f, 0f));
            }
            b.Build(root.transform, "Token");
            var c = FinishPickup(root, CollectibleType.Token, 0.65f, 0.8f);
            c.PowderColor = Theme.IsHoli ? C(0xAB47BC) : Theme.Pal(3);
            c.SpinSpeed = 150f;
            return root;
        }

        public static Color PowerUpColor(PowerUpType t) { return C(Theme.Current.PowerColors[(int)t]); }

        public static string PowerUpName(PowerUpType t) { return Theme.Current.PowerNames[(int)t]; }

        public static GameObject BuildPowerUp(PowerUpType type)
        {
            var root = Root("PowerUp_" + type);
            var b = new MeshBatcher();
            Color c = PowerUpColor(type);
            Color glow = new Color(c.r, c.g, c.b, 0.25f);
            b.Sph(new Vector3(0, 0.9f, 0), 0.82f, glow);
            b.Prim(PrimKind.Cylinder, new Vector3(0, 0.9f, 0), new Vector3(1.0f, 0.04f, 1.0f), Color.white, new Vector3(90, 0, 0)); // halo disc
            Color w = new Color(1f, 1f, 1f, 0.1f);
            Vector3 f = new Vector3(0, 0, -0.38f);
            switch (type) // a different white symbol per type so they are easy to tell apart
            {
                case PowerUpType.Magnet:
                    b.Box(new Vector3(-0.15f, 0.9f, 0) + f, new Vector3(0.12f, 0.4f, 0.1f), w);
                    b.Box(new Vector3(0.15f, 0.9f, 0) + f, new Vector3(0.12f, 0.4f, 0.1f), w);
                    b.Box(new Vector3(0, 0.75f, 0) + f, new Vector3(0.42f, 0.12f, 0.1f), w);
                    break;
                case PowerUpType.Pichkari:
                    b.Prim(PrimKind.Cylinder, new Vector3(0, 0.9f, 0) + f, new Vector3(0.12f, 0.5f, 0.12f), w, new Vector3(90, 0, 0));
                    b.Box(new Vector3(0, 0.78f, 0) + f, new Vector3(0.12f, 0.2f, 0.12f), w);
                    break;
                case PowerUpType.Shield:
                    b.Box(new Vector3(0, 0.95f, 0) + f, new Vector3(0.4f, 0.4f, 0.1f), w);
                    b.Box(new Vector3(0, 0.75f, 0) + f, new Vector3(0.25f, 0.25f, 0.1f), w, new Vector3(0, 0, 45));
                    break;
                default:
                    b.Box(new Vector3(0, 0.9f, 0) + f, new Vector3(0.45f, 0.12f, 0.1f), w, new Vector3(0, 0, 45));
                    b.Box(new Vector3(0, 0.9f, 0) + f, new Vector3(0.45f, 0.12f, 0.1f), w, new Vector3(0, 0, -45));
                    break;
            }
            b.Build(root.transform, "PowerUp");
            var col = FinishPickup(root, CollectibleType.PowerUp, 0.7f, 0.9f);
            col.PowerType = type;
            col.PowderColor = c;
            col.SpinSpeed = 100f;
            return root;
        }
    }
}
