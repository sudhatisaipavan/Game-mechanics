using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Cartoon sky: a gradient dome with sun glow that follows the camera, plus a field of soft clouds.
    /// Colours are blended by AtmosphereController (morning, noon, sunset). Built entirely in code.
    /// </summary>
    public class SkyDome : MonoBehaviour
    {
        Transform cam;
        Transform clouds, stars;
        Material skyMat, cloudMat;
        float t;
        Vector3 cloudBase;

        public static SkyDome Create(Camera camera)
        {
            var go = new GameObject("Sky");
            var sky = go.AddComponent<SkyDome>();
            sky.Build(camera);
            return sky;
        }

        void Build(Camera camera)
        {
            cam = camera.transform;

            // ---- dome
            var d = PrimMesh.Get(PrimKind.Sphere);
            var mesh = new Mesh { name = "SkyDome" };
            var verts = new Vector3[d.V.Length];
            for (int i = 0; i < verts.Length; i++) verts[i] = d.V[i] * 2f; // radius 1 (unit direction)
            mesh.vertices = verts;
            mesh.triangles = d.T;
            mesh.bounds = new Bounds(Vector3.zero, Vector3.one * 4000f);
            var domeGo = new GameObject("Dome");
            domeGo.transform.SetParent(transform, false);
            domeGo.transform.localScale = Vector3.one * 150f;
            domeGo.AddComponent<MeshFilter>().sharedMesh = mesh;
            var mr = domeGo.AddComponent<MeshRenderer>();
            skyMat = MaterialLibrary.Sky();
            mr.sharedMaterial = skyMat;
            mr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            mr.receiveShadows = false;

            // ---- clouds: one mesh, many soft quads (single draw call)
            var rng = new System.Random(2026);
            const int count = 22;
            var v = new Vector3[count * 4];
            var uv = new Vector2[count * 4];
            var col = new Color32[count * 4];
            var tri = new int[count * 6];
            for (int i = 0; i < count; i++)
            {
                float x = Mathf.Lerp(-110f, 110f, (float)rng.NextDouble());
                float z = Mathf.Lerp(70f, 110f, (float)rng.NextDouble());
                float y = Mathf.Lerp(16f, 62f, (float)rng.NextDouble());
                float w = Mathf.Lerp(22f, 52f, (float)rng.NextDouble());
                float h = w * 0.42f;
                int k = i * 4;
                v[k] = new Vector3(x - w, y - h, z); v[k + 1] = new Vector3(x - w, y + h, z);
                v[k + 2] = new Vector3(x + w, y + h, z); v[k + 3] = new Vector3(x + w, y - h, z);
                uv[k] = new Vector2(0, 0); uv[k + 1] = new Vector2(0, 1); uv[k + 2] = new Vector2(1, 1); uv[k + 3] = new Vector2(1, 0);
                byte a = (byte)Random.Range(170, 245);
                for (int c = 0; c < 4; c++) col[k + c] = new Color32(255, 255, 255, a);
                int t0 = i * 6;
                tri[t0] = k; tri[t0 + 1] = k + 1; tri[t0 + 2] = k + 2; tri[t0 + 3] = k; tri[t0 + 4] = k + 2; tri[t0 + 5] = k + 3;
            }
            var cm = new Mesh { name = "Clouds" };
            cm.vertices = v; cm.uv = uv; cm.colors32 = col; cm.triangles = tri;
            cm.bounds = new Bounds(new Vector3(0, 40, 100), new Vector3(600, 200, 200));
            var cgo = new GameObject("Clouds");
            cgo.transform.SetParent(transform, false);
            cgo.AddComponent<MeshFilter>().sharedMesh = cm;
            var cr = cgo.AddComponent<MeshRenderer>();
            // a private copy so the cloud tint does not affect other users of the material
            cloudMat = new Material(MaterialLibrary.Cloud());
            if (cloudMat.HasProperty("_CurveAmount")) cloudMat.SetFloat("_CurveAmount", 0f);
            cr.sharedMaterial = cloudMat;
            cr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            cr.receiveShadows = false;
            clouds = cgo.transform;

            if (Theme.Current.Stars) BuildStars();
        }

        /// <summary>Night themes: a field of twinkling sparkle quads high in the sky (additive, one draw call).</summary>
        void BuildStars()
        {
            var rng = new System.Random(77);
            const int count = 140;
            var v = new Vector3[count * 4]; var uv = new Vector2[count * 4]; var col = new Color32[count * 4]; var tri = new int[count * 6];
            for (int i = 0; i < count; i++)
            {
                float x = Mathf.Lerp(-120f, 120f, (float)rng.NextDouble());
                float y = Mathf.Lerp(30f, 100f, (float)rng.NextDouble());
                float z = Mathf.Lerp(60f, 120f, (float)rng.NextDouble());
                float sz = Mathf.Lerp(0.5f, 1.6f, (float)rng.NextDouble());
                int k = i * 4;
                v[k] = new Vector3(x - sz, y - sz, z); v[k + 1] = new Vector3(x - sz, y + sz, z);
                v[k + 2] = new Vector3(x + sz, y + sz, z); v[k + 3] = new Vector3(x + sz, y - sz, z);
                uv[k] = new Vector2(0, 0); uv[k + 1] = new Vector2(0, 1); uv[k + 2] = new Vector2(1, 1); uv[k + 3] = new Vector2(1, 0);
                byte a = (byte)rng.Next(110, 255);
                for (int c = 0; c < 4; c++) col[k + c] = new Color32(255, 255, 255, a);
                int t0 = i * 6;
                tri[t0] = k; tri[t0 + 1] = k + 1; tri[t0 + 2] = k + 2; tri[t0 + 3] = k; tri[t0 + 4] = k + 2; tri[t0 + 5] = k + 3;
            }
            var sm = new Mesh { name = "Stars" };
            sm.vertices = v; sm.uv = uv; sm.colors32 = col; sm.triangles = tri;
            sm.bounds = new Bounds(new Vector3(0, 60, 100), new Vector3(600, 200, 200));
            var sgo = new GameObject("Stars");
            sgo.transform.SetParent(transform, false);
            sgo.AddComponent<MeshFilter>().sharedMesh = sm;
            var sr = sgo.AddComponent<MeshRenderer>();
            var mat = new Material(MaterialLibrary.Sparkle());
            if (mat.HasProperty("_CurveAmount")) mat.SetFloat("_CurveAmount", 0f);
            sr.sharedMaterial = mat;
            sr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            sr.receiveShadows = false;
            stars = sgo.transform;
        }

        public void SetColors(Color top, Color mid, Color horizon, Color bottom, Color sun, Vector3 sunDir, Color cloudTint)
        {
            if (skyMat != null && skyMat.HasProperty("_TopColor"))
            {
                skyMat.SetColor("_TopColor", top);
                skyMat.SetColor("_MidColor", mid);
                skyMat.SetColor("_HorizonColor", horizon);
                skyMat.SetColor("_BottomColor", bottom);
                skyMat.SetColor("_SunColor", sun);
                skyMat.SetVector("_SunDir", new Vector4(sunDir.x, sunDir.y, sunDir.z, 0f));
            }
            if (cloudMat != null) cloudMat.color = cloudTint;
        }

        void LateUpdate()
        {
            if (cam == null) return;
            t += Time.deltaTime;
            transform.position = cam.position;
            if (clouds != null) clouds.localPosition = new Vector3(Mathf.Sin(t * 0.03f) * 18f, 0f, 0f);
            if (stars != null) stars.localPosition = new Vector3(Mathf.Sin(t * 0.01f) * 6f, Mathf.Sin(t * 0.5f) * 0.4f, 0f);
        }

        void OnDestroy()
        {
            if (cloudMat != null) Destroy(cloudMat);
        }
    }
}
