using System.Collections.Generic;
using UnityEngine;

namespace TokyoNightRun
{
    public enum TexId { None = 0, Facade, Brick, Concrete, Ballast, Wood, Metal, Window, Tile, Canvas, Graffiti0, Graffiti1, Graffiti2, Graffiti3, FacadeNight, Snow, Sand, Asphalt }

    /// <summary>
    /// Small procedural textures (64-128 px, generated once at start-up) so surfaces have brick, tile, concrete,
    /// ballast and window detail without importing any image files. They are greyscale-ish and get tinted by vertex colour.
    /// </summary>
    public static class TextureFactory
    {
        static readonly Dictionary<TexId, Texture2D> cache = new Dictionary<TexId, Texture2D>();

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics() { cache.Clear(); }

        public static Texture2D Get(TexId id)
        {
            if (id == TexId.None) return null;
            Texture2D t;
            if (cache.TryGetValue(id, out t) && t != null) return t;
            t = Make(id);
            cache[id] = t;
            return t;
        }

        static float Noise(int x, int y, float scale, float seed)
        {
            return Mathf.PerlinNoise(x * scale + seed, y * scale + seed * 1.7f);
        }

        static Texture2D Make(TexId id)
        {
            if (id >= TexId.Graffiti0 && id <= TexId.Graffiti3)
                return GraffitiTextures.Make((int)id - (int)TexId.Graffiti0);
            int n = (id == TexId.Facade) ? 128 : (id == TexId.FacadeNight ? 256 : 64);
            var tex = new Texture2D(n, n, TextureFormat.RGBA32, true);
            tex.wrapMode = TextureWrapMode.Repeat;
            tex.filterMode = FilterMode.Bilinear;
            tex.anisoLevel = 1;
            var px = new Color32[n * n];
            var rng = new System.Random((int)id * 7919 + 13);
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float u = x / (float)n, v = y / (float)n;
                    Color c = Pixel(id, x, y, u, v, n, rng);
                    px[y * n + x] = c;
                }
            tex.SetPixels32(px);
            tex.Apply(true, true); // keep no CPU copy: saves memory on phones
            return tex;
        }

        static Color G(float g) { return new Color(g, g, g, 1f); }

        static Color Pixel(TexId id, int x, int y, float u, float v, int n, System.Random rng)
        {
            switch (id)
            {
                case TexId.Concrete:
                {
                    float g = 0.82f + (Noise(x, y, 0.15f, 3f) - 0.5f) * 0.18f + ((float)rng.NextDouble() - 0.5f) * 0.05f;
                    return G(g);
                }
                case TexId.Ballast:
                {
                    float g = 0.55f + (Noise(x, y, 0.45f, 9f) - 0.5f) * 0.5f + ((float)rng.NextDouble() - 0.5f) * 0.12f;
                    return new Color(g, g * 0.97f, g * 0.93f, 1f);
                }
                case TexId.Wood:
                {
                    float g = 0.72f + Mathf.Sin(v * 40f + Noise(x, y, 0.1f, 5f) * 6f) * 0.08f + ((float)rng.NextDouble() - 0.5f) * 0.04f;
                    return new Color(g, g * 0.85f, g * 0.7f, 1f);
                }
                case TexId.Metal:
                {
                    float g = 0.85f + (Noise(x, y, 0.2f, 1f) - 0.5f) * 0.1f;
                    if (x % 16 == 2 && (y % 32 == 4 || y % 32 == 28)) g -= 0.25f; // rivets
                    return G(g);
                }
                case TexId.Brick:
                {
                    int row = y / 8;
                    int off = (row % 2) * 8;
                    bool mortar = (y % 8 == 0) || (((x + off) % 16) == 0);
                    float g = mortar ? 0.55f : 0.9f + (Noise((x + off) / 16 * 16, row * 8, 0.3f, 2f) - 0.5f) * 0.2f;
                    return G(g);
                }
                case TexId.Tile:
                {
                    bool grout = (x % 32 < 2) || (y % 32 < 2);
                    float g = grout ? 0.5f : 0.92f + (Noise(x, y, 0.1f, 4f) - 0.5f) * 0.08f;
                    return G(g);
                }
                case TexId.Canvas:
                {
                    float weave = ((x + y) % 4 == 0) ? 0.93f : 1f;
                    return G(weave * (0.96f + (Noise(x, y, 0.3f, 6f) - 0.5f) * 0.06f));
                }
                case TexId.Window:
                {
                    // dark glass with a bright diagonal reflection and a light frame
                    bool frame = x < 3 || x >= n - 3 || y < 4 || y >= n - 4;
                    if (frame) return G(0.9f);
                    float refl = Mathf.Clamp01(1f - Mathf.Abs((u + v * 0.6f) - 0.55f) * 6f) * 0.25f;
                    return new Color(0.16f + refl, 0.24f + refl, 0.34f + refl, 1f);
                }
                case TexId.Facade:
                {
                    // 4 m x 4 m tile: wall (white, tinted by vertex colour) with two windows, lintels and a sill line.
                    float mx = u * 4f, my = v * 4f; // metres
                    bool win1 = mx > 0.45f && mx < 1.55f && my > 1.2f && my < 2.9f;
                    bool win2 = mx > 2.45f && mx < 3.55f && my > 1.2f && my < 2.9f;
                    bool frame1 = mx > 0.35f && mx < 1.65f && my > 1.1f && my < 3.0f;
                    bool frame2 = mx > 2.35f && mx < 3.65f && my > 1.1f && my < 3.0f;
                    bool sill = my > 1.0f && my < 1.1f && ((mx > 0.25f && mx < 1.75f) || (mx > 2.25f && mx < 3.75f));
                    float wall = 0.93f + (Noise(x, y, 0.08f, 11f) - 0.5f) * 0.1f;
                    if (win1) return (mx > 0.98f && mx < 1.02f) ? G(0.85f) : new Color(0.17f, 0.24f, 0.31f, 1f);
                    if (win2) // shuttered window (green shutters)
                        return ((int)((mx - 2.45f) * 22f) % 2 == 0) ? new Color(0.30f, 0.42f, 0.30f, 1f) : new Color(0.24f, 0.34f, 0.24f, 1f);
                    if (frame1 || frame2) return G(0.75f);
                    if (sill) return G(0.7f);
                    if (my > 3.55f && my < 3.65f) return G(0.78f);
                    return G(wall);
                }
                case TexId.Snow:
                {
                    float g = 0.93f + (Noise(x, y, 0.12f, 21f) - 0.5f) * 0.1f;
                    if (rng.NextDouble() < 0.012) g = 1f;                       // sparkle
                    return new Color(g * 0.97f, g * 0.99f, Mathf.Min(1f, g * 1.03f), 1f);
                }
                case TexId.Sand:
                {
                    float g = 0.9f + (Noise(x, y, 0.25f, 31f) - 0.5f) * 0.12f + ((float)rng.NextDouble() - 0.5f) * 0.08f;
                    return new Color(g, g * 0.95f, g * 0.84f, 1f);
                }
                case TexId.Asphalt:
                {
                    float g = 0.5f + (Noise(x, y, 0.3f, 17f) - 0.5f) * 0.2f + ((float)rng.NextDouble() - 0.5f) * 0.14f;
                    return new Color(g, g, g * 1.04f, 1f);
                }
                case TexId.FacadeNight:
                {
                    // 16 m x 16 m tile = 4 x 4 cells of 4 m, two windows per cell; some lit warm / cool / pink. Use with an emissive vertex colour.
                    int cell = n / 4, cx = x / cell, cy = y / cell;
                    float lx = (x % cell) / (float)cell, ly = (y % cell) / (float)cell;
                    Color wall = new Color(0.09f, 0.10f, 0.17f, 1f);
                    wall += new Color(1f, 1f, 1f, 0f) * ((Noise(x, y, 0.08f, 5f) - 0.5f) * 0.05f);
                    for (int w = 0; w < 2; w++)
                    {
                        float wx0 = 0.12f + w * 0.5f, wx1 = wx0 + 0.3f;
                        if (lx > wx0 && lx < wx1 && ly > 0.3f && ly < 0.78f)
                        {
                            var r2 = new System.Random((cx * 31 + cy * 17 + w * 7) * 7919 + 3);
                            double lit = r2.NextDouble(); double hue = r2.NextDouble();
                            if (lit < 0.55)
                            {
                                if (hue < 0.62) return new Color(1f, 0.82f, 0.45f, 1f);
                                if (hue < 0.82) return new Color(0.75f, 0.92f, 1f, 1f);
                                if (hue < 0.92) return new Color(1f, 0.5f, 0.78f, 1f);
                                return new Color(0.5f, 1f, 0.85f, 1f);
                            }
                            return new Color(0.06f, 0.08f, 0.14f, 1f);
                        }
                    }
                    if (ly > 0.84f && ly < 0.88f) return new Color(0.16f, 0.17f, 0.26f, 1f);
                    return wall;
                }
                default:
                    return Color.white;
            }
        }
    }
}
