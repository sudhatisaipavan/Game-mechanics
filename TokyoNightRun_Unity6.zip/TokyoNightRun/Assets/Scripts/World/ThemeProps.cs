using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Theme-specific obstacle dressing, collectible models, train decoration and freight loads for the non-Holi themes.
    /// Only the visuals live here: colliders and gameplay sizes stay in ProceduralFactory so every theme plays the same.
    /// All pivots are at ground level, x = 0 is the lane centre, z = 0 the object centre.
    /// </summary>
    public static class ThemeProps
    {
        static Color C(int rgb) { return GameConfig.Hex(rgb); }
        static Color G(int rgb, float a = 0f) { return ThemedEnvironment.Glow(rgb, a); }
        static Color G(Color c, float a = 0f) { return ThemedEnvironment.Glow(c, a); }
        static readonly Color Dark = new Color(0.14f, 0.14f, 0.16f, 1f);
        static readonly Color Snow = new Color(0.96f, 0.98f, 1f, 1f);
        static Color Steel() { return new Color(0.5f, 0.52f, 0.56f, 1f); }

        static void Gift(MeshBatcher b, Vector3 p, float s, Color box, Color ribbon)
        {
            b.Box(p + new Vector3(0, s * 0.5f, 0), Vector3.one * s, box);
            b.Box(p + new Vector3(0, s * 0.5f, 0), new Vector3(s * 1.03f, s * 1.03f, s * 0.2f), ribbon);
            b.Box(p + new Vector3(0, s * 0.5f, 0), new Vector3(s * 0.2f, s * 1.03f, s * 1.03f), ribbon);
            b.Sph(p + new Vector3(0, s * 1.08f, 0), s * 0.32f, ribbon);
        }

        static void Lantern(MeshBatcher b, Vector3 p, float k, int rgb)
        {
            b.Sph(p, new Vector3(0.42f, 0.55f, 0.42f) * k, G(rgb, 0.08f));
            b.Cyl(p + new Vector3(0, 0.3f * k, 0), 0.26f * k, 0.05f * k, C(0x212121));
            b.Cyl(p + new Vector3(0, -0.3f * k, 0), 0.26f * k, 0.05f * k, C(0x212121));
        }

        // =================================================================== OBSTACLES
        public static void Obstacle(ObstacleType type, MeshBatcher b, Color accent, System.Random rng)
        {
            switch (Theme.Current.Id)
            {
                case ThemeId.ClassicCity: ClassicObstacle(type, b, accent, rng); break;
                case ThemeId.WinterHoliday: WinterObstacle(type, b, accent, rng); break;
                case ThemeId.TokyoNight: TokyoObstacle(type, b, accent, rng); break;
                default: MiamiObstacle(type, b, accent, rng); break;
            }
        }

        // ---------------------------------------------------------------- classic
        static void ClassicObstacle(ObstacleType type, MeshBatcher b, Color accent, System.Random rng)
        {
            switch (type)
            {
                case ObstacleType.Cart: // green dumpster with overflowing bags (Solid)
                    b.Box(new Vector3(0, 0.75f, 0), new Vector3(1.6f, 1.1f, 2.2f), C(0x2E7D32), default(Vector3), TexId.Metal, 1.5f);
                    b.Box(new Vector3(0, 1.36f, 0.2f), new Vector3(1.7f, 0.12f, 1.6f), C(0x1B5E20));
                    b.Box(new Vector3(0, 1.62f, -0.95f), new Vector3(1.7f, 0.1f, 0.9f), C(0x1B5E20), new Vector3(-55, 0, 0));
                    for (int sx = -1; sx <= 1; sx += 2) for (int sz = -1; sz <= 1; sz += 2) b.Wheel(new Vector3(0.82f * sx, 0.2f, 0.8f * sz), 0.2f, 0.1f, Dark);
                    for (int i = 0; i < 3; i++) b.Sph(new Vector3(-0.4f + i * 0.4f, 1.75f, 0.35f), new Vector3(0.5f, 0.45f, 0.5f), i == 1 ? C(0x37474F) : C(0x212121));
                    b.Box(new Vector3(0, 0.75f, -1.11f), new Vector3(1.3f, 0.3f, 0.03f), accent);
                    b.Box(new Vector3(0, 1.0f, 0), new Vector3(1.64f, 0.12f, 2.24f), accent);
                    break;
                case ObstacleType.Barricade: // road barrier with warning lamp (Low)
                    b.Box(new Vector3(-0.8f, 0.4f, 0), new Vector3(0.1f, 0.8f, 0.1f), Dark);
                    b.Box(new Vector3(0.8f, 0.4f, 0), new Vector3(0.1f, 0.8f, 0.1f), Dark);
                    for (int i = 0; i < 6; i++) b.Box(new Vector3(-0.8f + i * 0.32f, 0.62f, 0), new Vector3(0.32f, 0.2f, 0.12f), i % 2 == 0 ? C(0xFF6F00) : Color.white);
                    b.Box(new Vector3(0, 0.36f, 0), new Vector3(1.9f, 0.2f, 0.12f), Color.white);
                    b.Sph(new Vector3(0.8f, 0.9f, 0), 0.16f, new Color(1f, 0.2f, 0.1f, 0f));
                    break;
                case ObstacleType.Trolley: // luggage trolley with suitcases (Low)
                    b.Box(new Vector3(0, 0.38f, 0), new Vector3(1.0f, 0.1f, 1.6f), Steel());
                    b.Wheel(new Vector3(0.5f, 0.2f, 0.55f), 0.2f, 0.1f, Dark); b.Wheel(new Vector3(-0.5f, 0.2f, 0.55f), 0.2f, 0.1f, Dark);
                    b.Wheel(new Vector3(0.5f, 0.2f, -0.55f), 0.2f, 0.1f, Dark); b.Wheel(new Vector3(-0.5f, 0.2f, -0.55f), 0.2f, 0.1f, Dark);
                    b.Box(new Vector3(0, 0.95f, -0.85f), new Vector3(0.9f, 0.06f, 0.06f), Steel());
                    b.Box(new Vector3(-0.2f, 0.7f, 0.1f), new Vector3(0.6f, 0.5f, 0.9f), Theme.Pal(0));
                    b.Box(new Vector3(0.28f, 0.62f, 0.2f), new Vector3(0.5f, 0.35f, 0.7f), Theme.Pal(2));
                    b.Box(new Vector3(0, 1.05f, 0.15f), new Vector3(0.5f, 0.28f, 0.6f), accent);
                    break;
                case ObstacleType.Puddle: // oily rain puddle (Slow)
                    b.Cyl(new Vector3(0, 0.02f, 0), 1.8f, 0.02f, C(0x2B3A55));
                    b.Cyl(new Vector3(0, 0.035f, 0), 1.2f, 0.02f, C(0x5C7AA8));
                    b.Cyl(new Vector3(0.2f, 0.045f, 0.1f), 0.5f, 0.02f, accent * 0.9f);
                    break;
                case ObstacleType.Banner: // overhead road sign (High, slide under)
                    b.Box(new Vector3(-1.0f, 1.4f, 0), new Vector3(0.1f, 2.8f, 0.1f), Steel());
                    b.Box(new Vector3(1.0f, 1.4f, 0), new Vector3(0.1f, 2.8f, 0.1f), Steel());
                    b.Box(new Vector3(0, 2.4f, 0), new Vector3(2.1f, 0.1f, 0.1f), Steel());
                    b.Box(new Vector3(0, 1.9f, 0), new Vector3(1.9f, 0.9f, 0.05f), C(0x1565C0));
                    b.Box(new Vector3(0, 1.9f, -0.03f), new Vector3(1.7f, 0.7f, 0.04f), Color.white);
                    b.Box(new Vector3(0, 1.9f, -0.06f), new Vector3(1.5f, 0.5f, 0.03f), C(0x1565C0));
                    for (int i = 0; i < 4; i++) b.Box(new Vector3(-0.55f + i * 0.37f, 1.9f, -0.09f), new Vector3(0.22f, 0.3f, 0.02f), i == 1 ? accent : Color.white);
                    b.Sph(new Vector3(0, 2.62f, 0), 0.2f, new Color(1f, 0.15f, 0.1f, 0f));
                    break;
                default: // crates with tyres and paint cans (Solid)
                    b.Box(new Vector3(0, 0.33f, 0), new Vector3(1.3f, 0.65f, 1.3f), C(0xA1887F), default(Vector3), TexId.Wood, 1f);
                    b.Box(new Vector3(0.05f, 0.98f, 0), new Vector3(1.2f, 0.65f, 1.2f), C(0x8D6E63), default(Vector3), TexId.Wood, 1f);
                    for (int i = 0; i < 3; i++) b.Cyl(new Vector3(0, 1.43f + i * 0.2f, 0), 0.9f - i * 0.04f, 0.2f, C(0x212121));
                    b.Cyl(new Vector3(0, 1.85f, 0), 0.4f, 0.1f, C(0x607D8B));
                    b.Cyl(new Vector3(0.3f, 2.0f, 0.2f), 0.28f, 0.3f, accent); b.Cyl(new Vector3(-0.3f, 2.0f, -0.2f), 0.28f, 0.3f, Theme.Pal(2));
                    b.Box(new Vector3(0, 0.98f, -0.62f), new Vector3(0.6f, 0.3f, 0.03f), accent);
                    break;
            }
        }

        // ---------------------------------------------------------------- winter
        static void WinterObstacle(ObstacleType type, MeshBatcher b, Color accent, System.Random rng)
        {
            switch (type)
            {
                case ObstacleType.Cart: // sleigh stacked with presents (Solid)
                    b.Box(new Vector3(0, 0.62f, 0.1f), new Vector3(1.3f, 0.5f, 1.9f), C(0xC62828), default(Vector3), TexId.Canvas, 1f);
                    b.Box(new Vector3(0, 0.95f, -0.9f), new Vector3(1.3f, 0.7f, 0.2f), C(0xC62828), new Vector3(-25, 0, 0));
                    for (int e = -1; e <= 1; e += 2)
                    {
                        b.Box(new Vector3(e * 0.55f, 0.15f, 0.1f), new Vector3(0.1f, 0.1f, 2.4f), C(0xFFC107));
                        b.Box(new Vector3(e * 0.55f, 0.4f, -1.2f), new Vector3(0.1f, 0.45f, 0.1f), C(0xFFC107));
                    }
                    Gift(b, new Vector3(-0.3f, 0.87f, 0.4f), 0.7f, Theme.Pal(1), Theme.Pal(3));
                    Gift(b, new Vector3(0.3f, 0.87f, -0.1f), 0.6f, Theme.Pal(2), Color.white);
                    Gift(b, new Vector3(-0.05f, 1.57f, 0.2f), 0.55f, Theme.Pal(4), Theme.Pal(0));
                    b.Sph(new Vector3(0, 1.3f, 0.8f), new Vector3(0.9f, 0.9f, 0.8f), C(0x8D5A2B));
                    b.Sph(new Vector3(0, 2.0f, 0.2f), 0.2f, G(0xFFD54F));
                    break;
                case ObstacleType.Barricade: // candy-cane picket fence with snow (Low)
                    for (int i = 0; i < 8; i++) b.Box(new Vector3(-0.85f + i * 0.243f, 0.4f, 0), new Vector3(0.17f, 0.8f, 0.07f), i % 2 == 0 ? C(0xE53935) : Color.white);
                    b.Box(new Vector3(0, 0.6f, 0.06f), new Vector3(2.0f, 0.1f, 0.06f), C(0x6D4C41));
                    b.Box(new Vector3(0, 0.25f, 0.06f), new Vector3(2.0f, 0.1f, 0.06f), C(0x6D4C41));
                    b.Box(new Vector3(0, 0.84f, 0), new Vector3(2.0f, 0.1f, 0.16f), Snow);
                    b.Sph(new Vector3(0.9f, 0.95f, 0), 0.16f, G(0xFF5252)); b.Sph(new Vector3(-0.9f, 0.95f, 0), 0.16f, C(0x2E7D32));
                    break;
                case ObstacleType.Trolley: // toboggan with gifts (Low)
                    b.Box(new Vector3(0, 0.3f, 0), new Vector3(0.9f, 0.1f, 1.6f), C(0x8D5A2B), default(Vector3), TexId.Wood, 1f);
                    for (int e = -1; e <= 1; e += 2) { b.Box(new Vector3(e * 0.4f, 0.15f, 0), new Vector3(0.08f, 0.08f, 1.9f), C(0xB0BEC5)); b.Box(new Vector3(e * 0.4f, 0.22f, 0.95f), new Vector3(0.08f, 0.24f, 0.08f), C(0xB0BEC5)); }
                    Gift(b, new Vector3(-0.2f, 0.35f, 0.2f), 0.5f, Theme.Pal(0), Theme.Pal(3));
                    Gift(b, new Vector3(0.22f, 0.35f, -0.2f), 0.45f, Theme.Pal(2), Color.white);
                    Gift(b, new Vector3(0, 0.82f, 0f), 0.4f, Theme.Pal(1), Theme.Pal(4));
                    b.Box(new Vector3(0, 0.55f, 0.8f), new Vector3(0.6f, 0.06f, 0.06f), C(0x5D4037));
                    break;
                case ObstacleType.Puddle: // slippery ice patch (Slow)
                    b.Cyl(new Vector3(0, 0.02f, 0), 1.8f, 0.02f, C(0xA8DCF5));
                    b.Cyl(new Vector3(0, 0.035f, 0), 1.3f, 0.02f, C(0xD6F1FF));
                    b.Box(new Vector3(0, 0.05f, 0), new Vector3(0.05f, 0.01f, 1.2f), Color.white, new Vector3(0, 30, 0));
                    b.Box(new Vector3(0, 0.05f, 0), new Vector3(0.05f, 0.01f, 1.0f), Color.white, new Vector3(0, -50, 0));
                    break;
                case ObstacleType.Banner: // candy-cane gate with garland and icicles (High)
                    for (int e = -1; e <= 1; e += 2) for (int i = 0; i < 10; i++) b.Cyl(new Vector3(e * 1.0f, 0.14f + i * 0.28f, 0), 0.2f, 0.28f, i % 2 == 0 ? C(0xE53935) : Color.white);
                    b.Box(new Vector3(0, 2.5f, 0), new Vector3(2.2f, 0.22f, 0.3f), C(0x1F6B45));
                    b.Garland(new Vector3(-1.0f, 2.35f, -0.05f), new Vector3(1.0f, 2.35f, -0.05f), 0.45f, 12, 0.2f, G(0xE53935, 0.1f), G(0xFFD54F, 0.1f));
                    for (int i = 0; i < 7; i++) b.Cyl(new Vector3(-0.9f + i * 0.3f, 2.0f - (i % 2) * 0.12f, -0.05f), 0.1f, 0.5f + (i % 2) * 0.25f, C(0xCDEBFF));
                    b.Sph(new Vector3(0, 1.75f, -0.05f), 0.3f, accent);
                    break;
                default: // tower of presents (Solid)
                    Gift(b, new Vector3(0, 0, 0), 1.3f, Theme.Pal(0), Theme.Pal(3));
                    Gift(b, new Vector3(0.05f, 1.3f, 0), 1.0f, Theme.Pal(1), Color.white);
                    Gift(b, new Vector3(-0.03f, 2.3f, 0), 0.7f, Theme.Pal(2), Theme.Pal(0));
                    b.Box(new Vector3(0, 3.1f, 0), new Vector3(0.5f, 0.12f, 0.12f), G(0xFFD54F), new Vector3(0, 0, 45));
                    b.Box(new Vector3(0, 3.1f, 0), new Vector3(0.5f, 0.12f, 0.12f), G(0xFFD54F), new Vector3(0, 0, -45));
                    break;
            }
        }

        // ---------------------------------------------------------------- tokyo
        static void TokyoObstacle(ObstacleType type, MeshBatcher b, Color accent, System.Random rng)
        {
            switch (type)
            {
                case ObstacleType.Cart: // two glowing vending machines (Solid)
                    for (int i = 0; i < 2; i++)
                    {
                        float z = -0.62f + i * 1.24f; Color gl = i == 0 ? Theme.Pal(1) : accent;
                        b.Box(new Vector3(0, 0.98f, z), new Vector3(1.5f, 1.95f, 1.0f), C(0x2B2F3A));
                        b.Box(new Vector3(0, 1.2f, z - 0.51f), new Vector3(1.2f, 1.3f, 0.04f), G(gl, 0.12f));
                        for (int k = 0; k < 3; k++) for (int j = 0; j < 4; j++) b.Box(new Vector3(-0.42f + j * 0.28f, 1.65f - k * 0.38f, z - 0.54f), new Vector3(0.16f, 0.26f, 0.03f), G(Theme.Pal(j + k + i), 0.05f));
                        b.Box(new Vector3(0, 0.3f, z - 0.52f), new Vector3(0.6f, 0.2f, 0.04f), C(0x0D0D0D));
                        b.Box(new Vector3(0, 1.97f, z), new Vector3(1.4f, 0.06f, 0.9f), G(gl, 0f));
                    }
                    break;
                case ObstacleType.Barricade: // roadworks barrier with arrow board (Low)
                    for (int e = -1; e <= 1; e += 2) b.Box(new Vector3(e * 0.8f, 0.2f, 0), new Vector3(0.1f, 0.4f, 0.5f), Dark);
                    for (int i = 0; i < 6; i++) b.Box(new Vector3(-0.85f + i * 0.34f, 0.62f, 0), new Vector3(0.34f, 0.3f, 0.1f), i % 2 == 0 ? C(0xFFD400) : Dark);
                    b.Box(new Vector3(0, 0.38f, 0), new Vector3(1.9f, 0.12f, 0.1f), Color.white);
                    for (int e = -1; e <= 1; e += 2) { b.Cyl(new Vector3(e * 0.95f, 0.3f, 0.2f), 0.4f, 0.6f, C(0xFF5A1F)); b.Cyl(new Vector3(e * 0.95f, 0.38f, 0.2f), 0.3f, 0.08f, Color.white); b.Sph(new Vector3(e * 0.95f, 0.85f, 0.2f), 0.14f, G(0xFF6A00)); }
                    b.Box(new Vector3(0, 0.95f, 0), new Vector3(0.7f, 0.18f, 0.06f), G(0xFF6A00, 0.05f));
                    break;
                case ObstacleType.Trolley: // delivery cart with boxes and a lantern (Low)
                    b.Box(new Vector3(0, 0.4f, 0), new Vector3(1.0f, 0.12f, 1.6f), C(0x607D8B));
                    for (int sx = -1; sx <= 1; sx += 2) for (int sz = -1; sz <= 1; sz += 2) b.Wheel(new Vector3(0.5f * sx, 0.18f, 0.6f * sz), 0.18f, 0.1f, Dark);
                    b.Box(new Vector3(-0.2f, 0.7f, 0.2f), new Vector3(0.6f, 0.5f, 0.7f), C(0xC9A26B), default(Vector3), TexId.Canvas, 1f);
                    b.Box(new Vector3(0.25f, 0.65f, -0.2f), new Vector3(0.5f, 0.4f, 0.6f), C(0xB88B54), default(Vector3), TexId.Canvas, 1f);
                    b.Box(new Vector3(0, 1.0f, 0.1f), new Vector3(0.45f, 0.2f, 0.5f), G(accent, 0.15f));
                    Lantern(b, new Vector3(0.45f, 0.95f, 0.7f), 0.7f, 0xFF3D3D);
                    b.Box(new Vector3(0, 0.95f, -0.85f), new Vector3(0.9f, 0.06f, 0.06f), Steel());
                    break;
                case ObstacleType.Puddle: // neon-reflecting rain puddle (Slow)
                    b.Cyl(new Vector3(0, 0.02f, 0), 1.8f, 0.02f, C(0x141A33));
                    b.Cyl(new Vector3(-0.2f, 0.035f, 0.1f), 1.1f, 0.02f, G(Theme.Pal(0), 0.55f));
                    b.Cyl(new Vector3(0.3f, 0.045f, -0.1f), 0.8f, 0.02f, G(Theme.Pal(1), 0.5f));
                    break;
                case ObstacleType.Banner: // torii-style gate with shimenawa rope (High)
                    for (int e = -1; e <= 1; e += 2) b.Cyl(new Vector3(e * 0.98f, 1.4f, 0), 0.22f, 2.8f, G(0xE53935, 0.6f));
                    b.Box(new Vector3(0, 2.72f, 0), new Vector3(2.6f, 0.2f, 0.4f), C(0x1A1A1A));
                    b.Box(new Vector3(0, 2.5f, 0), new Vector3(2.2f, 0.16f, 0.28f), G(0xE53935, 0.6f));
                    b.Prim(PrimKind.Cylinder, new Vector3(0, 2.1f, 0), new Vector3(0.22f, 2.0f, 0.22f), C(0xF1E6C8), new Vector3(0, 0, 90));
                    for (int i = 0; i < 5; i++) b.Box(new Vector3(-0.8f + i * 0.4f, 1.85f, 0), new Vector3(0.16f, 0.36f, 0.03f), Color.white, new Vector3(0, 0, (i % 2) * 8f));
                    Lantern(b, new Vector3(-0.55f, 1.55f, -0.05f), 0.9f, 0xFF3D3D); Lantern(b, new Vector3(0.55f, 1.55f, -0.05f), 0.9f, 0xFF3D3D);
                    b.Box(new Vector3(0, 1.75f, -0.1f), new Vector3(0.5f, 0.6f, 0.06f), G(accent, 0.08f));
                    break;
                default: // neon-labelled crate stack with a lantern (Solid)
                    b.Box(new Vector3(0, 0.33f, 0), new Vector3(1.3f, 0.65f, 1.3f), C(0xB88B54), default(Vector3), TexId.Canvas, 1f);
                    b.Box(new Vector3(0.05f, 0.98f, 0), new Vector3(1.2f, 0.65f, 1.2f), C(0xA67C45), default(Vector3), TexId.Canvas, 1f);
                    b.Box(new Vector3(-0.03f, 1.63f, 0), new Vector3(1.1f, 0.62f, 1.1f), C(0xB88B54), default(Vector3), TexId.Canvas, 1f);
                    for (int i = 0; i < 3; i++) b.Box(new Vector3(0, 0.33f + i * 0.65f, -0.67f), new Vector3(0.7f, 0.3f, 0.03f), G(Theme.Pal(i * 2 + 1), 0.05f));
                    Lantern(b, new Vector3(0, 2.25f, 0), 1.0f, 0xFF3D3D);
                    break;
            }
        }

        // ---------------------------------------------------------------- miami
        static void MiamiObstacle(ObstacleType type, MeshBatcher b, Color accent, System.Random rng)
        {
            switch (type)
            {
                case ObstacleType.Cart: // ice-cream cart under a striped parasol (Solid)
                    b.Box(new Vector3(0, 0.75f, 0), new Vector3(1.3f, 1.0f, 1.8f), C(0xFF8FB8), default(Vector3), TexId.Canvas, 1f);
                    b.Box(new Vector3(0, 0.45f, 0), new Vector3(1.32f, 0.4f, 1.82f), Color.white);
                    for (int sx = -1; sx <= 1; sx += 2) for (int sz = -1; sz <= 1; sz += 2) b.Wheel(new Vector3(0.7f * sx, 0.28f, 0.7f * sz), 0.28f, 0.1f, Dark);
                    b.Box(new Vector3(0, 1.3f, -0.92f), new Vector3(1.0f, 0.4f, 0.04f), G(0x00E5FF, 0.15f));
                    b.Cyl(new Vector3(0, 1.5f, 0), 0.07f, 1.0f, Color.white);
                    for (int i = 0; i < 8; i++) { float a = i * Mathf.PI / 4f; b.Box(new Vector3(Mathf.Cos(a) * 0.55f, 2.0f, Mathf.Sin(a) * 0.55f), new Vector3(0.5f, 0.06f, 1.1f), i % 2 == 0 ? Theme.Pal(0) : Color.white, new Vector3(8, -a * Mathf.Rad2Deg + 90f, 0)); }
                    b.Prim(PrimKind.Cylinder, new Vector3(0, 2.05f, 0), new Vector3(0.3f, 0.12f, 0.3f), Theme.Pal(0));
                    b.Sph(new Vector3(0.3f, 1.35f, 0.3f), 0.32f, Theme.Pal(2)); b.Sph(new Vector3(-0.3f, 1.35f, 0.3f), 0.32f, Theme.Pal(1));
                    break;
                case ObstacleType.Barricade: // striped beach barrier with flag (Low)
                    for (int e = -1; e <= 1; e += 2) b.Box(new Vector3(e * 0.85f, 0.4f, 0), new Vector3(0.1f, 0.8f, 0.1f), C(0xEFEBE9));
                    for (int i = 0; i < 6; i++) b.Box(new Vector3(-0.85f + i * 0.34f, 0.6f, 0), new Vector3(0.34f, 0.3f, 0.1f), i % 3 == 0 ? Theme.Pal(0) : i % 3 == 1 ? Color.white : Theme.Pal(1));
                    b.Box(new Vector3(0, 0.3f, 0), new Vector3(1.9f, 0.14f, 0.1f), C(0xE0B887));
                    b.Box(new Vector3(0.85f, 1.0f, 0), new Vector3(0.05f, 0.5f, 0.05f), C(0xEFEBE9));
                    b.Box(new Vector3(0.85f - 0.2f, 1.15f, 0), new Vector3(0.4f, 0.22f, 0.03f), G(0xFFB300, 0.1f));
                    break;
                case ObstacleType.Trolley: // cooler cart with beach ball (Low)
                    b.Box(new Vector3(0, 0.38f, 0), new Vector3(1.0f, 0.1f, 1.6f), C(0x607D8B));
                    for (int sx = -1; sx <= 1; sx += 2) for (int sz = -1; sz <= 1; sz += 2) b.Wheel(new Vector3(0.5f * sx, 0.2f, 0.6f * sz), 0.2f, 0.1f, Dark);
                    b.Box(new Vector3(-0.2f, 0.7f, 0.2f), new Vector3(0.6f, 0.5f, 0.8f), C(0x29B6F6)); b.Box(new Vector3(-0.2f, 0.98f, 0.2f), new Vector3(0.64f, 0.08f, 0.84f), Color.white);
                    b.Box(new Vector3(0.28f, 0.65f, -0.15f), new Vector3(0.5f, 0.4f, 0.6f), Theme.Pal(0)); b.Box(new Vector3(0.28f, 0.87f, -0.15f), new Vector3(0.54f, 0.06f, 0.64f), Color.white);
                    b.Sph(new Vector3(0, 1.1f, 0.55f), 0.42f, Color.white); b.Cyl(new Vector3(0, 1.1f, 0.55f), 0.43f, 0.1f, Theme.Pal(2));
                    b.Box(new Vector3(0, 0.95f, -0.85f), new Vector3(0.9f, 0.06f, 0.06f), Steel());
                    break;
                case ObstacleType.Puddle: // tide pool with foam (Slow)
                    b.Cyl(new Vector3(0, 0.02f, 0), 1.8f, 0.02f, C(0x12C2D8));
                    b.Cyl(new Vector3(0, 0.035f, 0), 1.2f, 0.02f, C(0x7FE9F0));
                    for (int i = 0; i < 6; i++) { float a = i * 1.05f; b.Sph(new Vector3(Mathf.Cos(a) * 0.85f, 0.05f, Mathf.Sin(a) * 0.85f), new Vector3(0.35f, 0.05f, 0.25f), Color.white); }
                    break;
                case ObstacleType.Banner: // surf-shop sign between bamboo poles (High)
                    for (int e = -1; e <= 1; e += 2) { b.Cyl(new Vector3(e * 1.0f, 1.4f, 0), 0.14f, 2.8f, C(0xC9A66B)); b.Sph(new Vector3(e * 1.0f, 2.85f, 0), 0.2f, C(0x2E9E4F)); }
                    b.Box(new Vector3(0, 2.45f, 0), new Vector3(2.2f, 0.1f, 0.1f), C(0xC9A66B));
                    b.Box(new Vector3(0, 1.9f, 0), new Vector3(1.9f, 0.9f, 0.07f), C(0x00BFB3));
                    for (int i = 0; i < 3; i++) b.Box(new Vector3(0, 1.62f + i * 0.2f, -0.05f), new Vector3(1.8f, 0.09f, 0.03f), i == 1 ? Color.white : C(0xFF4F9A));
                    b.Prim(PrimKind.Cylinder, new Vector3(-0.5f, 1.95f, -0.06f), new Vector3(0.45f, 0.04f, 0.45f), G(0xFFB300, 0.1f), new Vector3(90, 0, 0));
                    b.Box(new Vector3(0.35f, 1.95f, -0.06f), new Vector3(0.7f, 0.3f, 0.03f), G(0xFFF3C4, 0.1f));
                    b.Garland(new Vector3(-0.95f, 1.5f, -0.05f), new Vector3(0.95f, 1.5f, -0.05f), 0.25f, 10, 0.1f, G(0xFFE29A, 0.1f), G(0xFF9AC4, 0.1f));
                    break;
                default: // tropical fruit crates (Solid)
                    b.Box(new Vector3(0, 0.33f, 0), new Vector3(1.3f, 0.65f, 1.3f), C(0xD9B27C), default(Vector3), TexId.Wood, 1f);
                    b.Box(new Vector3(0.05f, 0.98f, 0), new Vector3(1.2f, 0.65f, 1.2f), C(0xC9A06C), default(Vector3), TexId.Wood, 1f);
                    b.Box(new Vector3(-0.03f, 1.63f, 0), new Vector3(1.1f, 0.62f, 1.1f), C(0xD9B27C), default(Vector3), TexId.Wood, 1f);
                    for (int i = 0; i < 3; i++) { b.Sph(new Vector3(-0.3f + i * 0.3f, 2.15f, 0), new Vector3(0.36f, 0.46f, 0.36f), C(0xFFC400)); b.Box(new Vector3(-0.3f + i * 0.3f, 2.5f, 0), new Vector3(0.08f, 0.3f, 0.08f), C(0x2E9E4F)); }
                    b.Sph(new Vector3(0.45f, 2.0f, 0.3f), 0.3f, C(0x6D4C41));
                    b.Box(new Vector3(0, 0.98f, -0.62f), new Vector3(0.6f, 0.3f, 0.03f), Theme.Pal(0));
                    break;
            }
        }

        // =================================================================== COLLECTIBLES
        /// <summary>Energy pickup A (spray can / snowflake / paper lantern / seashell). Collider is added by the caller.</summary>
        public static void PickupA(MeshBatcher b, Color c)
        {
            switch (Theme.Current.Id)
            {
                case ThemeId.ClassicCity:
                    b.Cyl(new Vector3(0, 0.6f, 0), 0.26f, 0.55f, c);
                    b.Cyl(new Vector3(0, 0.9f, 0), 0.2f, 0.12f, C(0x37474F));
                    b.Box(new Vector3(0, 1.0f, 0), new Vector3(0.08f, 0.1f, 0.1f), Color.white);
                    b.Cyl(new Vector3(0, 0.6f, 0), 0.28f, 0.16f, Color.white);
                    b.Sph(new Vector3(0, 0.6f, -0.14f), new Vector3(0.14f, 0.14f, 0.02f), G(c, 0.2f));
                    break;
                case ThemeId.WinterHoliday:
                    for (int i = 0; i < 3; i++) b.Box(new Vector3(0, 0.75f, 0), new Vector3(0.8f, 0.09f, 0.07f), G(0xE1F5FE, 0.15f), new Vector3(0, 0, i * 60f));
                    for (int i = 0; i < 6; i++) { float a = i * 60f * Mathf.Deg2Rad; b.Sph(new Vector3(Mathf.Cos(a) * 0.4f, 0.75f + Mathf.Sin(a) * 0.4f, 0), 0.11f, G(c, 0.2f)); }
                    b.Sph(new Vector3(0, 0.75f, 0), 0.2f, G(0xFFFFFF, 0f));
                    break;
                case ThemeId.TokyoNight:
                    Lantern(b, new Vector3(0, 0.75f, 0), 1.0f, ((int)(c.r * 255) << 16) | ((int)(c.g * 255) << 8) | (int)(c.b * 255));
                    b.Box(new Vector3(0, 1.1f, 0), new Vector3(0.03f, 0.2f, 0.03f), C(0x212121));
                    b.Box(new Vector3(0, 0.45f, 0), new Vector3(0.03f, 0.2f, 0.03f), G(0xFFEA00));
                    break;
                default: // seashell
                    b.Sph(new Vector3(0, 0.7f, 0), new Vector3(0.55f, 0.5f, 0.16f), c);
                    for (int i = 0; i < 5; i++) b.Box(new Vector3((i - 2) * 0.08f, 0.72f, -0.08f), new Vector3(0.035f, 0.42f, 0.03f), Color.Lerp(c, Color.white, 0.55f), new Vector3(0, 0, (i - 2) * -18f));
                    b.Box(new Vector3(0, 0.44f, 0), new Vector3(0.16f, 0.1f, 0.14f), Color.Lerp(c, Color.white, 0.3f));
                    b.Sph(new Vector3(0, 0.7f, -0.12f), 0.1f, G(0xFFFFFF, 0.3f));
                    break;
            }
        }

        /// <summary>Energy pickup B (soda can / ornament / onigiri / beach ball).</summary>
        public static void PickupB(MeshBatcher b, Color c)
        {
            switch (Theme.Current.Id)
            {
                case ThemeId.ClassicCity:
                    b.Cyl(new Vector3(0, 0.65f, 0), 0.3f, 0.52f, c);
                    b.Cyl(new Vector3(0, 0.93f, 0), 0.26f, 0.05f, C(0xCFD8DC));
                    b.Cyl(new Vector3(0, 0.65f, 0), 0.31f, 0.18f, Color.white);
                    b.Box(new Vector3(0.05f, 0.98f, 0), new Vector3(0.14f, 0.03f, 0.04f), C(0x90A4AE));
                    b.Sph(new Vector3(-0.08f, 0.8f, -0.13f), 0.07f, new Color(1f, 1f, 1f, 0.3f));
                    break;
                case ThemeId.WinterHoliday:
                    b.Sph(new Vector3(0, 0.65f, 0), 0.5f, c);
                    b.Cyl(new Vector3(0, 0.65f, 0), 0.51f, 0.08f, Color.white);
                    b.Cyl(new Vector3(0, 0.93f, 0), 0.16f, 0.1f, C(0xFFC107));
                    b.Box(new Vector3(0, 1.03f, 0), new Vector3(0.14f, 0.04f, 0.02f), C(0xFFC107));
                    b.Sph(new Vector3(-0.12f, 0.8f, -0.2f), 0.12f, new Color(1f, 1f, 1f, 0.3f));
                    break;
                case ThemeId.TokyoNight:
                    b.Prim(PrimKind.Wedge, new Vector3(0, 0.65f, 0), new Vector3(0.7f, 0.62f, 0.34f), Color.white);
                    b.Box(new Vector3(0, 0.48f, -0.1f), new Vector3(0.34f, 0.28f, 0.16f), C(0x1B5E3A));
                    b.Sph(new Vector3(0, 0.7f, -0.17f), 0.1f, G(c, 0.3f));
                    b.Sph(new Vector3(0, 0.65f, 0), 0.0001f, G(c, 0f));
                    break;
                default: // beach ball
                    b.Sph(new Vector3(0, 0.65f, 0), 0.55f, Color.white);
                    b.Cyl(new Vector3(0, 0.65f, 0), 0.56f, 0.12f, c);
                    b.Cyl(new Vector3(0, 0.9f, 0), 0.3f, 0.05f, Theme.Pal(1));
                    b.Cyl(new Vector3(0, 0.4f, 0), 0.3f, 0.05f, Theme.Pal(2));
                    b.Sph(new Vector3(-0.12f, 0.82f, -0.2f), 0.1f, new Color(1f, 1f, 1f, 0.3f));
                    break;
            }
        }

        /// <summary>Rare bonus token (golden key / star / lucky coin / sun).</summary>
        public static void Token(MeshBatcher b)
        {
            Color gold = new Color(1f, 0.84f, 0.2f, 0.12f);
            switch (Theme.Current.Id)
            {
                case ThemeId.ClassicCity:
                    b.Cyl(new Vector3(0, 1.05f, 0), 0.42f, 0.08f, gold, new Vector3(90, 0, 0));
                    b.Cyl(new Vector3(0, 1.05f, 0), 0.2f, 0.1f, C(0x7C4DFF), new Vector3(90, 0, 0));
                    b.Box(new Vector3(0, 0.6f, 0), new Vector3(0.12f, 0.75f, 0.08f), gold);
                    b.Box(new Vector3(0.12f, 0.35f, 0), new Vector3(0.2f, 0.1f, 0.08f), gold);
                    b.Box(new Vector3(0.1f, 0.55f, 0), new Vector3(0.16f, 0.1f, 0.08f), gold);
                    break;
                case ThemeId.WinterHoliday:
                    for (int i = 0; i < 5; i++) b.Box(new Vector3(0, 0.8f, 0), new Vector3(0.14f, 0.85f, 0.1f), gold, new Vector3(0, 0, i * 72f));
                    b.Sph(new Vector3(0, 0.8f, 0), 0.3f, G(0xFFF59D));
                    break;
                case ThemeId.TokyoNight:
                    b.Sph(new Vector3(0, 0.8f, 0), new Vector3(0.7f, 0.85f, 0.14f), gold);
                    b.Cyl(new Vector3(0, 0.8f, 0), 0.5f, 0.05f, G(0xFF2E93, 0.2f), new Vector3(90, 0, 0));
                    b.Box(new Vector3(0, 0.8f, -0.1f), new Vector3(0.18f, 0.4f, 0.04f), C(0xB71C1C));
                    break;
                default:
                    b.Sph(new Vector3(0, 0.8f, 0), 0.55f, G(0xFFB300, 0.1f));
                    for (int i = 0; i < 8; i++) b.Box(new Vector3(0, 0.8f, 0), new Vector3(0.12f, 1.0f, 0.08f), G(0xFF7A45, 0.1f), new Vector3(0, 0, i * 22.5f));
                    break;
            }
        }

        // =================================================================== TRAINS
        /// <summary>Theme dressing for a coach (replaces the Holi hand-prints and marigold garlands).</summary>
        public static void CoachDecor(MeshBatcher b, float L, bool loco, System.Random rng)
        {
            float h = L * 0.5f;
            switch (Theme.Current.Id)
            {
                case ThemeId.ClassicCity:
                    for (int s = -1; s <= 1; s += 2)
                        for (int k = -1; k <= 1; k += 2)
                        {
                            Color c = Theme.Pal(k + s + 3);
                            b.Prim(PrimKind.Cylinder, new Vector3(s * 1.03f, 2.95f, k * (L * 0.3f)), new Vector3(0.5f, 0.04f, 0.5f), c, new Vector3(0, 0, 90));
                            b.Prim(PrimKind.Cylinder, new Vector3(s * 1.05f, 2.95f, k * (L * 0.3f)), new Vector3(0.34f, 0.04f, 0.34f), Color.white, new Vector3(0, 0, 90));
                        }
                    for (int i = 0; i < 2; i++) b.Box(new Vector3(0, 3.78f, -h + L * (0.3f + 0.4f * i)), new Vector3(1.0f, 0.3f, 0.9f), C(0x9AA3AD), default(Vector3), TexId.Metal, 1f);
                    break;
                case ThemeId.WinterHoliday:
                    b.Box(new Vector3(0, 3.66f, 0), new Vector3(1.55f, 0.12f, L - 0.6f), Snow, default(Vector3), TexId.Snow, 2f);
                    for (int s = -1; s <= 1; s += 2)
                    {
                        for (float z = -h + 0.6f; z < h - 0.5f; z += 0.5f) b.Cyl(new Vector3(s * 0.88f, 3.36f, z), 0.08f, 0.2f + (float)rng.NextDouble() * 0.15f, C(0xCDEBFF));
                        b.Garland(new Vector3(s * 1.03f, 3.1f, -h + 0.8f), new Vector3(s * 1.03f, 3.1f, h - 0.8f), 0.22f, 16, 0.1f, G(0xFF5252, 0.05f), G(0xFFD54F, 0.05f));
                        for (int k = 0; k < 2; k++)
                            for (int i = 0; i < 3; i++) b.Box(new Vector3(s * 1.02f, 1.2f, (k == 0 ? -1f : 1f) * L * 0.18f), new Vector3(0.03f, 0.6f, 0.07f), Color.white, new Vector3(i * 60f, 0, 0));
                    }
                    if (loco) // wreath on the nose
                    {
                        float z = -h - 0.12f;
                        for (int i = 0; i < 12; i++) { float a = i / 12f * Mathf.PI * 2f; b.Sph(new Vector3(Mathf.Cos(a) * 0.42f, 2.0f + Mathf.Sin(a) * 0.42f, z), 0.2f, C(0x2E7D32)); }
                        b.Box(new Vector3(0, 1.55f, z - 0.03f), new Vector3(0.3f, 0.2f, 0.06f), C(0xD32F2F));
                    }
                    break;
                case ThemeId.TokyoNight:
                    for (int s = -1; s <= 1; s += 2)
                    {
                        b.Box(new Vector3(s * 1.03f, 0.98f, 0), new Vector3(0.04f, 0.06f, L - 0.4f), G(0x00E5FF, 0f));
                        b.Box(new Vector3(s * 1.03f, 3.0f, 0), new Vector3(0.04f, 0.05f, L - 0.4f), G(0xFF2E93, 0f));
                        for (int i = 0; i < 5; i++) b.Box(new Vector3(s * 1.025f, 2.68f, -h + 2.0f + i * (L - 4f) / 4f), new Vector3(0.025f, 0.6f, (L - 4f) / 5f - 0.3f), G(0xFFE0A0, 0.28f));
                    }
                    if (loco) b.Box(new Vector3(0, 3.33f, -h - 0.1f), new Vector3(0.9f, 0.16f, 0.04f), G(0xFF2E93, 0f));
                    break;
                default: // miami: surfboards on the roof, sun and wave art, flower lei
                    for (int i = 0; i < 3; i++) b.Sph(new Vector3((i - 1) * 0.5f, 3.74f, 0f), new Vector3(0.28f, 0.08f, L * 0.7f), Theme.Pal(i * 2 + 1));
                    for (int s = -1; s <= 1; s += 2)
                    {
                        b.Prim(PrimKind.Cylinder, new Vector3(s * 1.03f, 1.55f, -L * 0.2f), new Vector3(0.7f, 0.04f, 0.7f), G(0xFFB300, 0.12f), new Vector3(0, 0, 90));
                        for (int i = 0; i < 3; i++) b.Box(new Vector3(s * 1.025f, 1.3f - i * 0.12f, L * 0.2f), new Vector3(0.03f, 0.06f, 1.6f - i * 0.2f), i % 2 == 0 ? G(0x00E5FF, 0.2f) : G(0xFF4F9A, 0.2f));
                    }
                    if (loco) b.Garland(new Vector3(-0.95f, 1.75f, -h - 0.12f), new Vector3(0.95f, 1.75f, -h - 0.12f), 0.3f, 12, 0.14f, C(0xFF4F9A), C(0xFFC107));
                    break;
            }
        }

        /// <summary>Freight load for the open wagon (heaped no higher than ~3 m).</summary>
        public static void CargoLoad(MeshBatcher b, float L, System.Random rng)
        {
            float h = L * 0.5f;
            int n = Mathf.FloorToInt(L / 0.8f);
            switch (Theme.Current.Id)
            {
                case ThemeId.ClassicCity:
                    for (int i = 0; i < n; i++) for (int s = -1; s <= 1; s += 2)
                    {
                        float z = -h + 0.6f + i * 0.8f;
                        b.Cyl(new Vector3(s * 0.45f, 1.7f, z), 0.7f, 1.0f, Theme.Pal(rng.Next(6)));
                        b.Cyl(new Vector3(s * 0.45f, 2.25f, z + 0.05f), 0.66f, 0.9f, Theme.Pal(rng.Next(6)));
                    }
                    b.Box(new Vector3(0, 2.4f, 0), new Vector3(0.7f, 0.7f, L - 1.4f), C(0xA1887F), default(Vector3), TexId.Wood, 1.2f);
                    break;
                case ThemeId.WinterHoliday:
                    for (int i = 0; i < n; i++) for (int s = -1; s <= 1; s += 2)
                    {
                        float z = -h + 0.6f + i * 0.8f;
                        Gift(b, new Vector3(s * 0.45f, 1.16f, z), 0.7f, Theme.Pal(rng.Next(6)), Theme.Pal(rng.Next(6)));
                        Gift(b, new Vector3(s * 0.45f, 1.9f, z + 0.05f), 0.55f, Theme.Pal(rng.Next(6)), Color.white);
                    }
                    ThemedEnvironment.Pine(b, new Vector3(0, 1.16f, 0), 2.5f, C(0x1F6B45), true, true, rng);
                    break;
                case ThemeId.TokyoNight:
                    for (int i = 0; i < n; i++) for (int s = -1; s <= 1; s += 2)
                    {
                        float z = -h + 0.6f + i * 0.8f;
                        b.Box(new Vector3(s * 0.45f, 1.55f, z), new Vector3(0.7f, 0.8f, 0.7f), (i + s) % 2 == 0 ? C(0xB88B54) : G(Theme.Pal(i), 0.25f), default(Vector3), TexId.Canvas, 1f);
                        b.Box(new Vector3(s * 0.45f, 2.3f, z), new Vector3(0.6f, 0.6f, 0.6f), C(0xC9A26B), default(Vector3), TexId.Canvas, 1f);
                    }
                    for (int i = 0; i < 3; i++) Lantern(b, new Vector3(0, 2.1f, -h + 1.2f + i * (L - 2.4f) / 2f), 1.1f, i == 1 ? 0x00E5FF : 0xFF2E93);
                    break;
                default:
                    for (int i = 0; i < n; i++) for (int s = -1; s <= 1; s += 2)
                    {
                        float z = -h + 0.6f + i * 0.8f;
                        b.Sph(new Vector3(s * 0.5f, 2.25f, z), new Vector3(0.34f, 2.3f, 0.12f), Theme.Pal(i + (s > 0 ? 2 : 0)));
                    }
                    for (int i = 0; i < 4; i++) { b.Sph(new Vector3(-0.3f + (i % 2) * 0.6f, 1.45f, -1.4f + i * 0.9f), new Vector3(0.45f, 0.55f, 0.45f), C(0xFFC400)); b.Box(new Vector3(-0.3f + (i % 2) * 0.6f, 1.85f, -1.4f + i * 0.9f), new Vector3(0.08f, 0.3f, 0.08f), C(0x2E9E4F)); }
                    b.Sph(new Vector3(0, 1.4f, 1.5f), 0.4f, C(0x6D4C41));
                    break;
            }
        }
    }
}
