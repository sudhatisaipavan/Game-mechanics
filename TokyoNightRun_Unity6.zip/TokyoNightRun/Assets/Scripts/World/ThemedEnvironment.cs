using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Builds one 30 m railway segment for the non-Holi themes. The shared corridor (tracks, platforms, masts, wires) is
    /// restyled from Theme.Current.Env; each theme then adds its own three scenery variants (0 = zone 1, 1 = zone 2, 2 = zone 3).
    /// Decoration only: no colliders.
    /// </summary>
    public static class ThemedEnvironment
    {
        public const float PlatformInnerX = 3.9f, PlatformOuterX = 9.4f, PlatformTop = 1.0f;
        public static readonly Color Dark = new Color(0.16f, 0.16f, 0.18f, 1f);
        public static readonly Color White = Color.white;

        public static Color C(int rgb) { return GameConfig.Hex(rgb); }
        /// <summary>Emissive colour (vertex alpha 0 = glows through bloom).</summary>
        public static Color Glow(int rgb, float a = 0f) { var c = GameConfig.Hex(rgb); c.a = a; return c; }
        public static Color Glow(Color c, float a = 0f) { c.a = a; return c; }

        public static GameObject BuildSegment(int variant, System.Random rng)
        {
            var t = Theme.Current;
            var root = new GameObject("Segment_" + t.Id + "_V" + variant);
            var b = new MeshBatcher();
            float L = GameConfig.SegmentLength;
            Tracks(b, L, t.Env, rng);
            Platforms(b, L, t.Env, variant, rng);
            Overhead(b, L, t.Env, t.Id, variant, rng);
            switch (t.Id)
            {
                case ThemeId.ClassicCity: ClassicEnv.Build(b, variant, L, rng); break;
                case ThemeId.WinterHoliday: WinterEnv.Build(b, variant, L, rng); break;
                case ThemeId.TokyoNight: TokyoEnv.Build(b, variant, L, rng); break;
                default: MiamiEnv.Build(b, variant, L, rng); break;
            }
            b.Build(root.transform, "Env");
            return root;
        }

        // ------------------------------------------------------------ shared corridor
        static void Tracks(MeshBatcher b, float L, EnvStyle st, System.Random rng)
        {
            b.Box(new Vector3(0, -0.15f, L * 0.5f), new Vector3(7.8f, 0.3f, L), C(st.Ballast), default(Vector3), st.BallastTex, 2.5f);
            for (int s = -1; s <= 1; s += 2)
            {
                b.Box(new Vector3(s * 3.95f, -0.45f, L * 0.5f), new Vector3(0.5f, 0.9f, L), C(st.Trench), default(Vector3), TexId.Concrete, 2.5f);
                if (st.Snow) b.Box(new Vector3(s * 3.95f, 0.02f, L * 0.5f), new Vector3(0.56f, 0.12f, L), C(0xFFFFFF), default(Vector3), TexId.Snow, 2f);
            }
            for (int lane = -1; lane <= 1; lane++)
            {
                float cx = lane * GameConfig.LaneWidth;
                for (float z = 0.4f; z < L; z += 0.75f)
                    b.Box(new Vector3(cx, 0.04f, z), new Vector3(1.9f, 0.09f, 0.26f), C(st.Sleeper), default(Vector3), TexId.Wood, 1.5f);
                for (int r = -1; r <= 1; r += 2)
                {
                    float rx = cx + r * GameConfig.RailHalfGauge;
                    b.Box(new Vector3(rx, 0.15f, L * 0.5f), new Vector3(0.1f, 0.13f, L), C(st.RailBody), default(Vector3), TexId.Metal, 3f);
                    b.Box(new Vector3(rx, 0.225f, L * 0.5f), new Vector3(0.06f, 0.03f, L), C(st.RailHead));
                }
            }
            if (st.Snow) // drifts between the rails
                for (int i = 0; i < 7; i++)
                {
                    float r = 0.5f + (float)rng.NextDouble() * 0.9f;
                    b.Prim(PrimKind.Sphere, new Vector3(Mathf.Lerp(-3.4f, 3.4f, (float)rng.NextDouble()), 0.02f, (float)rng.NextDouble() * L), new Vector3(r * 1.6f, 0.12f, r * 1.2f), C(0xF4F9FF));
                }
        }

        static void Platforms(MeshBatcher b, float L, EnvStyle st, int variant, System.Random rng)
        {
            float w = PlatformOuterX - PlatformInnerX;
            for (int s = -1; s <= 1; s += 2)
            {
                float cx = s * (PlatformInnerX + w * 0.5f);
                b.Box(new Vector3(cx, PlatformTop * 0.5f - 0.1f, L * 0.5f), new Vector3(w, PlatformTop + 0.2f, L), C(st.PlatformBody), default(Vector3), TexId.Concrete, 3f);
                b.Box(new Vector3(cx, PlatformTop + 0.01f, L * 0.5f), new Vector3(w - 0.1f, 0.04f, L), C(st.PlatformTop), default(Vector3), st.PlatformTopTex, 3.2f);
                float fx = s * (PlatformInnerX + 0.03f);
                b.Box(new Vector3(fx, 0.55f, L * 0.5f), new Vector3(0.08f, 0.9f, L), C(st.PlatformFace), default(Vector3), TexId.Concrete, 3f);
                for (int i = 0; i < 10; i++) // coloured band along the platform face
                    b.Box(new Vector3(fx - s * 0.05f, 0.62f, 1.5f + i * 3f), new Vector3(0.04f, 0.4f, 2.9f), Theme.Pal(i + variant * 2));
                b.Box(new Vector3(s * (PlatformInnerX + 0.45f), PlatformTop + 0.04f, L * 0.5f), new Vector3(0.14f, 0.02f, L), C(st.Strip));
                for (int i = 0; i < 20; i++)
                    b.Box(new Vector3(s * (PlatformInnerX + 0.7f), PlatformTop + 0.035f, 0.8f + i * 1.5f), new Vector3(0.3f, 0.02f, 0.5f), C(st.Strip));
                // back wall + trim
                b.Box(new Vector3(s * (PlatformOuterX + 0.15f), 2.2f, L * 0.5f), new Vector3(0.3f, 3.4f, L), C(st.BackWall), default(Vector3), st.BackWallTex, 3f);
                b.Box(new Vector3(s * (PlatformOuterX + 0.15f), 4.0f, L * 0.5f), new Vector3(0.4f, 0.2f, L), C(st.BackWallTrim));
                if (st.Snow) b.Box(new Vector3(s * (PlatformOuterX + 0.15f), 4.2f, L * 0.5f), new Vector3(0.6f, 0.24f, L), C(0xFFFFFF), default(Vector3), TexId.Snow, 2f);
                if (st.WallGraffiti)
                    for (int gz = 0; gz < 2; gz++)
                        b.Decal(new Vector3(s * (PlatformOuterX - 0.012f), 2.35f, 7.5f + gz * 15f), new Vector2(6.4f, 3.2f), -s, Color.white,
                            (TexId)((int)TexId.Graffiti0 + rng.Next(4)));
            }
        }

        static void Overhead(MeshBatcher b, float L, EnvStyle st, ThemeId id, int variant, System.Random rng)
        {
            Color steel = new Color(0.45f, 0.47f, 0.5f, 1f);
            for (int lane = -1; lane <= 1; lane++)
            {
                b.Box(new Vector3(lane * GameConfig.LaneWidth, 5.4f, L * 0.5f), new Vector3(0.03f, 0.03f, L), Dark);
                b.Box(new Vector3(lane * GameConfig.LaneWidth, 5.75f, L * 0.5f), new Vector3(0.025f, 0.025f, L), steel);
            }
            for (int m = 0; m < 2; m++)
            {
                float z = 2f + m * 15f;
                for (int s = -1; s <= 1; s += 2)
                {
                    b.Box(new Vector3(s * 4.35f, 3.4f, z), new Vector3(0.22f, 6.8f, 0.22f), C(st.Mast), default(Vector3), TexId.Metal, 2f);
                    b.Box(new Vector3(s * 4.35f, 0.2f, z), new Vector3(0.5f, 0.4f, 0.5f), C(0x9A9A98), default(Vector3), TexId.Concrete, 1f);
                }
                b.Box(new Vector3(0, 6.55f, z), new Vector3(9.0f, 0.18f, 0.18f), C(st.Mast), default(Vector3), TexId.Metal, 2f);
                for (int lane = -1; lane <= 1; lane++)
                {
                    float x = lane * GameConfig.LaneWidth;
                    b.Box(new Vector3(x, 6.0f, z), new Vector3(0.04f, 1.1f, 0.04f), steel);
                    b.Box(new Vector3(x, 5.6f, z), new Vector3(0.5f, 0.05f, 0.05f), steel);
                    b.Sph(new Vector3(x, 6.35f, z - 0.15f), new Vector3(0.18f, 0.28f, 0.18f), (lane + m) % 2 == 0 ? new Color(0.2f, 1f, 0.35f, 0f) : new Color(1f, 0.2f, 0.15f, 0f));
                }
                switch (id)
                {
                    case ThemeId.ClassicCity: ClassicEnv.Overhead(b, z, m, rng); break;
                    case ThemeId.WinterHoliday: WinterEnv.Overhead(b, z, m, rng); break;
                    case ThemeId.TokyoNight: TokyoEnv.Overhead(b, z, m, rng); break;
                    default: MiamiEnv.Overhead(b, z, m, rng); break;
                }
            }
        }

        // ------------------------------------------------------------ shared scenery helpers
        /// <summary>A building block standing behind the platform on side s.</summary>
        public static void Tower(MeshBatcher b, int s, float x, float cz, float w, float d, float h, Color col, TexId tex, float tile, float roofAlpha = 1f)
        {
            b.Box(new Vector3(s * x, h * 0.5f, cz), new Vector3(w, h, d), col, default(Vector3), tex, tile);
        }

        public static void Skyline(MeshBatcher b, int s, float L, System.Random rng, int[] colors, TexId tex, float tile, float minH, float maxH, float alpha = 1f)
        {
            for (int i = 0; i < 3; i++)
            {
                float h = minH + (float)rng.NextDouble() * (maxH - minH);
                Color c = C(colors[rng.Next(colors.Length)]); c.a = alpha;
                b.Box(new Vector3(s * (PlatformOuterX + 15f + (float)rng.NextDouble() * 6f), h * 0.5f, 4f + i * 10f), new Vector3(7f, h, 8.5f), c, default(Vector3), tex, tile);
            }
        }

        /// <summary>Stylised pine: stacked tiers, optional snow caps and fairy lights.</summary>
        public static void Pine(MeshBatcher b, Vector3 p, float h, Color leaf, bool snow, bool lights, System.Random rng)
        {
            b.Cyl(p + new Vector3(0, h * 0.08f, 0), 0.3f, h * 0.16f, C(0x5D4037));
            int tiers = 4;
            for (int i = 0; i < tiers; i++)
            {
                float k = i / (float)(tiers - 1);
                float d = Mathf.Lerp(h * 0.55f, h * 0.18f, k);
                float y = h * 0.2f + k * h * 0.62f;
                b.Cyl(p + new Vector3(0, y, 0), d, h * 0.22f, leaf * Mathf.Lerp(0.8f, 1.05f, k));
                if (snow) b.Cyl(p + new Vector3(0, y + h * 0.1f, 0), d * 0.82f, h * 0.05f, C(0xFFFFFF));
                if (lights && i < tiers - 1)
                    for (int l = 0; l < 4; l++)
                    {
                        float a = (l + i * 0.5f) * Mathf.PI * 0.5f;
                        b.Sph(p + new Vector3(Mathf.Cos(a) * d * 0.45f, y + h * 0.02f, Mathf.Sin(a) * d * 0.45f), 0.13f, Glow(Theme.Pal(l + i)));
                    }
            }
        }

        /// <summary>Round-crown street tree.</summary>
        public static void RoundTree(MeshBatcher b, Vector3 p, float h, Color leaf)
        {
            b.Cyl(p + new Vector3(0, h * 0.3f, 0), 0.28f, h * 0.6f, C(0x6D4C41));
            b.Sph(p + new Vector3(0, h * 0.7f, 0), new Vector3(h * 0.55f, h * 0.5f, h * 0.55f), leaf);
            b.Sph(p + new Vector3(0.3f, h * 0.85f, 0.2f), new Vector3(h * 0.38f, h * 0.34f, h * 0.38f), leaf * 1.1f);
        }

        public static void Lamp(MeshBatcher b, Vector3 p, float h, Color pole, Color bulb)
        {
            b.Box(p + new Vector3(0, h * 0.5f, 0), new Vector3(0.12f, h, 0.12f), pole);
            b.Sph(p + new Vector3(0, h + 0.1f, 0), 0.32f, bulb);
        }
    }
}
