using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>Tokyo Night: neon towers with lit windows, an izakaya alley with lantern chains, and a temple with torii gates and a red tower.</summary>
    public static class TokyoEnv
    {
        static Color C(int rgb) { return GameConfig.Hex(rgb); }
        static Color G(int rgb, float a = 0f) { return ThemedEnvironment.Glow(rgb, a); }
        static readonly int[] Neon = { 0xFF2E93, 0x00E5FF, 0xFFEA00, 0x7C4DFF, 0x39FF88, 0xFF6A00 };
        static readonly Color NightTint = new Color(1f, 1f, 1f, 0.14f);   // alpha < 1 = emissive: lit windows glow

        // ---------------------------------------------------------------- props
        static void Lantern(MeshBatcher b, Vector3 p, float k, int rgb)
        {
            b.Cyl(p + new Vector3(0, 0.22f * k, 0), 0.08f * k, 0.12f * k, C(0x212121));
            b.Sph(p, new Vector3(0.42f, 0.55f, 0.42f) * k, G(rgb, 0.08f));
            b.Cyl(p + new Vector3(0, 0.3f * k, 0), 0.26f * k, 0.05f * k, C(0x212121));
            b.Cyl(p + new Vector3(0, -0.3f * k, 0), 0.26f * k, 0.05f * k, C(0x212121));
        }

        static void LanternChain(MeshBatcher b, Vector3 a, Vector3 c, int n, float sag, int rgb, int rgb2)
        {
            for (int i = 0; i <= n; i++)
            {
                float t = i / (float)n;
                Vector3 p = Vector3.Lerp(a, c, t); p.y -= Mathf.Sin(t * Mathf.PI) * sag;
                Lantern(b, p, 1f, i % 2 == 0 ? rgb : rgb2);
            }
        }

        static void Vending(MeshBatcher b, Vector3 p, int rgb, float yaw)
        {
            b.Box(p + new Vector3(0, 0.95f, 0), new Vector3(0.9f, 1.9f, 0.8f), C(0x2B2F3A));
            b.Box(p + new Vector3(-0.42f, 1.15f, 0), new Vector3(0.06f, 1.3f, 0.62f), G(rgb, 0.1f));
            for (int i = 0; i < 4; i++) b.Box(p + new Vector3(-0.46f, 1.7f - i * 0.3f, 0), new Vector3(0.04f, 0.14f, 0.5f), G(Neon[(i + (rgb & 3)) % 6], 0.2f));
            b.Box(p + new Vector3(-0.42f, 0.3f, 0), new Vector3(0.08f, 0.22f, 0.5f), C(0x111111));
        }

        static void NeonSign(MeshBatcher b, float x, float y, float z, float h, int rgb, int side)
        {
            b.Box(new Vector3(x, y, z), new Vector3(0.35f, h, 1.3f), C(0x1A1A2E));
            b.Box(new Vector3(x - side * 0.2f, y, z), new Vector3(0.08f, h * 0.92f, 1.1f), G(rgb, 0.05f));
            for (int i = 0; i < 4; i++) b.Box(new Vector3(x - side * 0.26f, y - h * 0.38f + i * h * 0.25f, z), new Vector3(0.04f, 0.18f, 0.8f), G(Neon[(i + 2) % 6], 0.0f));
        }

        static void Sakura(MeshBatcher b, Vector3 p, float h, System.Random rng)
        {
            b.Cyl(p + new Vector3(0, h * 0.3f, 0), 0.3f, h * 0.6f, C(0x4E342E));
            for (int i = 0; i < 5; i++)
            {
                float a = i * 1.26f;
                b.Sph(p + new Vector3(Mathf.Cos(a) * h * 0.22f, h * (0.72f + (i % 2) * 0.1f), Mathf.Sin(a) * h * 0.22f), new Vector3(h * 0.4f, h * 0.32f, h * 0.4f), G(i % 2 == 0 ? 0xFFB7D5 : 0xFF8FC0, 0.45f));
            }
            b.Sph(p + new Vector3(0, h * 0.85f, 0), new Vector3(h * 0.45f, h * 0.35f, h * 0.45f), G(0xFFC9E0, 0.45f));
        }

        public static void Torii(MeshBatcher b, float z, float halfSpan, float h)
        {
            Color red = G(0xE53935, 0.55f);
            for (int s = -1; s <= 1; s += 2)
            {
                b.Cyl(new Vector3(s * halfSpan, h * 0.5f, z), 0.7f, h, red);
                b.Cyl(new Vector3(s * halfSpan, 0.25f, z), 0.95f, 0.5f, C(0x212121));
            }
            b.Box(new Vector3(0, h - 0.4f, z), new Vector3(halfSpan * 2f + 2.4f, 0.55f, 0.9f), C(0x1A1A1A));
            b.Box(new Vector3(0, h - 0.62f, z), new Vector3(halfSpan * 2f + 1.6f, 0.4f, 0.8f), red);
            b.Box(new Vector3(0, h - 1.7f, z), new Vector3(halfSpan * 2f + 0.4f, 0.4f, 0.5f), red);
            b.Box(new Vector3(0, h - 1.1f, z), new Vector3(0.7f, 1.0f, 0.3f), C(0x1A1A1A));
            b.Sph(new Vector3(0, h - 1.1f, z - 0.2f), 0.2f, G(0xFFEA00));
        }

        static void Tower(MeshBatcher b, int s, float x, float cz, float w, float d, float h, System.Random rng)
        {
            Color tint = NightTint;
            b.Box(new Vector3(s * x, h * 0.5f, cz), new Vector3(w, h, d), tint, default(Vector3), TexId.FacadeNight, 16f);
            b.Box(new Vector3(s * x, h + 0.25f, cz), new Vector3(w + 0.3f, 0.5f, d + 0.3f), C(0x1A1A2E));
            b.Sph(new Vector3(s * x, h + 1.0f, cz), 0.3f, G(0xFF1744));
            b.Box(new Vector3(s * x, h + 1.6f, cz), new Vector3(0.1f, 2.2f, 0.1f), C(0x90A4AE));
            float faceX = s * x - s * (w * 0.5f);
            int n = 1 + rng.Next(2);
            for (int i = 0; i < n; i++)
                NeonSign(b, faceX - s * 0.25f, 6f + (float)rng.NextDouble() * Mathf.Max(3f, h - 12f), cz - d * 0.3f + i * d * 0.5f, 3.5f + (float)rng.NextDouble() * 3f, Neon[rng.Next(6)], s);
            // wide screen billboard
            b.Decal(new Vector3(faceX - s * 0.03f, 4.2f, cz), new Vector2(Mathf.Min(6f, d - 1f), 2.6f), -s, NightTint, (TexId)((int)TexId.Graffiti0 + rng.Next(4)));
        }

        // ---------------------------------------------------------------- overhead
        public static void Overhead(MeshBatcher b, float z, int m, System.Random rng)
        {
            LanternChain(b, new Vector3(-4.35f, 6.3f, z), new Vector3(4.35f, 6.3f, z), 8, 0.9f, 0xFF2E93, 0x00E5FF);
            b.Box(new Vector3(0, 6.7f, z), new Vector3(8.8f, 0.07f, 0.07f), G(m == 0 ? 0xFF2E93 : 0x00E5FF, 0f));
            for (int s = -1; s <= 1; s += 2) b.Box(new Vector3(s * 4.2f, 3.4f, z), new Vector3(0.06f, 5.5f, 0.06f), G(Neon[(m + (s > 0 ? 1 : 0)) % 6], 0f));
        }

        // ---------------------------------------------------------------- variants
        public static void Build(MeshBatcher b, int variant, float L, System.Random rng)
        {
            for (int s = -1; s <= 1; s += 2)
            {
                if (variant == 0) Street(b, s, L, rng);
                else if (variant == 1) Alley(b, s, L, rng);
                else Temple(b, s, L, rng);
                for (int i = 0; i < 3; i++) // lit skyline
                {
                    float h = 20f + (float)rng.NextDouble() * 26f;
                    b.Box(new Vector3(s * (ThemedEnvironment.PlatformOuterX + 15f + (float)rng.NextDouble() * 6f), h * 0.5f, 4f + i * 10f), new Vector3(7f, h, 8.5f), NightTint, default(Vector3), TexId.FacadeNight, 16f);
                }
            }
            if (variant == 1) { Torii(b, 12f, 5.2f, 7.4f); }
            if (variant == 2) { Torii(b, 22f, 5.6f, 8.4f); }
        }

        static void Street(MeshBatcher b, int s, float L, System.Random rng)
        {
            float z = 0f; int guard = 0;
            while (z < L - 2f && guard++ < 4)
            {
                float d = Mathf.Min(L - z, 8f + (float)rng.NextDouble() * 5f);
                Tower(b, s, ThemedEnvironment.PlatformOuterX + 3.8f, z + d * 0.5f, 6.5f, d - 0.2f, 12f + (float)rng.NextDouble() * 12f, rng);
                z += d;
            }
            // konbini (convenience store) on the platform + vending machines
            float cx = s * 8.1f;
            b.Box(new Vector3(cx, 2.3f, 20f), new Vector3(2.4f, 2.6f, 5f), C(0xF4F7FA));
            b.Box(new Vector3(cx - s * 1.22f, 3.45f, 20f), new Vector3(0.1f, 0.5f, 5f), G(0x00C853, 0.1f));
            b.Box(new Vector3(cx - s * 1.22f, 2.9f, 20f), new Vector3(0.1f, 0.3f, 5f), G(0x2979FF, 0.1f));
            b.Box(new Vector3(cx - s * 1.23f, 1.9f, 20f), new Vector3(0.06f, 1.6f, 4.2f), G(0xFFF8D6, 0.1f));
            for (int i = 0; i < 3; i++) Vending(b, new Vector3(s * 8.3f, 1.0f, 5f + i * 1.0f), Neon[i], 0f);
            ThemedEnvironment.Lamp(b, new Vector3(s * 5.0f, 1.0f, 12f), 4.4f, C(0x33384A), G(0xFFD9A0));
            for (int i = 0; i < 2; i++) b.Box(new Vector3(s * 5.4f, 1.0f + 0.9f, 25f + i), new Vector3(0.4f, 1.8f, 0.4f), G(Neon[i + 3], 0.3f)); // bollards
        }

        static void Alley(MeshBatcher b, int s, float L, System.Random rng)
        {
            // low izakayas with noren curtains, red lanterns and wooden fronts
            for (int i = 0; i < 3; i++)
            {
                float z = 5f + i * 9f, x = s * 7.8f;
                b.Box(new Vector3(x, 1.0f + 1.2f, z), new Vector3(3.2f, 2.4f, 5.6f), C(0x4E342E), default(Vector3), TexId.Wood, 2f);
                b.Prim(PrimKind.Wedge, new Vector3(x, 1.0f + 2.95f, z), new Vector3(3.8f, 1.1f, 6.2f), C(0x263238));
                b.Box(new Vector3(x - s * 1.62f, 2.2f, z), new Vector3(0.08f, 1.5f, 3.6f), G(0xFFB74D, 0.12f));
                for (int k = 0; k < 6; k++) b.Box(new Vector3(x - s * 1.75f, 3.0f, z - 1.4f + k * 0.56f), new Vector3(0.05f, 0.9f, 0.5f), k % 2 == 0 ? C(0xC62828) : C(0xF5F5F5));
                Lantern(b, new Vector3(x - s * 1.9f, 3.9f, z - 1.9f), 1.3f, 0xFF3D3D);
                Lantern(b, new Vector3(x - s * 1.9f, 3.9f, z + 1.9f), 1.3f, 0xFF3D3D);
                NeonSign(b, x - s * 1.9f, 4.6f, z, 1.4f, Neon[(i + (s > 0 ? 2 : 0)) % 6], s);
            }
            Sakura(b, new Vector3(s * 5.6f, 1.0f, 14f), 4.6f, rng);
            // taller buildings behind
            float zz = 0f; int guard = 0;
            while (zz < L - 2f && guard++ < 3)
            {
                float d = Mathf.Min(L - zz, 9f + (float)rng.NextDouble() * 4f);
                Tower(b, s, ThemedEnvironment.PlatformOuterX + 4.6f, zz + d * 0.5f, 6.5f, d - 0.2f, 14f + (float)rng.NextDouble() * 10f, rng);
                zz += d;
            }
            // ramen cart
            b.Box(new Vector3(s * 5.9f, 1.0f + 0.6f, 25f), new Vector3(1.2f, 1.2f, 1.8f), C(0x8D5A2B), default(Vector3), TexId.Wood, 1f);
            Lantern(b, new Vector3(s * 5.9f, 3.0f, 25f), 1.2f, 0xFF3D3D);
            b.Box(new Vector3(s * 5.9f, 2.55f, 25f), new Vector3(1.4f, 0.08f, 2.0f), C(0x263238));
        }

        static void Temple(MeshBatcher b, int s, float L, System.Random rng)
        {
            // five-tier pagoda
            float x = s * 15f, z = 14f, y = 0f;
            b.Box(new Vector3(x, 0.5f, z), new Vector3(9f, 1.0f, 9f), C(0x3A3A52), default(Vector3), TexId.Concrete, 3f);
            y = 1f;
            for (int i = 0; i < 5; i++)
            {
                float w = 5.4f - i * 0.8f;
                b.Box(new Vector3(x, y + 1.0f, z), new Vector3(w, 2.0f, w), G(0xF2D7B0, 0.55f), default(Vector3), TexId.Wood, 2f);
                b.Box(new Vector3(x, y + 2.15f, z), new Vector3(w + 1.8f, 0.3f, w + 1.8f), C(0x212121));
                b.Prim(PrimKind.Wedge, new Vector3(x, y + 2.75f, z), new Vector3(w + 1.6f, 0.9f, w + 1.8f), C(0x37474F));
                b.Sph(new Vector3(x - s * (w * 0.5f + 0.05f), y + 1.0f, z), 0.3f, G(0xFFB74D, 0.1f));
                y += 2.6f;
            }
            b.Box(new Vector3(x, y + 1.0f, z), new Vector3(0.15f, 2.4f, 0.15f), G(0xFFD54F));
            // stone lanterns and cherry trees along the path
            for (int i = 0; i < 3; i++)
            {
                float lz = 4f + i * 9f;
                b.Box(new Vector3(s * 6.2f, 1.0f + 0.5f, lz), new Vector3(0.45f, 1.0f, 0.45f), C(0x7C8294));
                b.Box(new Vector3(s * 6.2f, 1.0f + 1.15f, lz), new Vector3(0.8f, 0.3f, 0.8f), C(0x7C8294));
                b.Sph(new Vector3(s * 6.2f, 1.0f + 1.15f, lz), 0.35f, G(0xFFC266, 0.1f));
                b.Prim(PrimKind.Wedge, new Vector3(s * 6.2f, 1.0f + 1.5f, lz), new Vector3(0.95f, 0.4f, 0.95f), C(0x5C6378));
            }
            Sakura(b, new Vector3(s * 8.0f, 1.0f, 8f), 5.2f, rng);
            Sakura(b, new Vector3(s * 8.4f, 1.0f, 24f), 4.6f, rng);
            // Tokyo-tower style lattice on the skyline
            float tx = s * 27f; float tz = 26f;
            for (int i = 0; i < 6; i++)
            {
                float w = Mathf.Lerp(7f, 1.2f, i / 5f), hh = 6f;
                b.Box(new Vector3(tx, 3f + i * hh, tz), new Vector3(w, hh, w), i % 2 == 0 ? G(0xFF5A36, 0.4f) : G(0xFFFFFF, 0.4f));
                b.Box(new Vector3(tx, 3f + i * hh, tz), new Vector3(w * 0.5f, hh + 0.2f, w * 1.1f), C(0x2A2A44));
            }
            b.Box(new Vector3(tx, 40f, tz), new Vector3(0.3f, 10f, 0.3f), G(0xFF1744));
            b.Sph(new Vector3(tx, 45.5f, tz), 0.8f, G(0xFF1744));
        }
    }
}
