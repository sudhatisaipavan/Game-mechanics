using System.Collections.Generic;
using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>One 30m piece of street plus the pooled obstacles/collectibles placed on it.</summary>
    public class TrackSegment : MonoBehaviour
    {
        public int Index;
        public float StartZ;
        public int Variant;
        readonly List<PooledObject> dynamics = new List<PooledObject>(32);

        public float EndZ { get { return StartZ + GameConfig.SegmentLength; } }

        public void Setup(int index, float startZ, int variant)
        {
            Index = index; StartZ = startZ; Variant = variant;
            transform.position = new Vector3(0, 0, startZ);
            transform.rotation = Quaternion.identity;
        }

        public void Track(GameObject go)
        {
            var po = go.GetComponent<PooledObject>();
            if (po != null) dynamics.Add(po);
        }

        /// <summary>Returns every obstacle/collectible on this segment to its pool.</summary>
        public void ClearDynamics()
        {
            for (int i = 0; i < dynamics.Count; i++)
                if (dynamics[i] != null) dynamics[i].Release();
            dynamics.Clear();
        }
    }
}
