using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>
    /// Detailed railway rolling stock built from batched primitives (bogies with wheels, body panels, window strips,
    /// doors, curved roof with vents, headlights, buffers, Holi stripes, hand-prints and marigold garlands).
    /// Local space: ground at y=0, centred on x=0/z=0, the end the player sees is at z = -length/2.
    /// </summary>
    public static class TrainFactory
    {
        static int[][] Palettes { get { return Theme.Current.TrainPalettes; } }

        static Color C(int rgb) { return GameConfig.Hex(rgb); }
        static Color Holi(int i) { return Theme.Pal(i); }
        static readonly Color Glow = new Color(1f, 0.96f, 0.75f, 0f);
        static readonly Color Dark = new Color(0.13f, 0.13f, 0.15f, 1f);
        static readonly Color Steel = new Color(0.55f, 0.57f, 0.6f, 1f);

        static void Bogie(MeshBatcher b, float z)
        {
            b.Box(new Vector3(0, 0.48f, z), new Vector3(1.55f, 0.22f, 2.3f), Dark, default(Vector3), TexId.Metal, 1.5f);
            for (int s = -1; s <= 1; s += 2)
                for (int k = -1; k <= 1; k += 2)
                {
                    b.Wheel(new Vector3(s * 0.74f, 0.4f, z + k * 0.8f), 0.4f, 0.1f, Steel);
                    b.Wheel(new Vector3(s * 0.69f, 0.4f, z + k * 0.8f), 0.18f, 0.16f, Dark);
                }
        }

        static void Handprint(MeshBatcher b, float side, float z, float y, Color col)
        {
            float x = side * 1.005f;
            b.Prim(PrimKind.Sphere, new Vector3(x, y, z), new Vector3(0.03f, 0.3f, 0.26f), col);
            for (int f = 0; f < 4; f++)
                b.Prim(PrimKind.Sphere, new Vector3(x, y + 0.2f + (f == 1 || f == 2 ? 0.05f : 0f), z - 0.12f + f * 0.08f), new Vector3(0.03f, 0.2f, 0.06f), col);
            b.Prim(PrimKind.Sphere, new Vector3(x, y + 0.05f, z + 0.18f), new Vector3(0.03f, 0.08f, 0.16f), col, new Vector3(35, 0, 0));
        }

        /// <summary>Passenger coach (static) or locomotive/EMU front car (moving).</summary>
        public static void BuildCoach(MeshBatcher b, float L, bool locoFront, System.Random rng)
        {
            var pal = Palettes[rng.Next(Palettes.Length)];
            Color lower = C(pal[0]), upper = C(pal[1]);
            float h = L * 0.5f;

            // chassis and bogies
            b.Box(new Vector3(0, 0.78f, 0), new Vector3(1.75f, 0.3f, L - 0.5f), Dark, default(Vector3), TexId.Metal, 2f);
            Bogie(b, -h + 1.8f);
            Bogie(b, h - 1.8f);

            // body shell: lower panel + upper panel + Holi colour stripe
            b.Box(new Vector3(0, 1.4f, 0), new Vector3(2.0f, 1.0f, L), lower, default(Vector3), TexId.Metal, 2f);
            b.Box(new Vector3(0, 2.62f, 0), new Vector3(1.96f, 1.45f, L), upper, default(Vector3), TexId.None);
            int segs = Mathf.FloorToInt(L / 0.9f);
            for (int i = 0; i < segs; i++)
                b.Box(new Vector3(0, 1.93f, -h + 0.45f + i * 0.9f), new Vector3(2.03f, 0.14f, 0.9f), Holi(i + rng.Next(6)));
            b.Box(new Vector3(0, 1.84f, 0), new Vector3(2.02f, 0.05f, L), Steel); // belt rail

            // street-art panels on the lower body (the signature graffiti-train look)
            for (int side = -1; side <= 1; side += 2)
                for (int k = -1; k <= 1; k += 2)
                {
                    var g = (TexId)((int)TexId.Graffiti0 + rng.Next(4));
                    b.Decal(new Vector3(side * 1.012f, 1.38f, k * L * 0.2f), new Vector2(Mathf.Min(2.6f, L * 0.3f), 0.84f), side, Color.white, g);
                }

            // window strips (both sides) and doors
            for (int s = -1; s <= 1; s += 2)
            {
                float x = s * 0.985f;
                b.Box(new Vector3(x, 2.68f, 0), new Vector3(0.06f, 0.78f, L - 2.6f), Color.white, default(Vector3), TexId.Window, 1.2f);
                for (int d = -1; d <= 1; d += 2)
                {
                    float dz = d * (L * 0.5f - 1.35f);
                    b.Box(new Vector3(s * 1.0f, 2.1f, dz), new Vector3(0.07f, 1.85f, 1.0f), lower * 0.82f);
                    b.Box(new Vector3(s * 1.04f, 2.55f, dz), new Vector3(0.05f, 0.6f, 0.7f), Color.white, default(Vector3), TexId.Window, 0.8f);
                    b.Box(new Vector3(s * 1.04f, 1.55f, dz + 0.3f), new Vector3(0.05f, 0.05f, 0.3f), Steel); // door handle rail
                }
                // Holi hand-prints and splashes (other themes dress the coach in ThemeProps.CoachDecor)
                if (Theme.IsHoli) for (int k = 0; k < 4; k++)
                {
                    float z = Mathf.Lerp(-h + 2.6f, h - 2.6f, (float)rng.NextDouble());
                    Handprint(b, s, z, 1.15f + (float)rng.NextDouble() * 0.2f, Holi(rng.Next(6)));
                }
                if (Theme.IsHoli) for (int k = 0; k < 3; k++)
                {
                    float z = Mathf.Lerp(-h + 2f, h - 2f, (float)rng.NextDouble());
                    float r = 0.25f + (float)rng.NextDouble() * 0.3f;
                    b.Prim(PrimKind.Sphere, new Vector3(s * 1.005f, 1.4f + (float)rng.NextDouble() * 1.8f, z), new Vector3(0.025f, r, r * 1.3f), Holi(rng.Next(6)));
                }
            }

            // curved roof, vents, antenna
            b.Prim(PrimKind.Cylinder, new Vector3(0, 3.33f, 0), new Vector3(1.94f, L - 0.1f, 0.62f), upper * 0.92f, new Vector3(90, 0, 0));
            for (int i = 0; i < 3; i++)
                b.Cyl(new Vector3(0, 3.7f, -h + L * (0.2f + 0.3f * i)), 0.5f, 0.16f, Steel);
            b.Box(new Vector3(0, 3.66f, 0), new Vector3(0.18f, 0.06f, L * 0.7f), Dark);

            if (!Theme.IsHoli) ThemeProps.CoachDecor(b, L, locoFront, rng);
            if (locoFront) BuildFront(b, L, lower, upper, rng);
            else BuildRearEnd(b, L, lower, upper);

            // far end (plain end wall with tail lamps), so trains look right if seen from behind
            b.Box(new Vector3(0, 2.1f, h + 0.02f), new Vector3(1.98f, 2.4f, 0.05f), lower);
            for (int s = -1; s <= 1; s += 2) b.Sph(new Vector3(s * 0.7f, 1.2f, h + 0.07f), 0.16f, new Color(1f, 0.15f, 0.1f, 0f));
        }

        static void BuildFront(MeshBatcher b, float L, Color lower, Color upper, System.Random rng)
        {
            float z = -L * 0.5f;
            b.Box(new Vector3(0, 2.1f, z - 0.02f), new Vector3(1.98f, 2.4f, 0.08f), lower);
            b.Box(new Vector3(0, 2.85f, z - 0.07f), new Vector3(1.55f, 0.85f, 0.05f), Color.white, default(Vector3), TexId.Window, 1.0f); // windscreen
            b.Box(new Vector3(0, 3.33f, z - 0.07f), new Vector3(1.0f, 0.2f, 0.05f), new Color(1f, 0.55f, 0.1f, 0.15f)); // destination board
            b.Box(new Vector3(0, 1.85f, z - 0.07f), new Vector3(1.9f, 0.12f, 0.06f), upper);
            for (int s = -1; s <= 1; s += 2)
            {
                b.Sph(new Vector3(s * 0.7f, 1.35f, z - 0.1f), new Vector3(0.28f, 0.28f, 0.14f), Glow);   // headlights
                b.Sph(new Vector3(s * 0.7f, 1.0f, z - 0.1f), 0.12f, new Color(1f, 0.15f, 0.1f, 0f));      // marker lamps
                b.Cyl(new Vector3(s * 0.72f, 0.88f, z - 0.25f), 0.24f, 0.4f, Steel, new Vector3(90, 0, 0)); // buffers
                b.Box(new Vector3(s * 0.45f, 2.55f, z - 0.12f), new Vector3(0.04f, 0.55f, 0.03f), Dark, new Vector3(0, 0, s * -25f)); // wipers
            }
            b.Box(new Vector3(0, 1.1f, z - 0.1f), new Vector3(0.5f, 0.22f, 0.04f), new Color(1f, 0.85f, 0.2f, 1f)); // number plate
            b.Box(new Vector3(0, 0.9f, z - 0.3f), new Vector3(0.18f, 0.18f, 0.5f), Dark); // coupler
            // marigold garland draped across the nose
            if (Theme.IsHoli) b.Garland(new Vector3(-0.95f, 1.75f, z - 0.12f), new Vector3(0.95f, 1.75f, z - 0.12f), 0.3f, 12, 0.13f, GameConfig.Hex(0xFF9800), GameConfig.Hex(0xFFC107));
            // pantograph
            b.Box(new Vector3(0, 3.78f, 0.5f), new Vector3(1.3f, 0.05f, 0.08f), Dark);
            b.Box(new Vector3(0.0f, 4.1f, 0.5f), new Vector3(0.05f, 0.7f, 0.05f), Steel, new Vector3(0, 0, 25));
            b.Box(new Vector3(0.0f, 4.1f, 0.5f), new Vector3(0.05f, 0.7f, 0.05f), Steel, new Vector3(0, 0, -25));
        }

        static void BuildRearEnd(MeshBatcher b, float L, Color lower, Color upper)
        {
            float z = -L * 0.5f;
            b.Box(new Vector3(0, 2.1f, z - 0.02f), new Vector3(1.98f, 2.4f, 0.08f), lower);
            b.Box(new Vector3(0, 2.0f, z - 0.07f), new Vector3(0.95f, 1.95f, 0.05f), Dark);            // end door
            b.Box(new Vector3(0, 2.65f, z - 0.1f), new Vector3(0.65f, 0.55f, 0.04f), Color.white, default(Vector3), TexId.Window, 0.7f);
            b.Box(new Vector3(0, 2.15f, z - 0.2f), new Vector3(1.5f, 2.2f, 0.3f), new Color(0.1f, 0.1f, 0.12f, 1f)); // gangway bellows
            for (int s = -1; s <= 1; s += 2)
            {
                b.Sph(new Vector3(s * 0.75f, 1.15f, z - 0.08f), 0.16f, new Color(1f, 0.15f, 0.1f, 0f)); // tail lamps
                b.Box(new Vector3(s * 0.95f, 2.1f, z - 0.1f), new Vector3(0.04f, 1.8f, 0.04f), Steel);  // grab rails
            }
            b.Box(new Vector3(0, 0.9f, z - 0.3f), new Vector3(0.18f, 0.18f, 0.5f), Dark);
        }

        /// <summary>Open freight wagon heaped with festival goods (gulal sacks and crates).</summary>
        public static void BuildCargo(MeshBatcher b, float L, System.Random rng)
        {
            float h = L * 0.5f;
            b.Box(new Vector3(0, 0.78f, 0), new Vector3(1.75f, 0.3f, L - 0.4f), Dark, default(Vector3), TexId.Metal, 2f);
            Bogie(b, -h + 1.4f);
            Bogie(b, h - 1.4f);
            Color wagon = C(0x7B4B2A);
            b.Box(new Vector3(0, 1.05f, 0), new Vector3(2.0f, 0.22f, L), wagon * 0.8f, default(Vector3), TexId.Wood, 1.5f);
            for (int s = -1; s <= 1; s += 2)
            {
                b.Box(new Vector3(s * 0.96f, 1.7f, 0), new Vector3(0.1f, 1.1f, L), wagon, default(Vector3), TexId.Wood, 1.5f);
                for (int i = 0; i < 4; i++)
                    b.Box(new Vector3(s * 1.03f, 1.7f, -h + 0.5f + i * (L - 1f) / 3f), new Vector3(0.05f, 1.15f, 0.12f), Steel);
            }
            b.Box(new Vector3(0, 1.7f, -h + 0.05f), new Vector3(1.9f, 1.1f, 0.1f), wagon, default(Vector3), TexId.Wood, 1.5f);
            b.Box(new Vector3(0, 1.7f, h - 0.05f), new Vector3(1.9f, 1.1f, 0.1f), wagon, default(Vector3), TexId.Wood, 1.5f);
            b.Box(new Vector3(0, 1.3f, -h - 0.08f), new Vector3(1.0f, 0.2f, 0.06f), new Color(1f, 0.85f, 0.2f, 1f));
            b.Box(new Vector3(0, 0.9f, -h - 0.25f), new Vector3(0.18f, 0.18f, 0.5f), Dark);
            if (!Theme.IsHoli) { ThemeProps.CargoLoad(b, L, rng); return; }
            // heaped goods: gulal sacks in Holi colours + crates
            int n = Mathf.FloorToInt(L / 0.8f);
            for (int i = 0; i < n; i++)
                for (int s = -1; s <= 1; s += 2)
                {
                    float z = -h + 0.6f + i * 0.8f;
                    b.Sph(new Vector3(s * 0.45f, 2.35f + (float)rng.NextDouble() * 0.15f, z), new Vector3(0.7f, 0.55f, 0.7f), Holi(rng.Next(6)));
                    b.Sph(new Vector3(s * 0.45f, 2.9f, z + 0.1f), new Vector3(0.6f, 0.45f, 0.6f), Holi(rng.Next(6)));
                }
            b.Box(new Vector3(0, 2.0f, 0), new Vector3(0.6f, 0.8f, L - 1.2f), C(0xA1887F), default(Vector3), TexId.Wood, 1.2f);
            b.Box(new Vector3(0, 2.55f, 0), new Vector3(0.9f, 0.3f, 0.9f), C(0x8D6E63), default(Vector3), TexId.Wood, 1.2f);
            b.Garland(new Vector3(-0.95f, 2.0f, -h - 0.05f), new Vector3(0.95f, 2.0f, -h - 0.05f), 0.25f, 10, 0.12f, GameConfig.Hex(0xFF9800), GameConfig.Hex(0xFFC107));
        }
    }
}
