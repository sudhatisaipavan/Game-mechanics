using UnityEngine;

namespace TokyoNightRun
{
    /// <summary>Winter Holiday: snowy station, Christmas market and a North-Pole village with a candy-cane gate.</summary>
    public static class WinterEnv
    {
        static Color C(int rgb) { return GameConfig.Hex(rgb); }
        static Color G(int rgb, float a = 0f) { return ThemedEnvironment.Glow(rgb, a); }
        static readonly Color Snow = new Color(0.96f, 0.98f, 1f, 1f);
        static readonly int[] Houses = { 0xC62828, 0x2E7D5B, 0x1E5AA8, 0xF2C14E, 0x8E4A6B, 0xE07A5F };

        // ---------------------------------------------------------------- props
        static void Gift(MeshBatcher b, Vector3 p, float s, Color box, Color ribbon)
        {
            b.Box(p + new Vector3(0, s * 0.5f, 0), Vector3.one * s, box);
            b.Box(p + new Vector3(0, s * 0.5f, 0), new Vector3(s * 1.02f, s * 1.02f, s * 0.18f), ribbon);
            b.Box(p + new Vector3(0, s * 0.5f, 0), new Vector3(s * 0.18f, s * 1.02f, s * 1.02f), ribbon);
            b.Sph(p + new Vector3(0, s * 1.08f, 0), s * 0.3f, ribbon);
        }

        public static void Snowman(MeshBatcher b, Vector3 p, float k)
        {
            b.Sph(p + new Vector3(0, 0.45f * k, 0), 0.9f * k, Snow);
            b.Sph(p + new Vector3(0, 1.15f * k, 0), 0.65f * k, Snow);
            b.Sph(p + new Vector3(0, 1.7f * k, 0), 0.46f * k, Snow);
            b.Cyl(p + new Vector3(0, 1.98f * k, 0), 0.34f * k, 0.3f * k, C(0x263238));          // hat
            b.Cyl(p + new Vector3(0, 1.83f * k, 0), 0.6f * k, 0.04f * k, C(0x263238));
            b.Box(p + new Vector3(0, 1.7f * k, -0.28f * k), new Vector3(0.07f, 0.07f, 0.28f) * k, C(0xFF7A00));   // carrot nose
            b.Box(p + new Vector3(0, 1.5f * k, 0), new Vector3(0.52f, 0.1f, 0.52f) * k, C(0xD32F2F));             // scarf
            for (int i = 0; i < 3; i++) b.Sph(p + new Vector3(0, (1.2f - i * 0.22f) * k, -0.31f * k), 0.1f * k, C(0x212121));
            for (int e = -1; e <= 1; e += 2) b.Sph(p + new Vector3(e * 0.12f * k, 1.78f * k, -0.2f * k), 0.06f * k, C(0x212121));
            for (int e = -1; e <= 1; e += 2) b.Box(p + new Vector3(e * 0.55f * k, 1.2f * k, 0), new Vector3(0.5f, 0.04f, 0.04f) * k, C(0x5D4037), new Vector3(0, 0, e * 25f));
        }

        static void CandyCane(MeshBatcher b, Vector3 p, float h)
        {
            int n = 8;
            for (int i = 0; i < n; i++) b.Cyl(p + new Vector3(0, h / n * (i + 0.5f), 0), 0.16f, h / n, i % 2 == 0 ? C(0xE53935) : Color.white);
            b.Box(p + new Vector3(0.12f, h + 0.05f, 0), new Vector3(0.3f, 0.16f, 0.16f), C(0xE53935));
            b.Cyl(p + new Vector3(0.26f, h - 0.05f, 0), 0.16f, 0.2f, Color.white);
        }

        static void Icicles(MeshBatcher b, float x, float y, float z0, float z1, System.Random rng)
        {
            for (float z = z0; z < z1; z += 0.45f)
            {
                float l = 0.2f + (float)rng.NextDouble() * 0.45f;
                b.Cyl(new Vector3(x, y - l * 0.5f, z), 0.1f, l, C(0xCDEBFF));
            }
        }

        static void Wreath(MeshBatcher b, Vector3 c)
        {
            for (int i = 0; i < 12; i++)
            {
                float a = i / 12f * Mathf.PI * 2f;
                b.Sph(c + new Vector3(0, Mathf.Sin(a) * 0.38f, Mathf.Cos(a) * 0.38f), 0.2f, C(0x2E7D32));
            }
            b.Box(c + new Vector3(0, -0.4f, 0), new Vector3(0.12f, 0.22f, 0.3f), C(0xD32F2F));
            for (int i = 0; i < 4; i++) b.Sph(c + new Vector3(0.1f, Mathf.Sin(i * 1.6f) * 0.3f, Mathf.Cos(i * 1.6f) * 0.3f), 0.09f, G(0xFF5252));
        }

        static void Chalet(MeshBatcher b, int s, float cx, float cz, float w, float d, float h, Color wall, Color roof, System.Random rng, bool lit)
        {
            b.Box(new Vector3(cx, h * 0.5f, cz), new Vector3(w, h, d), wall, default(Vector3), TexId.Wood, 3f);
            b.Prim(PrimKind.Wedge, new Vector3(cx, h + w * 0.28f, cz), new Vector3(w + 0.8f, w * 0.56f, d + 0.8f), roof);
            b.Prim(PrimKind.Wedge, new Vector3(cx, h + w * 0.3f + 0.08f, cz), new Vector3(w + 0.5f, w * 0.5f, d + 0.5f), Snow);
            b.Box(new Vector3(cx + 0.9f * s, h + w * 0.5f, cz + d * 0.25f), new Vector3(0.7f, 1.4f, 0.7f), C(0x6D4C41));   // chimney
            b.Box(new Vector3(cx + 0.9f * s, h + w * 0.5f + 0.75f, cz + d * 0.25f), new Vector3(0.9f, 0.16f, 0.9f), Snow);
            float faceX = cx - s * (w * 0.5f);
            for (int i = 0; i < 2; i++)
            {
                float wz = cz + (i - 0.5f) * d * 0.45f;
                b.Box(new Vector3(faceX - s * 0.04f, h * 0.55f, wz), new Vector3(0.1f, 1.1f, 1.1f), lit ? G(0xFFD27A, 0.1f) : C(0x7FB2D8));
                b.Box(new Vector3(faceX - s * 0.1f, h * 0.55f, wz), new Vector3(0.06f, 1.3f, 0.12f), C(0xFFFFFF));
                b.Box(new Vector3(faceX - s * 0.1f, h * 0.55f, wz), new Vector3(0.06f, 0.12f, 1.3f), C(0xFFFFFF));
                b.Box(new Vector3(faceX - s * 0.2f, h * 0.55f - 0.7f, wz), new Vector3(0.35f, 0.3f, 1.3f), C(0x2E7D32));   // flower box
            }
            Icicles(b, faceX - s * 0.45f, h + 0.1f, cz - d * 0.45f, cz + d * 0.45f, rng);
            b.Garland(new Vector3(faceX - s * 0.15f, h - 0.3f, cz - d * 0.45f), new Vector3(faceX - s * 0.15f, h - 0.3f, cz + d * 0.45f), 0.35f, 12, 0.13f, G(0xFF5252), G(0xFFD54F));
        }

        // ---------------------------------------------------------------- overhead
        public static void Overhead(MeshBatcher b, float z, int m, System.Random rng)
        {
            b.Garland(new Vector3(-4.35f, 6.25f, z), new Vector3(4.35f, 6.25f, z), 1.0f, 22, 0.16f, G(0xFF5252), G(0xFFD54F));
            b.Garland(new Vector3(-4.35f, 6.0f, z + 0.2f), new Vector3(4.35f, 6.0f, z + 0.2f), 0.7f, 18, 0.13f, G(0x4FC3F7), G(0x69F0AE));
            for (int s = -1; s <= 1; s += 2) Wreath(b, new Vector3(s * 4.2f, 5.0f, z));
            b.Box(new Vector3(0, 6.75f, z), new Vector3(9.2f, 0.12f, 0.3f), Snow);
        }

        // ---------------------------------------------------------------- variants
        public static void Build(MeshBatcher b, int variant, float L, System.Random rng)
        {
            for (int s = -1; s <= 1; s += 2)
            {
                if (variant == 0) Station(b, s, L, rng);
                else if (variant == 1) Market(b, s, L, rng);
                else Village(b, s, L, rng);
                // distant snowy peaks
                for (int i = 0; i < 3; i++)
                {
                    float h = 16f + (float)rng.NextDouble() * 14f, w = 14f + (float)rng.NextDouble() * 8f;
                    float x = s * (ThemedEnvironment.PlatformOuterX + 21f + (float)rng.NextDouble() * 6f), z = 4f + i * 10f;
                    b.Prim(PrimKind.Wedge, new Vector3(x, h * 0.5f, z), new Vector3(w, h, 10f), C(0x7C93B8));
                    b.Prim(PrimKind.Wedge, new Vector3(x, h * 0.78f, z), new Vector3(w * 0.42f, h * 0.44f, 10.1f), Snow);
                }
            }
            if (variant == 2) Gate(b, 22f);
            if (variant == 1) LightSpan(b, 20f);
        }

        static void Station(MeshBatcher b, int s, float L, System.Random rng)
        {
            float x0 = s * ThemedEnvironment.PlatformInnerX, x1 = s * ThemedEnvironment.PlatformOuterX;
            float cx = (x0 + x1) * 0.5f, w = Mathf.Abs(x1 - x0) + 0.8f;
            b.Box(new Vector3(cx, 4.7f, L * 0.5f), new Vector3(w, 0.22f, L), C(0xB0463F), new Vector3(0, 0, -s * 4f), TexId.Metal, 3f);
            b.Box(new Vector3(cx, 4.9f, L * 0.5f), new Vector3(w, 0.2f, L), Snow, new Vector3(0, 0, -s * 4f), TexId.Snow, 2f);
            Icicles(b, cx - s * (w * 0.5f), 4.6f, 0.5f, L - 0.5f, rng);
            for (int i = 0; i < 4; i++)
            {
                float z = 3.75f + i * 7.5f, x = s * (ThemedEnvironment.PlatformInnerX + 1.0f);
                CandyCane(b, new Vector3(x, 1.0f, z), 3.8f);
                b.Sph(new Vector3(x, 4.35f, z + 0.3f), 0.22f, G(0xFFF1B8));
            }
            for (int i = 0; i < 3; i++) // fairy-lit pines along the fence and snowmen
                ThemedEnvironment.Pine(b, new Vector3(s * 8.6f, 1.0f, 4f + i * 10f), 3.4f + (float)rng.NextDouble(), C(0x1F6B45), true, true, rng);
            Snowman(b, new Vector3(s * 6.4f, 1.0f, 11f), 1.0f);
            Snowman(b, new Vector3(s * 7.4f, 1.0f, 12.2f), 0.7f);
            b.Box(new Vector3(s * 7.7f, 1.45f, 24f), new Vector3(0.6f, 0.08f, 2f), C(0x8D5A2B), default(Vector3), TexId.Wood, 1f);   // bench
            b.Box(new Vector3(s * 7.7f, 1.55f, 24f), new Vector3(0.7f, 0.12f, 2.1f), Snow);
            for (int i = 0; i < 2; i++) Gift(b, new Vector3(s * 5.6f, 1.0f, 18f + i * 1.0f), 0.5f + i * 0.2f, Theme.Pal(i), Theme.Pal(i + 3));
            float z0 = 0f; int guard = 0;
            while (z0 < L - 2f && guard++ < 4)
            {
                float d = Mathf.Min(L - z0, 8f + (float)rng.NextDouble() * 4f);
                Chalet(b, s, s * (ThemedEnvironment.PlatformOuterX + 4.5f), z0 + d * 0.5f, 7f, d - 0.3f, 5f + (float)rng.NextDouble() * 4f, C(Houses[rng.Next(Houses.Length)]), C(0x5D4037), rng, true);
                z0 += d;
            }
        }

        static void Market(MeshBatcher b, int s, float L, System.Random rng)
        {
            for (int i = 0; i < 3; i++)
            {
                float z = 5f + i * 9f, x = s * 8.3f;
                Color roof = i % 2 == 0 ? C(0xD32F2F) : C(0x2E7D32);
                b.Box(new Vector3(x, 1.0f + 0.6f, z), new Vector3(1.5f, 1.2f, 2.6f), C(0x8D5A2B), default(Vector3), TexId.Wood, 1.5f);
                for (int e = -1; e <= 1; e += 2) b.Box(new Vector3(x - s * 0.7f, 1.0f + 1.3f, z + e * 1.3f), new Vector3(0.08f, 2.6f, 0.08f), C(0x5D4037));
                b.Prim(PrimKind.Wedge, new Vector3(x, 1.0f + 2.95f, z), new Vector3(2.0f, 0.75f, 3.0f), roof);
                for (int k = 0; k < 5; k++) b.Box(new Vector3(x - s * 0.02f, 1.0f + 2.7f, z - 1.2f + k * 0.6f), new Vector3(1.9f, 0.12f, 0.3f), k % 2 == 0 ? Color.white : roof);
                b.Prim(PrimKind.Wedge, new Vector3(x, 1.0f + 3.4f, z), new Vector3(1.9f, 0.3f, 3.0f), Snow);
                Icicles(b, x - s * 1.0f, 3.75f, z - 1.3f, z + 1.3f, rng);
                b.Garland(new Vector3(x - s * 0.8f, 1.0f + 2.5f, z - 1.3f), new Vector3(x - s * 0.8f, 1.0f + 2.5f, z + 1.3f), 0.25f, 9, 0.12f, G(0xFF5252), G(0xFFD54F));
                for (int k = 0; k < 4; k++) b.Sph(new Vector3(x, 1.0f + 1.3f, z - 0.9f + k * 0.6f), 0.28f, Theme.Pal(k + i));
                Gift(b, new Vector3(x - s * 1.4f, 1.0f, z + 1.6f), 0.45f, Theme.Pal(i + 1), Theme.Pal(i + 4));
            }
            // big Christmas tree with a glowing star
            ThemedEnvironment.Pine(b, new Vector3(s * 12.5f, 0f, 15f), 11f, C(0x1B6B3F), true, true, rng);
            b.Sph(new Vector3(s * 12.5f, 11.3f, 15f), 0.9f, G(0xFFD54F));
            b.Box(new Vector3(s * 12.5f, 11.3f, 15f), new Vector3(1.8f, 0.2f, 0.2f), G(0xFFD54F), new Vector3(0, 0, 45));
            b.Box(new Vector3(s * 12.5f, 11.3f, 15f), new Vector3(1.8f, 0.2f, 0.2f), G(0xFFD54F), new Vector3(0, 0, -45));
            for (int i = 0; i < 6; i++) Gift(b, new Vector3(s * (11f + (i % 3) * 1.1f), 0f, 13f + (i / 3) * 2.5f), 0.7f, Theme.Pal(i), Theme.Pal(i + 2));
            float z0 = 0f; int guard = 0;
            while (z0 < L - 2f && guard++ < 3)
            {
                float d = Mathf.Min(L - z0, 9f + (float)rng.NextDouble() * 4f);
                float h = (3 + rng.Next(3)) * 3.2f, bx = s * (ThemedEnvironment.PlatformOuterX + 16.5f);
                if (z0 > 10f && z0 < 20f) { z0 += d; continue; }
                b.Box(new Vector3(bx, h * 0.5f, z0 + d * 0.5f), new Vector3(6.5f, h, d - 0.3f), C(Houses[rng.Next(Houses.Length)]), default(Vector3), TexId.Facade, 4f);
                b.Prim(PrimKind.Wedge, new Vector3(bx, h + 1.4f, z0 + d * 0.5f), new Vector3(7.2f, 2.8f, d), Snow);
                z0 += d;
            }
        }

        static void Village(MeshBatcher b, int s, float L, System.Random rng)
        {
            float z0 = 0f; int guard = 0;
            while (z0 < L - 2f && guard++ < 3)
            {
                float d = Mathf.Min(L - z0, 8f + (float)rng.NextDouble() * 3f);
                Chalet(b, s, s * (ThemedEnvironment.PlatformOuterX + 4.0f), z0 + d * 0.5f, 6f, d - 0.5f, 3.5f + (float)rng.NextDouble() * 2.5f, C(Houses[rng.Next(Houses.Length)]), C(0xB0463F), rng, true);
                z0 += d;
            }
            // church with a steeple on the far plot
            float x = s * (ThemedEnvironment.PlatformOuterX + 13f);
            b.Box(new Vector3(x, 3f, 12f), new Vector3(6f, 6f, 9f), C(0xF1E6D2), default(Vector3), TexId.Brick, 3f);
            b.Prim(PrimKind.Wedge, new Vector3(x, 7f, 12f), new Vector3(6.6f, 2.2f, 9.6f), Snow);
            b.Box(new Vector3(x, 8f, 7f), new Vector3(2.2f, 10f, 2.2f), C(0xF1E6D2), default(Vector3), TexId.Brick, 3f);
            b.Prim(PrimKind.Wedge, new Vector3(x, 14.2f, 7f), new Vector3(2.8f, 3.6f, 2.8f), C(0x8E4A6B));
            b.Sph(new Vector3(x - s * 1.12f, 11f, 7f), 0.8f, G(0xFFD27A, 0.1f));
            // igloo, snowmen family, pines, reindeer
            b.Prim(PrimKind.Sphere, new Vector3(s * 7.6f, 1.0f, 8f), new Vector3(3.2f, 2.8f, 3.2f), C(0xEAF4FC));
            b.Box(new Vector3(s * 6.2f, 1.45f, 8f), new Vector3(0.8f, 0.9f, 1.0f), C(0x40506A));
            Snowman(b, new Vector3(s * 6.0f, 1.0f, 15f), 1.1f); Snowman(b, new Vector3(s * 7.1f, 1.0f, 15.8f), 0.8f);
            for (int i = 0; i < 4; i++) ThemedEnvironment.Pine(b, new Vector3(s * (8.2f + (i % 2) * 1.4f), 1.0f, 20f + i * 2.4f), 3.0f + (float)rng.NextDouble() * 1.5f, C(0x1F6B45), true, i % 2 == 0, rng);
            Reindeer(b, new Vector3(s * 7.2f, 1.0f, 26f), s);
            for (int i = 0; i < 3; i++) CandyCane(b, new Vector3(s * 5.2f, 1.0f, 3f + i * 1.7f), 1.6f);
        }

        static void Reindeer(MeshBatcher b, Vector3 p, int s)
        {
            Color br = C(0x8D5A2B);
            b.Box(p + new Vector3(0, 1.0f, 0), new Vector3(0.6f, 0.6f, 1.2f), br);
            for (int i = 0; i < 4; i++) b.Box(p + new Vector3((i % 2 - 0.5f) * 0.35f, 0.4f, (i / 2 - 0.5f) * 0.8f), new Vector3(0.12f, 0.8f, 0.12f), br);
            b.Box(p + new Vector3(0, 1.55f, -0.6f), new Vector3(0.3f, 0.7f, 0.3f), br, new Vector3(-20, 0, 0));
            b.Box(p + new Vector3(0, 1.95f, -0.78f), new Vector3(0.38f, 0.34f, 0.5f), br);
            b.Sph(p + new Vector3(0, 1.9f, -1.05f), 0.16f, G(0xFF1744));
            for (int e = -1; e <= 1; e += 2) { b.Box(p + new Vector3(e * 0.2f, 2.35f, -0.78f), new Vector3(0.06f, 0.6f, 0.06f), C(0x5D4037), new Vector3(0, 0, e * 20f)); b.Box(p + new Vector3(e * 0.32f, 2.6f, -0.78f), new Vector3(0.3f, 0.05f, 0.05f), C(0x5D4037)); }
        }

        static void Gate(MeshBatcher b, float z)
        {
            for (int s = -1; s <= 1; s += 2)
            {
                for (int i = 0; i < 12; i++) b.Cyl(new Vector3(s * 4.7f, 0.35f + i * 0.6f, z), 0.5f, 0.6f, i % 2 == 0 ? C(0xE53935) : Color.white);
                b.Sph(new Vector3(s * 4.7f, 7.5f, z), 0.7f, G(0xFFD54F));
            }
            b.Box(new Vector3(0, 7.0f, z), new Vector3(10.2f, 0.7f, 0.7f), C(0x1F6B45));
            b.Garland(new Vector3(-4.7f, 6.7f, z), new Vector3(4.7f, 6.7f, z), 1.2f, 26, 0.24f, G(0xE53935), G(0xFFD54F));
            b.Sph(new Vector3(0, 7.9f, z), 1.0f, G(0xFFD54F));
            b.Box(new Vector3(0, 7.9f, z), new Vector3(2f, 0.22f, 0.22f), G(0xFFD54F), new Vector3(0, 0, 45));
            b.Box(new Vector3(0, 7.9f, z), new Vector3(2f, 0.22f, 0.22f), G(0xFFD54F), new Vector3(0, 0, -45));
        }

        static void LightSpan(MeshBatcher b, float z)
        {
            for (int s = -1; s <= 1; s += 2) b.Box(new Vector3(s * 4.6f, 3.8f, z), new Vector3(0.25f, 7.6f, 0.25f), C(0x5D4037));
            for (int i = 0; i < 4; i++)
                b.Garland(new Vector3(-4.6f, 7.2f - i * 0.25f, z), new Vector3(4.6f, 7.2f - i * 0.25f, z), 0.6f + i * 0.2f, 20, 0.16f, G(i % 2 == 0 ? 0xFF5252 : 0x4FC3F7), G(0xFFF1B8));
        }
    }
}
