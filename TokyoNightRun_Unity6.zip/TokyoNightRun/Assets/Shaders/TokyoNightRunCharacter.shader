// Stylised cartoon character shader (runner skins): texture x tint, soft 3-band toon ramp with a cool shadow colour,
// small glossy highlight and a bright rim light. Follows the curved world so feet stay on the track.
// SubShader 1 = URP (Unity 6.x). SubShader 2 = Built-in pipeline fallback.
Shader "TokyoNightRun/Character"
{
    Properties
    {
        _MainTex ("Texture", 2D) = "white" {}
        _Color ("Tint", Color) = (1,1,1,1)
        _ShadeColor ("Shadow Colour", Color) = (0.62, 0.55, 0.78, 1)
        _RimColor ("Rim Colour", Color) = (1, 0.93, 0.82, 1)
        _RimPower ("Rim Power", Range(0.5, 6)) = 2.4
        _RimStrength ("Rim Strength", Range(0, 1.5)) = 0.5
        _GlossStrength ("Gloss Strength", Range(0, 1)) = 0.22
    }

    SubShader
    {
        PackageRequirements { "com.unity.render-pipelines.universal": "1.0" }
        Tags { "RenderType"="Opaque" "Queue"="Geometry" "RenderPipeline"="UniversalPipeline" }
        LOD 100

        Pass
        {
            Name "ForwardLit"
            Tags { "LightMode"="UniversalForward" }
            ZWrite On
            Cull Back

            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_fog
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"

            TEXTURE2D(_MainTex);
            SAMPLER(sampler_MainTex);

            CBUFFER_START(UnityPerMaterial)
                float4 _MainTex_ST;
                half4 _Color;
                half4 _ShadeColor;
                half4 _RimColor;
                half _RimPower;
                half _RimStrength;
                half _GlossStrength;
            CBUFFER_END

            float4 _HR_Curve;
            float4 _HR_Origin;

            struct Attributes
            {
                float4 positionOS : POSITION;
                float3 normalOS : NORMAL;
                float2 uv : TEXCOORD0;
            };

            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                float2 uv : TEXCOORD0;
                half3 normalWS : TEXCOORD1;
                float3 positionWS : TEXCOORD2;
                half fogFactor : TEXCOORD3;
            };

            Varyings vert(Attributes IN)
            {
                Varyings OUT;
                float3 posWS = TransformObjectToWorld(IN.positionOS.xyz);
                float dz = max(0.0, posWS.z - _HR_Origin.z);
                posWS.y -= dz * dz * _HR_Curve.y;
                posWS.x += dz * dz * _HR_Curve.x;
                OUT.positionWS = posWS;
                OUT.positionCS = TransformWorldToHClip(posWS);
                OUT.uv = TRANSFORM_TEX(IN.uv, _MainTex);
                OUT.normalWS = TransformObjectToWorldNormal(IN.normalOS);
                OUT.fogFactor = (half)ComputeFogFactor(OUT.positionCS.z);
                return OUT;
            }

            half4 frag(Varyings IN) : SV_Target
            {
                half3 n = normalize(IN.normalWS);
                half3 v = normalize(_WorldSpaceCameraPos - IN.positionWS);
                half4 tex = SAMPLE_TEXTURE2D(_MainTex, sampler_MainTex, IN.uv);
                half3 albedo = tex.rgb * _Color.rgb;

                Light mainLight = GetMainLight();
                half t = saturate(dot(n, mainLight.direction) * 0.5h + 0.5h);
                half ramp = smoothstep(0.28h, 0.52h, t) * 0.55h + smoothstep(0.58h, 0.82h, t) * 0.45h;
                half3 shade = lerp(_ShadeColor.rgb, half3(1, 1, 1), ramp);
                half3 light = shade * mainLight.color + SampleSH(n) * 0.75h;

                half3 h = normalize(mainLight.direction + v);
                half gloss = smoothstep(0.82h, 0.9h, saturate(dot(n, h))) * _GlossStrength * ramp;
                half rim = pow(1.0h - saturate(dot(n, v)), _RimPower) * _RimStrength * (0.35h + 0.65h * t);

                half3 rgb = albedo * light + _RimColor.rgb * rim + gloss.xxx;
                half luma = dot(rgb, half3(0.299h, 0.587h, 0.114h));
                rgb = saturate(lerp(luma.xxx, rgb, 1.18h));
                rgb = MixFog(rgb, IN.fogFactor);
                return half4(rgb, 1.0h);
            }
            ENDHLSL
        }
    }

    // ------------------------------------------------------------------ Built-in render pipeline fallback
    SubShader
    {
        Tags { "RenderType"="Opaque" "Queue"="Geometry" }
        Pass
        {
            Tags { "LightMode"="ForwardBase" }
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_fog
            #include "UnityCG.cginc"
            #include "UnityLightingCommon.cginc"

            sampler2D _MainTex;
            float4 _MainTex_ST;
            fixed4 _Color, _RimColor;
            half _RimPower, _RimStrength;

            struct appdata { float4 vertex : POSITION; float3 normal : NORMAL; float2 uv : TEXCOORD0; };
            struct v2f
            {
                float4 pos : SV_POSITION;
                float2 uv : TEXCOORD0;
                half3 light : TEXCOORD1;
                half rim : TEXCOORD2;
                UNITY_FOG_COORDS(3)
            };

            v2f vert (appdata v)
            {
                v2f o;
                o.pos = UnityObjectToClipPos(v.vertex);
                o.uv = TRANSFORM_TEX(v.uv, _MainTex);
                float3 n = UnityObjectToWorldNormal(v.normal);
                float3 wpos = mul(unity_ObjectToWorld, v.vertex).xyz;
                float3 viewDir = normalize(_WorldSpaceCameraPos - wpos);
                half wrap = saturate(dot(n, _WorldSpaceLightPos0.xyz) * 0.5 + 0.5);
                o.light = wrap * wrap * _LightColor0.rgb + ShadeSH9(half4(n, 1)) * 0.9;
                o.rim = pow(1.0 - saturate(dot(n, viewDir)), _RimPower) * _RimStrength;
                UNITY_TRANSFER_FOG(o, o.pos);
                return o;
            }

            fixed4 frag (v2f i) : SV_Target
            {
                fixed4 c = tex2D(_MainTex, i.uv) * _Color;
                c.rgb = c.rgb * i.light + _RimColor.rgb * i.rim;
                half luma = dot(c.rgb, half3(0.299, 0.587, 0.114));
                c.rgb = saturate(lerp(luma.xxx, c.rgb, 1.2));
                c.a = 1;
                UNITY_APPLY_FOG(i.fogCoord, c);
                return c;
            }
            ENDCG
        }
    }
    Fallback "Legacy Shaders/Diffuse"
}
