// Soft unlit particle / transparent shader (powder clouds, sparkles, shield bubble, blob shadow, clouds).
// _SrcBlend/_DstBlend are set from code: alpha blend (5,10) or additive (5,1).
// Follows the curved world. SubShader 1 = URP, SubShader 2 = Built-in fallback.
Shader "TokyoNightRun/Particle"
{
    Properties
    {
        _MainTex ("Texture", 2D) = "white" {}
        [HDR] _Color ("Tint", Color) = (1,1,1,1)
        _CurveAmount ("Curved World Amount", Range(0, 1)) = 1
        [HideInInspector] _SrcBlend ("Src Blend", Float) = 5
        [HideInInspector] _DstBlend ("Dst Blend", Float) = 10
    }

    SubShader
    {
        PackageRequirements { "com.unity.render-pipelines.universal": "1.0" }
        Tags { "RenderType"="Transparent" "Queue"="Transparent" "IgnoreProjector"="True" "RenderPipeline"="UniversalPipeline" }
        LOD 100

        Pass
        {
            Name "Particle"
            Blend [_SrcBlend] [_DstBlend]
            ZWrite Off
            Cull Off

            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            TEXTURE2D(_MainTex);
            SAMPLER(sampler_MainTex);

            CBUFFER_START(UnityPerMaterial)
                float4 _MainTex_ST;
                half4 _Color;
                half _CurveAmount;
            CBUFFER_END

            float4 _HR_Curve;
            float4 _HR_Origin;

            struct Attributes { float4 positionOS : POSITION; half4 color : COLOR; float2 uv : TEXCOORD0; };
            struct Varyings { float4 positionCS : SV_POSITION; half4 color : COLOR; float2 uv : TEXCOORD0; };

            Varyings vert(Attributes IN)
            {
                Varyings OUT;
                float3 posWS = TransformObjectToWorld(IN.positionOS.xyz);
                float dz = max(0.0, posWS.z - _HR_Origin.z);
                posWS.y -= dz * dz * _HR_Curve.y * _CurveAmount;
                posWS.x += dz * dz * _HR_Curve.x * _CurveAmount;
                OUT.positionCS = TransformWorldToHClip(posWS);
                OUT.color = IN.color;
                OUT.uv = TRANSFORM_TEX(IN.uv, _MainTex);
                return OUT;
            }

            half4 frag(Varyings IN) : SV_Target
            {
                half4 c = SAMPLE_TEXTURE2D(_MainTex, sampler_MainTex, IN.uv) * IN.color * _Color;
                return c;
            }
            ENDHLSL
        }
    }

    SubShader
    {
        Tags { "RenderType"="Transparent" "Queue"="Transparent" "IgnoreProjector"="True" }
        Pass
        {
            Blend [_SrcBlend] [_DstBlend]
            ZWrite Off
            Cull Off
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"

            sampler2D _MainTex;
            float4 _MainTex_ST;
            fixed4 _Color;
            half _CurveAmount;
            float4 _HR_Curve;
            float4 _HR_Origin;

            struct appdata { float4 vertex : POSITION; fixed4 color : COLOR; float2 uv : TEXCOORD0; };
            struct v2f { float4 pos : SV_POSITION; fixed4 color : COLOR; float2 uv : TEXCOORD0; };

            v2f vert (appdata v)
            {
                v2f o;
                float4 wpos = mul(unity_ObjectToWorld, v.vertex);
                float dz = max(0.0, wpos.z - _HR_Origin.z);
                wpos.y -= dz * dz * _HR_Curve.y * _CurveAmount;
                wpos.x += dz * dz * _HR_Curve.x * _CurveAmount;
                o.pos = mul(UNITY_MATRIX_VP, wpos);
                o.color = v.color;
                o.uv = TRANSFORM_TEX(v.uv, _MainTex);
                return o;
            }

            fixed4 frag (v2f i) : SV_Target
            {
                return tex2D(_MainTex, i.uv) * i.color * _Color;
            }
            ENDCG
        }
    }
    Fallback "Sprites/Default"
}
