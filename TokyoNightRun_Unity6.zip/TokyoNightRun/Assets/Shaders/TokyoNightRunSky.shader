// Gradient sky dome with a warm horizon glow and a soft sun. Drawn first, never writes depth.
// Colours are driven by AtmosphereController (morning / noon / sunset). SubShader 1 = URP, SubShader 2 = Built-in.
Shader "TokyoNightRun/Sky"
{
    Properties
    {
        _TopColor ("Zenith", Color) = (0.20, 0.52, 0.95, 1)
        _MidColor ("Upper Horizon", Color) = (0.55, 0.80, 1.0, 1)
        _HorizonColor ("Horizon", Color) = (1.0, 0.88, 0.80, 1)
        _BottomColor ("Below Horizon", Color) = (0.95, 0.80, 0.85, 1)
        _SunColor ("Sun", Color) = (1, 0.93, 0.7, 1)
        _SunDir ("Sun Direction", Vector) = (0.2, 0.35, 0.9, 0)
    }

    SubShader
    {
        PackageRequirements { "com.unity.render-pipelines.universal": "1.0" }
        Tags { "RenderType"="Background" "Queue"="Background" "PreviewType"="Skybox" "RenderPipeline"="UniversalPipeline" }

        Pass
        {
            Name "Sky"
            ZWrite Off
            Cull Off

            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            CBUFFER_START(UnityPerMaterial)
                half4 _TopColor;
                half4 _MidColor;
                half4 _HorizonColor;
                half4 _BottomColor;
                half4 _SunColor;
                float4 _SunDir;
            CBUFFER_END

            struct Attributes { float4 positionOS : POSITION; };
            struct Varyings { float4 positionCS : SV_POSITION; float3 dir : TEXCOORD0; };

            Varyings vert(Attributes IN)
            {
                Varyings OUT;
                OUT.positionCS = TransformObjectToHClip(IN.positionOS.xyz);
                OUT.dir = normalize(IN.positionOS.xyz);
                return OUT;
            }

            half4 frag(Varyings IN) : SV_Target
            {
                float3 d = normalize(IN.dir);
                half h = (half)d.y;
                half up = saturate(h);
                half3 col = lerp(_HorizonColor.rgb, _MidColor.rgb, saturate(up * 3.2h));
                col = lerp(col, _TopColor.rgb, saturate((up - 0.12h) * 1.45h));
                half down = saturate(-h * 4.0h);
                col = lerp(col, _BottomColor.rgb, down);

                float3 sd = normalize(_SunDir.xyz);
                half sdot = saturate((half)dot(d, sd));
                half glow = pow(sdot, 6.0h) * 0.28h + pow(sdot, 40.0h) * 0.35h;
                half disc = smoothstep(0.9965h, 0.9985h, sdot);
                col += _SunColor.rgb * glow;
                col = lerp(col, _SunColor.rgb * 1.5h, disc);
                return half4(col, 1.0h);
            }
            ENDHLSL
        }
    }

    SubShader
    {
        Tags { "RenderType"="Background" "Queue"="Background" "PreviewType"="Skybox" }
        Pass
        {
            ZWrite Off
            Cull Off
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"

            fixed4 _TopColor, _MidColor, _HorizonColor, _BottomColor, _SunColor;
            float4 _SunDir;

            struct appdata { float4 vertex : POSITION; };
            struct v2f { float4 pos : SV_POSITION; float3 dir : TEXCOORD0; };

            v2f vert (appdata v)
            {
                v2f o;
                o.pos = UnityObjectToClipPos(v.vertex);
                o.dir = normalize(v.vertex.xyz);
                return o;
            }

            fixed4 frag (v2f i) : SV_Target
            {
                float3 d = normalize(i.dir);
                half up = saturate(d.y);
                half3 col = lerp(_HorizonColor.rgb, _MidColor.rgb, saturate(up * 3.2));
                col = lerp(col, _TopColor.rgb, saturate((up - 0.12) * 1.45));
                col = lerp(col, _BottomColor.rgb, saturate(-d.y * 4.0));
                half sdot = saturate(dot(d, normalize(_SunDir.xyz)));
                col += _SunColor.rgb * (pow(sdot, 6.0) * 0.28 + pow(sdot, 40.0) * 0.35);
                col = lerp(col, _SunColor.rgb * 1.5, smoothstep(0.9965, 0.9985, sdot));
                return fixed4(col, 1);
            }
            ENDCG
        }
    }
    Fallback Off
}
