// Bright unlit colour for coins, lamps and pick-ups. Colour can be above 1 (HDR) so bloom makes it glow.
// Follows the curved world. SubShader 1 = URP, SubShader 2 = Built-in fallback.
Shader "TokyoNightRun/Unlit"
{
    Properties
    {
        [HDR] _Color ("Colour", Color) = (1,1,1,1)
        _Intensity ("Intensity", Range(0, 4)) = 1.4
    }

    SubShader
    {
        PackageRequirements { "com.unity.render-pipelines.universal": "1.0" }
        Tags { "RenderType"="Opaque" "Queue"="Geometry" "RenderPipeline"="UniversalPipeline" }
        LOD 100

        Pass
        {
            Name "Unlit"
            ZWrite On
            Cull Back

            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_fog
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            CBUFFER_START(UnityPerMaterial)
                half4 _Color;
                half _Intensity;
            CBUFFER_END

            float4 _HR_Curve;
            float4 _HR_Origin;

            struct Attributes { float4 positionOS : POSITION; };
            struct Varyings { float4 positionCS : SV_POSITION; half fogFactor : TEXCOORD0; };

            Varyings vert(Attributes IN)
            {
                Varyings OUT;
                float3 posWS = TransformObjectToWorld(IN.positionOS.xyz);
                float dz = max(0.0, posWS.z - _HR_Origin.z);
                posWS.y -= dz * dz * _HR_Curve.y;
                posWS.x += dz * dz * _HR_Curve.x;
                OUT.positionCS = TransformWorldToHClip(posWS);
                OUT.fogFactor = (half)ComputeFogFactor(OUT.positionCS.z);
                return OUT;
            }

            half4 frag(Varyings IN) : SV_Target
            {
                half3 rgb = _Color.rgb * _Intensity;
                rgb = MixFog(rgb, IN.fogFactor);
                return half4(rgb, 1.0h);
            }
            ENDHLSL
        }
    }

    SubShader
    {
        Tags { "RenderType"="Opaque" "Queue"="Geometry" }
        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_fog
            #include "UnityCG.cginc"

            fixed4 _Color;
            half _Intensity;
            float4 _HR_Curve;
            float4 _HR_Origin;

            struct appdata { float4 vertex : POSITION; };
            struct v2f { float4 pos : SV_POSITION; UNITY_FOG_COORDS(0) };

            v2f vert (appdata v)
            {
                v2f o;
                float4 wpos = mul(unity_ObjectToWorld, v.vertex);
                float dz = max(0.0, wpos.z - _HR_Origin.z);
                wpos.y -= dz * dz * _HR_Curve.y;
                wpos.x += dz * dz * _HR_Curve.x;
                o.pos = mul(UNITY_MATRIX_VP, wpos);
                UNITY_TRANSFER_FOG(o, o.pos);
                return o;
            }

            fixed4 frag (v2f i) : SV_Target
            {
                fixed4 c = fixed4(saturate(_Color.rgb * _Intensity), 1);
                UNITY_APPLY_FOG(i.fogCoord, c);
                return c;
            }
            ENDCG
        }
    }
    Fallback "Unlit/Color"
}
