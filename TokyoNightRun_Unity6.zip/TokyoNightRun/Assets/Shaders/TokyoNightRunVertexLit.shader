// World shader for every batched mesh (street, trains, obstacles, coins).
//  * Curved world: the track bends down / sideways towards the horizon (values set by CurvedWorld.cs).
//  * Texture x vertex colour. Vertex alpha < 1 = emissive (lamps, headlights, coins) and glows through bloom.
//  * Soft cartoon lighting: wrapped diffuse, sky ambient, warm top light, contact darkening near the ground.
// SubShader 1 = Universal Render Pipeline (Unity 6.x). SubShader 2 = Built-in pipeline fallback.
Shader "TokyoNightRun/VertexLit"
{
    Properties
    {
        _MainTex ("Texture", 2D) = "white" {}
        _Color ("Tint", Color) = (1,1,1,1)
        _Saturation ("Saturation", Range(0.5, 2)) = 1.3
        _EmissiveBoost ("Emissive Boost", Range(1, 4)) = 1.7
        _AoHeight ("Contact Darkening Height", Float) = 1.1
        _AoStrength ("Contact Darkening Strength", Range(0, 1)) = 0.38
    }

    SubShader
    {
        PackageRequirements { "com.unity.render-pipelines.universal": "1.0" }
        Tags { "RenderType"="Opaque" "Queue"="Geometry" "RenderPipeline"="UniversalPipeline" }
        LOD 100

        Pass
        {
            Name "ForwardLit"
            Tags { "LightMode"="UniversalForward" }
            ZWrite On
            Cull Back

            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_fog
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"

            TEXTURE2D(_MainTex);
            SAMPLER(sampler_MainTex);

            CBUFFER_START(UnityPerMaterial)
                float4 _MainTex_ST;
                half4 _Color;
                half _Saturation;
                half _EmissiveBoost;
                half _AoHeight;
                half _AoStrength;
            CBUFFER_END

            // Curved-world globals (CurvedWorld.cs). x = sideways bend, y = downward sag, per metre squared.
            float4 _HR_Curve;
            float4 _HR_Origin;

            struct Attributes
            {
                float4 positionOS : POSITION;
                float3 normalOS : NORMAL;
                float2 uv : TEXCOORD0;
                half4 color : COLOR;
            };

            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                float2 uv : TEXCOORD0;
                half4 color : COLOR;
                half3 normalWS : TEXCOORD1;
                half2 fogHeight : TEXCOORD2; // x = fog factor, y = world height before bending
            };

            Varyings vert(Attributes IN)
            {
                Varyings OUT;
                float3 posWS = TransformObjectToWorld(IN.positionOS.xyz);
                half height = (half)posWS.y;
                float dz = max(0.0, posWS.z - _HR_Origin.z);
                posWS.y -= dz * dz * _HR_Curve.y;
                posWS.x += dz * dz * _HR_Curve.x;
                OUT.positionCS = TransformWorldToHClip(posWS);
                OUT.uv = TRANSFORM_TEX(IN.uv, _MainTex);
                OUT.color = IN.color;
                OUT.normalWS = TransformObjectToWorldNormal(IN.normalOS);
                OUT.fogHeight = half2((half)ComputeFogFactor(OUT.positionCS.z), height);
                return OUT;
            }

            half4 frag(Varyings IN) : SV_Target
            {
                half3 n = normalize(IN.normalWS);
                half4 tex = SAMPLE_TEXTURE2D(_MainTex, sampler_MainTex, IN.uv);
                half3 albedo = tex.rgb * IN.color.rgb * _Color.rgb;

                Light mainLight = GetMainLight();
                half ndl = dot(n, mainLight.direction);
                half wrap = saturate(ndl * 0.5h + 0.5h);
                wrap = wrap * wrap * (3.0h - 2.0h * wrap);                  // smooth cartoon ramp
                half3 ambient = SampleSH(n);
                half3 light = wrap * mainLight.color + ambient;
                light += saturate(n.y) * 0.10h;                              // soft sky bounce on tops

                // contact darkening on vertical faces near the ground (cheap ambient occlusion)
                half vertical = 1.0h - abs(n.y);
                half ao = lerp(1.0h, lerp(1.0h - _AoStrength, 1.0h, saturate(IN.fogHeight.y / _AoHeight)), vertical);

                half3 lit = albedo * light * ao;
                half emissive = 1.0h - IN.color.a;
                half3 rgb = lerp(lit, albedo * _EmissiveBoost, emissive);

                half luma = dot(rgb, half3(0.299h, 0.587h, 0.114h));
                rgb = saturate(lerp(luma.xxx, rgb, _Saturation)) + (rgb - saturate(rgb)); // keep HDR overshoot for bloom
                rgb = MixFog(rgb, IN.fogHeight.x);
                return half4(rgb, 1.0h);
            }
            ENDHLSL
        }
    }

    // ------------------------------------------------------------------ Built-in render pipeline fallback
    SubShader
    {
        Tags { "RenderType"="Opaque" "Queue"="Geometry" }
        LOD 100
        Pass
        {
            Tags { "LightMode"="ForwardBase" }
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_fog
            #include "UnityCG.cginc"
            #include "UnityLightingCommon.cginc"

            sampler2D _MainTex;
            float4 _MainTex_ST;
            fixed4 _Color;
            float4 _HR_Curve;
            float4 _HR_Origin;

            struct appdata
            {
                float4 vertex : POSITION;
                float3 normal : NORMAL;
                float2 uv : TEXCOORD0;
                fixed4 color : COLOR;
            };

            struct v2f
            {
                float4 pos : SV_POSITION;
                float2 uv : TEXCOORD0;
                fixed4 col : COLOR0;
                UNITY_FOG_COORDS(1)
            };

            v2f vert (appdata v)
            {
                v2f o;
                float4 wpos = mul(unity_ObjectToWorld, v.vertex);
                float dz = max(0.0, wpos.z - _HR_Origin.z);
                wpos.y -= dz * dz * _HR_Curve.y;
                wpos.x += dz * dz * _HR_Curve.x;
                o.pos = mul(UNITY_MATRIX_VP, wpos);
                o.uv = TRANSFORM_TEX(v.uv, _MainTex);
                float3 n = UnityObjectToWorldNormal(v.normal);
                half nl = saturate(dot(n, _WorldSpaceLightPos0.xyz));
                half3 light = nl * _LightColor0.rgb + ShadeSH9(half4(n, 1));
                half emissive = 1.0 - v.color.a;
                half3 lit = v.color.rgb * _Color.rgb * light;
                o.col = fixed4(lerp(lit, v.color.rgb * _Color.rgb, emissive), 1);
                UNITY_TRANSFER_FOG(o, o.pos);
                return o;
            }

            fixed4 frag (v2f i) : SV_Target
            {
                fixed4 c = tex2D(_MainTex, i.uv);
                c.rgb *= i.col.rgb;
                half luma = dot(c.rgb, half3(0.299, 0.587, 0.114));
                c.rgb = saturate(lerp(luma.xxx, c.rgb, 1.28));
                c.a = 1;
                UNITY_APPLY_FOG(i.fogCoord, c);
                return c;
            }
            ENDCG
        }
    }
    Fallback "VertexLit"
}
