using System;
using NUnit.Framework;
using UnityEngine;

namespace TokyoNightRun.Tests
{
    public class RunStatsTests
    {
        [Test] public void Distance_AddsScore_WithMultiplier()
        {
            var s = new RunStats();
            s.AddDistance(100f, 1f);
            s.AddDistance(100f, 2f);
            Assert.AreEqual(300, s.Score);
            Assert.AreEqual(200f, s.Distance, 0.001f);
        }

        [Test] public void Coins_ScoreAndCount()
        {
            var s = new RunStats();
            s.AddCoins(3, 2f);
            Assert.AreEqual(3, s.Coins);
            Assert.AreEqual(3 * GameConfig.CoinScore * 2, s.Score);
        }

        [Test] public void Energy_FillsFromGulal_AndBurstConsumesIt()
        {
            var s = new RunStats();
            Assert.IsFalse(s.TryConsumeEnergy());
            s.AddGulal(10);
            Assert.IsTrue(s.EnergyFull);
            Assert.IsTrue(s.TryConsumeEnergy());
            Assert.AreEqual(0f, s.Energy);
            Assert.IsFalse(s.TryConsumeEnergy());
        }

        [Test] public void Energy_IsCapped()
        {
            var s = new RunStats();
            s.AddGulal(50);
            Assert.AreEqual(GameConfig.EnergyMax, s.Energy, 0.001f);
        }
    }

    public class PowerUpTimersTests
    {
        [Test] public void Activate_ThenExpire_FiresEachEventOnce()
        {
            var t = new PowerUpTimers();
            int started = 0, expired = 0;
            t.Started += _ => started++;
            t.Expired += _ => expired++;
            Assert.IsTrue(t.Activate(PowerUpType.Magnet));
            t.Tick(GameConfig.PowerUpDuration(PowerUpType.Magnet) + 0.1f);
            t.Tick(5f);
            Assert.AreEqual(1, started);
            Assert.AreEqual(1, expired);
            Assert.IsFalse(t.IsActive(PowerUpType.Magnet));
        }

        [Test] public void ReCollecting_RefreshesTimer_WithoutSecondStart()
        {
            var t = new PowerUpTimers();
            int started = 0;
            t.Started += _ => started++;
            t.Activate(PowerUpType.Shield);
            t.Tick(10f);
            Assert.IsFalse(t.Activate(PowerUpType.Shield));
            Assert.AreEqual(1, started);
            Assert.AreEqual(GameConfig.PowerUpDuration(PowerUpType.Shield), t.Remaining(PowerUpType.Shield), 0.001f);
        }

        [Test] public void Cancel_EndsEarly_Once()
        {
            var t = new PowerUpTimers();
            int expired = 0;
            t.Expired += _ => expired++;
            t.Activate(PowerUpType.Shield);
            t.Cancel(PowerUpType.Shield);
            t.Cancel(PowerUpType.Shield);
            Assert.AreEqual(1, expired);
        }

        [Test] public void PowerUps_AreIndependent()
        {
            var t = new PowerUpTimers();
            t.Activate(PowerUpType.Magnet);
            t.Activate(PowerUpType.Multiplier);
            t.Cancel(PowerUpType.Magnet);
            Assert.IsTrue(t.IsActive(PowerUpType.Multiplier));
        }
    }

    public class PoolAndWorldTests
    {
        [Test] public void Pool_ReusesObjects_AndIgnoresDoubleRelease()
        {
            var pool = new GameObjectPool("TestPool", () => new GameObject("pooled"), null, 0);
            var a = pool.Get(null);
            Assert.AreEqual(1, pool.ActiveCount);
            pool.Release(a);
            pool.Release(a); // second release must be harmless
            Assert.AreEqual(0, pool.ActiveCount);
            var b = pool.Get(null);
            Assert.AreSame(a, b);
            Assert.AreEqual(1, pool.CreatedCount);
            UnityEngine.Object.DestroyImmediate(b);
            UnityEngine.Object.DestroyImmediate(GameObject.Find("Pool_TestPool"));
        }

        [Test] public void Segments_AreContiguous()
        {
            for (int i = 0; i < 50; i++)
                Assert.AreEqual(TrackManager.SegmentStart(i) + GameConfig.SegmentLength, TrackManager.SegmentStart(i + 1), 0.0001f);
        }

        [Test] public void SafeLane_StaysInRange_AndMovesAtMostOne()
        {
            var rng = new System.Random(1);
            int lane = 1;
            for (int i = 0; i < 5000; i++)
            {
                int next = TrackManager.NextSafeLane(lane, rng);
                Assert.IsTrue(next >= 0 && next < GameConfig.LaneCount);
                Assert.LessOrEqual(Mathf.Abs(next - lane), 1);
                lane = next;
            }
        }

        [Test] public void Obstacles_HaveTriggerColliders_AndExpectedKinds()
        {
            var rng = new System.Random(2);
            foreach (ObstacleType t in Enum.GetValues(typeof(ObstacleType)))
            {
                var go = ProceduralFactory.BuildObstacle(t, rng);
                var col = go.GetComponent<BoxCollider>();
                var ob = go.GetComponent<Obstacle>();
                Assert.IsNotNull(col, t + " has no collider");
                Assert.IsTrue(col.isTrigger);
                Assert.IsNotNull(ob);
                if (t == ObstacleType.Puddle) Assert.AreEqual(ObstacleKind.Slow, ob.Kind);
                if (t == ObstacleType.Banner) Assert.AreEqual(ObstacleKind.High, ob.Kind);
                if (t == ObstacleType.Barricade || t == ObstacleType.Trolley) Assert.AreEqual(ObstacleKind.Low, ob.Kind);
                if (t == ObstacleType.TrainStatic || t == ObstacleType.TrainCargo) Assert.AreEqual(ObstacleKind.Solid, ob.Kind);
                if (t == ObstacleType.TrainMoving) Assert.Greater(ob.MoveSpeed, 0f);
                if (t != ObstacleType.TrainMoving) Assert.AreEqual(0f, ob.MoveSpeed);
                UnityEngine.Object.DestroyImmediate(go);
            }
        }

        [Test] public void Environment_HasNoColliders()
        {
            for (int v = 0; v < 3; v++)
            {
                var seg = ProceduralEnvironment.BuildSegment(v, new System.Random(v));
                Assert.AreEqual(0, seg.GetComponentsInChildren<Collider>().Length, "variant " + v + " has colliders");
                UnityEngine.Object.DestroyImmediate(seg);
            }
        }

        [Test] public void Collectibles_AreTriggers()
        {
            var coin = ProceduralFactory.BuildCoin();
            Assert.IsTrue(coin.GetComponent<SphereCollider>().isTrigger);
            Assert.AreEqual(CollectibleType.Coin, coin.GetComponent<Collectible>().Type);
            UnityEngine.Object.DestroyImmediate(coin);
        }
    }

    public class RailwayTests
    {
        [Test] public void TrainsFitInsideOneObstacleRow()
        {
            Assert.Less(GameConfig.TrainLength, GameConfig.RowSpacing);
            Assert.Less(GameConfig.CargoLength, GameConfig.RowSpacing);
        }

        [Test] public void TrackBedCoversAllThreeLanes()
        {
            float edge = PlayerController.LaneX(GameConfig.LaneCount - 1) + GameConfig.RailHalfGauge;
            Assert.Less(edge, ProceduralEnvironment.PlatformInnerX);
        }

        [Test] public void Batcher_BuildsMeshes_WithMatchingArrays()
        {
            var b = new MeshBatcher();
            b.Box(Vector3.zero, Vector3.one, Color.red);
            b.Prim(PrimKind.Cylinder, Vector3.up, Vector3.one, Color.blue);
            b.Prim(PrimKind.Sphere, Vector3.up * 2, Vector3.one, Color.green);
            b.Prim(PrimKind.Wedge, Vector3.up * 3, Vector3.one, Color.white);
            var root = new GameObject("t");
            var parts = b.Build(root.transform);
            Assert.Greater(parts.Count, 0);
            foreach (var go in parts)
            {
                var m = go.GetComponent<MeshFilter>().sharedMesh;
                Assert.AreEqual(m.vertexCount, m.normals.Length);
                Assert.AreEqual(m.vertexCount, m.uv.Length);
                Assert.AreEqual(0, m.triangles.Length % 3);
            }
            UnityEngine.Object.DestroyImmediate(root);
        }
    }

    public class MissionTests
    {
        [Test] public void SameDate_GivesSameMissions_AndThreeOfThem()
        {
            var a = MissionManager.Generate("2026-03-04");
            var b = MissionManager.Generate("2026-03-04");
            Assert.AreEqual(3, a.Count);
            for (int i = 0; i < 3; i++) { Assert.AreEqual(a[i].type, b[i].type); Assert.AreEqual(a[i].target, b[i].target); }
        }
    }
}
