using System.IO;
using NUnit.Framework;
using UnityEngine;

namespace TokyoNightRun.Tests
{
    public class SaveSystemTests
    {
        string dir;

        [SetUp] public void SetUp()
        {
            dir = Path.Combine(Path.GetTempPath(), "tokyonightrun_test_" + System.Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(dir);
            SaveManager.PathOverride = dir;
            SaveManager.ForgetCache();
        }

        [TearDown] public void TearDown()
        {
            SaveManager.PathOverride = null;
            SaveManager.ForgetCache();
            if (Directory.Exists(dir)) Directory.Delete(dir, true);
        }

        [Test] public void MissingFile_GivesSafeDefaults()
        {
            var d = SaveManager.Data;
            Assert.AreEqual(0, d.coins);
            Assert.IsTrue(d.unlocked.Contains(Catalog.DefaultCharacter));
            Assert.AreEqual(Catalog.DefaultCharacter, d.selectedCharacter);
        }

        [Test] public void SaveThenLoad_RoundTrips()
        {
            SaveManager.Data.coins = 123; SaveManager.Data.bestScore = 4567;
            SaveManager.Save();
            SaveManager.ForgetCache();
            Assert.AreEqual(123, SaveManager.Data.coins);
            Assert.AreEqual(4567, SaveManager.Data.bestScore);
        }

        [Test] public void CorruptFile_FallsBackToDefaults()
        {
            File.WriteAllText(Path.Combine(dir, "tokyonightrun_save.json"), "{ this is not json ");
            SaveManager.ForgetCache();
            Assert.AreEqual(0, SaveManager.Data.coins);
        }

        [Test] public void InvalidValues_AreRepaired()
        {
            File.WriteAllText(Path.Combine(dir, "tokyonightrun_save.json"),
                "{\"coins\":-50,\"musicVolume\":9,\"quality\":99,\"selectedCharacter\":\"char_unknown\",\"unlocked\":[\"bogus\"]}");
            SaveManager.ForgetCache();
            var d = SaveManager.Data;
            Assert.AreEqual(0, d.coins);
            Assert.AreEqual(1f, d.musicVolume);
            Assert.AreEqual(2, d.quality);
            Assert.AreEqual(Catalog.DefaultCharacter, d.selectedCharacter);
            Assert.IsFalse(d.unlocked.Contains("bogus"));
        }

        [Test] public void ResetAll_ClearsProgress()
        {
            SaveManager.Data.coins = 999;
            SaveManager.ResetAll();
            Assert.AreEqual(0, SaveManager.Data.coins);
        }
    }

    public class ProgressionTests
    {
        string dir;
        bool oldFlag;
        [SetUp] public void SetUp()
        {
            oldFlag = GameConfig.UnlockAllCharactersForTesting;
            GameConfig.UnlockAllCharactersForTesting = false; // test the real coin progression
            dir = Path.Combine(Path.GetTempPath(), "tokyonightrun_test_" + System.Guid.NewGuid().ToString("N"));
            SaveManager.PathOverride = dir; SaveManager.ForgetCache();
        }
        [TearDown] public void TearDown()
        {
            GameConfig.UnlockAllCharactersForTesting = oldFlag;
            SaveManager.PathOverride = null; SaveManager.ForgetCache();
            if (Directory.Exists(dir)) Directory.Delete(dir, true);
        }

        [Test] public void CannotUnlock_WithoutEnoughCoins()
        {
            SaveManager.Data.coins = 10;
            Assert.IsFalse(Progression.TryUnlock("char_divya"));
            Assert.AreEqual(10, SaveManager.Data.coins);
            Assert.IsFalse(Progression.IsUnlocked("char_divya"));
        }

        [Test] public void Unlock_SpendsCoins_ThenSelectWorks()
        {
            SaveManager.Data.coins = 700;
            Assert.IsTrue(Progression.TryUnlock("char_divya"));
            Assert.AreEqual(100, SaveManager.Data.coins);
            Assert.IsTrue(Progression.Select("char_divya"));
            Assert.AreEqual("char_divya", SaveManager.Data.selectedCharacter);
        }

        [Test] public void CannotSelect_LockedItem_OrBuyTwice()
        {
            Assert.IsFalse(Progression.Select("char_sandy"));
            SaveManager.Data.coins = 5000;
            Assert.IsTrue(Progression.TryUnlock("trail_pink"));
            Assert.IsFalse(Progression.TryUnlock("trail_pink"));
            Assert.AreEqual(4800, SaveManager.Data.coins);
        }

        [Test] public void UnknownId_IsRejected() { Assert.IsFalse(Progression.TryUnlock("nope")); }
    }

    public class CharacterTests
    {
        static readonly string[] Ids = { "char_dhiren", "char_divya", "char_trisha", "char_ulvaan", "char_sandy" };

        [Test] public void FiveCharacters_InCatalog_InOrder()
        {
            Assert.AreEqual(5, Catalog.Characters.Length);
            for (int i = 0; i < 5; i++) Assert.AreEqual(Ids[i], Catalog.Characters[i].Id);
            Assert.AreEqual(Catalog.CoupleB, Catalog.FindCharacter(Catalog.CoupleA).PartnerId);
            Assert.AreEqual(Catalog.CoupleA, Catalog.FindCharacter(Catalog.CoupleB).PartnerId);
        }

        [Test] public void EveryCharacter_BuildsASkinnedHumanoid()
        {
            foreach (var def in Catalog.Characters)
            {
                var rv = CharacterBuilder.Build(def, Catalog.FindOutfit(Catalog.DefaultOutfit));
                var smr = rv.GetComponentInChildren<SkinnedMeshRenderer>();
                Assert.IsNotNull(smr, def.Name + " has no SkinnedMeshRenderer");
                Assert.Greater(smr.sharedMesh.vertexCount, 3000, def.Name + " mesh is too simple");
                Assert.Less(smr.sharedMesh.vertexCount, 60000);
                Assert.AreEqual(smr.sharedMesh.vertexCount, smr.sharedMesh.boneWeights.Length);
                Assert.AreEqual(smr.bones.Length, smr.sharedMesh.bindposes.Length);
                for (int b = 0; b < (int)BoneId.Tail1; b++)
                {
                    Assert.IsNotNull(rv.Bones[b], def.Name + " is missing bone " + (BoneId)b);
                }
                foreach (var w in smr.sharedMesh.boneWeights) Assert.AreEqual(1f, w.weight0 + w.weight1 + w.weight2 + w.weight3, 0.01f);
                UnityEngine.Object.DestroyImmediate(rv.gameObject);
            }
        }

        [Test] public void AllPoses_ProduceFiniteAngles()
        {
            var f = new PoseFrame();
            foreach (CharacterStyle who in System.Enum.GetValues(typeof(CharacterStyle)))
                foreach (RunnerVisual.Pose p in System.Enum.GetValues(typeof(RunnerVisual.Pose)))
                {
                    CharacterPoses.Evaluate(p, who, 1.3f, 0.4f, 0.5f, 0.95f, f);
                    foreach (var e in f.E) Assert.IsFalse(float.IsNaN(e.x + e.y + e.z));
                    Assert.IsFalse(float.IsNaN(f.HipsY));
                }
        }

        [Test] public void Visual_LandsInRunAfterJump()
        {
            var rv = CharacterBuilder.Build(Catalog.Characters[0], Catalog.Outfits[0]);
            for (int i = 0; i < 10; i++) rv.Apply(RunnerVisual.Pose.Jump, 0.03f, 0f, 0f);
            rv.Apply(RunnerVisual.Pose.Run, 0.03f, 0f, 0f);
            Assert.AreEqual(RunnerVisual.Pose.Land, rv.CurrentPose);
            for (int i = 0; i < 20; i++) rv.Apply(RunnerVisual.Pose.Run, 0.03f, 0f, 0f);
            Assert.AreEqual(RunnerVisual.Pose.Run, rv.CurrentPose);
            UnityEngine.Object.DestroyImmediate(rv.gameObject);
        }

        [Test] public void CoupleSkins_OnlyForTheCouple()
        {
            var sunset = Catalog.FindOutfit("outfit_couple_sunset");
            Assert.IsTrue(Catalog.OutfitAllowed(sunset, "char_trisha"));
            Assert.IsTrue(Catalog.OutfitAllowed(sunset, "char_ulvaan"));
            Assert.IsFalse(Catalog.OutfitAllowed(sunset, "char_sandy"));
            Assert.AreEqual(Catalog.JacketColor(Catalog.FindCharacter("char_trisha"), sunset), Catalog.JacketColor(Catalog.FindCharacter("char_ulvaan"), sunset));
        }

        [Test] public void TestingBuild_AllFiveUnlocked()
        {
            bool old = GameConfig.UnlockAllCharactersForTesting;
            GameConfig.UnlockAllCharactersForTesting = true;
            foreach (var id in Ids) Assert.IsTrue(Progression.IsUnlocked(id));
            GameConfig.UnlockAllCharactersForTesting = old;
        }
    }
}
