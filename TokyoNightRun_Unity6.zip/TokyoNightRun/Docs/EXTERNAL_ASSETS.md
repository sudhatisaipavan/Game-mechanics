# External assets (none are required to run the game)
The game runs with zero imported assets: all models, textures, particles and sounds are generated in code. For the final polished look you
should replace the following with authored content:

| What | Why | Where to get it (check each licence) | How to import |
|---|---|---|---|
| Five humanoid character models (FBX) | Hand-modelled faces, hair, cloth would look much better than procedural primitives | Commission an artist; or Ready Player Me / VRoid / Character Creator (check commercial terms); or Mixamo base characters | Import as Humanoid, save prefab to `Assets/Resources/Characters/<id>.prefab` |
| Run/jump/fall/land/slide/idle/victory animations | Mocap-quality motion | Mixamo (free with Adobe ID; licence allows use in games), Unity Asset Store animation packs | Build an Animator Controller with states named Idle, Run, Jump, Fall, Land, Slide, Dead, Victory |
| Music and sound effects | Audio is synthesised (basic) | OpenGameArt, Freesound, Asset Store (check licence) | Replace the dictionary in `Audio/AudioManager.cs` |
| UI font and rounded sprites | UI uses the built-in font and plain rectangles | Google Fonts (OFL) + TextMeshPro | Optional |
| Real photo-textured trains/buildings | Textures are procedural 64-128 px | Asset Store / Poly Haven (CC0) | Replace materials in `MaterialLibrary` / `TextureFactory` |
