# Tokyo Night Run – feature testing checklist
Legend: **[auto]** = covered by EditMode unit tests (Test Runner). **[manual]** = you must run the game. Nothing has been run yet (v0.2 was written without Unity).

## Automated (Window > General > Test Runner > EditMode)
- [auto] Save/load round trip, missing file, corrupt file, invalid values repaired, reset
- [auto] Character/outfit/trail unlock: not enough coins, spend coins, select, no double purchase, unknown id
- [auto] Score: distance, multiplier, coins, energy meter fill/cap/burst consume
- [auto] Power-up timers: start once, refresh without a 2nd start, expire once, cancel, independence
- [auto] Object pool reuse + double-release safety
- [auto] Segments contiguous (no gaps), safe lane always within 1 lane
- [auto] Every obstacle has a trigger collider and the right kind; environment has no colliders; coin is a trigger

## Manual: gameplay (Game scene via MainMenu > PLAY)
- [manual] 3-2-1-GO countdown, runner starts running automatically, speed gradually increases
- [manual] Left/right swipes (and A/D) move one lane smoothly; cannot leave the 3 lanes
- [manual] Jump clears barricades/scooters; slide passes under banners; swipe down in air = fast fall then slide
- [manual] Hitting a cart/car/stack/float/rickshaw ends the run once (game over appears after ~1s, no repeats)
- [manual] Puddle slows you, does not end the run; decorations never hurt
- [manual] Coins/gulal/balloons/tokens disappear when collected; counters update
- [manual] Power-ups: Magnet pulls items; Pichkari speeds up + blue stream; Shield absorbs 1 hit; x2 doubles score; HUD chips show timers; re-collecting refreshes timer
- [manual] Gulal fills Color Energy; BURST button lights up when full and works
- [manual] Milestone toast + confetti every 500 m
- [manual] Pause button / Esc / Android Back pauses; Resume, Restart, Main Menu work; app minimise pauses
- [manual] Game over: score, coins, best, restart, main menu; best score saved
- [manual] No gaps or pop-in in the street while running for several minutes; no error spam in Console

## Manual: menus
- [manual] Runners: arrows browse, locked shows cost, unlock needs coins, selection persists after restart, runner in game matches
- [manual] Missions: 3 daily objectives, progress after a run, claim gives coins once
- [manual] Shop: buy/equip characters, outfits (kurta colour changes), trails (visible behind runner); "Not enough coins" message
- [manual] Settings: volume sliders, vibration, on-screen buttons (appear in HUD), graphics level, reset progress needs confirmation
- [manual] Every button plays a click sound and does something

## Manual: Android
- [manual] Portrait only; HUD clear of notch/camera cut-out; touch swipes responsive; 30/60 fps stable on a mid-range phone; vibration on crash

## v0.2 additions (all [manual] unless noted)
- [auto] Five characters in catalog, skinned meshes build, bone weights sum to 1, poses finite, landing state, couple skins, unlock-all flag
- Menu: RUNNERS shows Dhiren/Divya/Trisha/Ulvaan/Sandy; arrows + icons + drag rotation work; SELECT plays victory and persists after restart
- COUPLE screen (Trisha/Ulvaan): both shown, skins change both, PLAY AS buttons select the right runner; shop refuses couple skins for others
- In game: the chosen character runs on all 3 lanes; run/jump/fall/land/slide animations blend without popping; Sandy flips; ponytail/bandana swing
- Trains: parked trains block lanes (hit = game over once); moving trains start rolling only when close and never block the safe lane
- Barriers can be jumped, Holi banners slid under, puddles slow; coins fly up when collected
- Check for z-fighting/flicker on platforms, rails and train decals; check characters for inside-out (invisible) faces or odd proportions
- Performance on a real phone (target 30+ fps)
