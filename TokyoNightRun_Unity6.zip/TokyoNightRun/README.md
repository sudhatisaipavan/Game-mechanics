# Tokyo Night Run – Neon rails after dark
A Subway-Surfers-style 3D endless runner for Android, built in Unity 6 (Universal Render Pipeline) with C#. Theme: **Tokyo Night Run**.
Everything (world, trains, obstacles, pickups, characters, sounds, UI) is generated from code, so there are no external art files to import.

**Honest status:** this project was produced without Unity available, so it has not been opened or compiled in the editor.
The new theme code was syntax-checked and type-checked against stubs, and it builds on the Holi Rush code base (which your faculty
project already runs). Expect to fix a few small things on first open; send me the first red Console error or a screenshot and I will fix it.

## Open it
1. Unity Hub > Add project from disk > select this `TokyoNightRun` folder > open with **Unity 6 (6000.x)** with Android Build Support. Let Unity upgrade if it asks.
2. On first open the `TokyoNightRunRenderSetup` tool installs Universal RP and creates the URP asset. If it fails: **Tools > Tokyo Night Run > Setup Unity 6 Rendering (URP)**.
3. **Tools > Tokyo Night Run > Generate Complete Game** (runs automatically if scenes are missing), open `Assets/Scenes/MainMenu.unity` and press Play.
Editor controls: A/D or arrows = lanes, W/Space = jump, S = slide, Esc = pause, mouse drag = swipe.

## The theme
**Look:** Always night: a neon-pink dusk, deep midnight blue and a pre-dawn glow, with a star field. Towers with lit windows and neon signs, a konbini and vending machines, an izakaya alley with noren curtains and red lantern chains, torii gates over the tracks, a pagoda, sakura trees and a red Tokyo-tower style lattice on the skyline. Rain and drifting petals.

**Obstacles:** Glowing vending machines (solid), roadworks barrier with arrow board (jump), delivery cart with lantern (jump), neon rain puddle (slow), torii gate with shimenawa rope (slide), neon crate stack with lantern (solid).

**Pickups:** Paper lanterns (energy) and onigiri (energy), lucky gold coins as bonus tokens.

**Trains:** Shinkansen-style white/blue, Yamanote green, orange, red and neon-purple coaches with neon underglow and lit windows; freight wagon of boxes and glowing lanterns.

**Power-ups:** Coin Magnet, Turbo Dash, Neon Shield, Night x2.   **Music:** City-pop synth arpeggio loop (100 BPM).   **Weather:** neon rain and sakura petals.

Gameplay (lane width, speeds, colliders, scoring, missions, shop, characters) is identical in every theme, so only the visuals and wording change.

## How the theme system works (good for your viva)
* `Scripts/Themes/ThemeDef.cs` – one data class per theme: sky colours, fog, post-processing, palette, graffiti words, train colours, texts, music style, weather.
* `Scripts/Themes/ThemeLibrary.cs` – the five definitions (Holi, ClassicCity, WinterHoliday, TokyoNight, MiamiBeach).
* `Scripts/Themes/Theme.cs` – `ThemeConfig.DefaultTheme` picks the theme. Change that one line to re-skin this project as any of the other four.
* `Scripts/World/ThemedEnvironment.cs` – shared railway corridor (tracks, platforms, masts) restyled per theme; `ClassicEnv.cs`, `WinterEnv.cs`, `TokyoEnv.cs`, `MiamiEnv.cs` add three scenery variants each (one per time of day).
* `Scripts/World/ThemeProps.cs` – theme obstacles, pickups, train decoration, freight loads. Colliders stay in `ProceduralFactory.cs`.
* Internal names such as `CollectibleType.Gulal` and `RunStats.Gulal` are kept from the original game and simply mean "energy pickup A" here; the player only ever sees the theme names.

## Tuning
Look: `ThemeLibrary.cs` (colours, fog, bloom), shaders in `Assets/Shaders`. Gameplay numbers: `Core/GameConfig.cs`. Horizon bend: `Camera/CurvedWorld.cs`.
Android: File > Build Profiles > Android; scenes MainMenu + Game; package `com.tokyonightrun.game`; **Tools > Tokyo Night Run > Build Android APK (testing)**.
Tests: Window > General > Test Runner (EditMode). Manual checklist: `Docs/TESTING_CHECKLIST.md`.
